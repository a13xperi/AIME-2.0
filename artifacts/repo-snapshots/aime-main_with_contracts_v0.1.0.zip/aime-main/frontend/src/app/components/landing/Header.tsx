'use client';

import { useState, useEffect } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { Button } from "@/app/components/ui/button";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  // Track active section on scroll for mobile
  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll("section[id]");
      const scrollPosition = window.scrollY + 100;

      sections.forEach((section) => {
        const sectionTop = (section as HTMLElement).offsetTop;
        const sectionHeight = (section as HTMLElement).offsetHeight;
        const sectionId = section.getAttribute("id") || "";

        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
          setActiveSection(sectionId);
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 shadow-sm">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 bg-green-600 rounded-md flex items-center justify-center text-white font-bold text-xs">
            A
          </div>
          <span className="text-lg font-bold">AIME Golf</span>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden p-2 rounded-md touch-callout-none tap-highlight-transparent"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
        >
          {mobileMenuOpen ? (
            <X className="h-5 w-5 text-gray-700" />
          ) : (
            <Menu className="h-5 w-5 text-gray-700" />
          )}
        </button>

        {/* Desktop nav */}
        <nav className="hidden md:flex md:items-center md:space-x-6">
          <div className="hidden md:flex md:items-center md:space-x-6">
            <Link href="#features" className="text-sm font-medium text-gray-700 hover:text-gray-900">
              Features
            </Link>
            <Link href="#pricing" className="text-sm font-medium text-gray-700 hover:text-gray-900">
              Pricing
            </Link>
            <Link href="#testimonials" className="text-sm font-medium text-gray-700 hover:text-gray-900">
              Testimonials
            </Link>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" asChild>
              <Link href="/login">Log in</Link>
            </Button>
            <Button className="bg-green-600 hover:bg-green-700" asChild>
              <Link href="/signup">Sign up</Link>
            </Button>
          </div>
        </nav>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 top-14 z-50 h-[calc(100vh-3.5rem)] overflow-y-auto bg-white pb-12">
          <div className="flex flex-col">
            <div className="flex flex-col px-6 py-3 divide-y">
              <Link
                href="#features"
                className={`text-lg font-medium py-3 border-b ${activeSection === "features" ? "text-green-600 border-green-600" : "border-gray-100"}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Features
              </Link>
              <Link
                href="#testimonials"
                className={`text-lg font-medium py-3 border-b ${activeSection === "testimonials" ? "text-green-600 border-green-600" : "border-gray-100"}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Testimonials
              </Link>
              <Link
                href="#pricing"
                className={`text-lg font-medium py-3 border-b ${activeSection === "pricing" ? "text-green-600 border-green-600" : "border-gray-100"}`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Pricing
              </Link>
            </div>
            <div className="p-6 border-t">
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" className="w-full h-12 text-base" asChild>
                  <Link href="/login">Log in</Link>
                </Button>
                <Button
                  className="w-full h-12 text-base bg-green-600 hover:bg-green-700"
                  asChild
                >
                  <Link href="/signup">Sign up</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
} 