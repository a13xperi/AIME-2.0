from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, Field, ConfigDict


class GeoPointWGS84(BaseModel):
    lat: float = Field(..., ge=-90.0, le=90.0)
    lon: float = Field(..., ge=-180.0, le=180.0)


class Point2D(BaseModel):
    x_m: float
    y_m: float


class Stimp(BaseModel):
    ft: int = Field(12, ge=0, le=30)
    inches: int = Field(0, alias="in", ge=0, le=11)

    model_config = ConfigDict(populate_by_name=True)


class SolvePuttArgs(BaseModel):
    contract_version: str = "0.2.0"
    course_id: str
    hole_id: int
    ball_wgs84: GeoPointWGS84
    cup_wgs84: GeoPointWGS84
    stimp: Optional[Stimp] = None
    want_plot: bool = True
    request_id: Optional[str] = None


class PlotData(BaseModel):
    frame: str = "green_local_m"
    points: List[Point2D]


class RawData(BaseModel):
    dll_return_code: int
    dll_error_text: Optional[str] = None


class SolvePuttResult(BaseModel):
    contract_version: str = "0.2.0"
    request_id: str
    dtm_id: str
    ball_local: Point2D
    cup_local: Point2D
    instruction_text: str
    plot: Optional[PlotData] = None
    warnings: List[str] = Field(default_factory=list)
    raw: Optional[RawData] = None
