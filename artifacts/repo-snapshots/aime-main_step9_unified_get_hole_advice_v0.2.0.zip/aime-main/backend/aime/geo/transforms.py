from __future__ import annotations

import math
from functools import lru_cache
from typing import Any, Dict, List, Tuple

from pyproj import Transformer


class TransformError(RuntimeError):
    pass


@lru_cache(maxsize=32)
def _get_transformer_to_projected(epsg_projected: int) -> Transformer:
    # always_xy ensures lon/lat input order for EPSG:4326
    return Transformer.from_crs(4326, int(epsg_projected), always_xy=True)


def wgs84_to_projected_m(lat: float, lon: float, epsg_projected: int) -> Tuple[float, float]:
    try:
        transformer = _get_transformer_to_projected(int(epsg_projected))
        x_m, y_m = transformer.transform(lon, lat)
        return float(x_m), float(y_m)
    except Exception as e:
        raise TransformError(f"Failed WGS84→EPSG:{epsg_projected} transform: {e}") from e


def projected_to_green_local_m(x_proj_m: float, y_proj_m: float, manifest: Dict[str, Any]) -> Tuple[float, float]:
    t = manifest.get("transform") or {}

    sp_origin_x = float(t.get("sp_origin_x_m"))
    sp_origin_y = float(t.get("sp_origin_y_m"))
    local_offset_x = float(t.get("local_offset_x_m", 0.0))
    local_offset_y = float(t.get("local_offset_y_m", 0.0))
    rotation_deg = float(t.get("rotation_offset_deg", 0.0))

    # Step 1: translate into local frame
    dx = (x_proj_m - sp_origin_x) + local_offset_x
    dy = (y_proj_m - sp_origin_y) + local_offset_y

    # Step 2: rotation (MVP assumption: +deg is CCW around origin)
    theta = math.radians(rotation_deg)
    x_local = dx * math.cos(theta) - dy * math.sin(theta)
    y_local = dx * math.sin(theta) + dy * math.cos(theta)

    return float(x_local), float(y_local)


def wgs84_to_green_local_m(lat: float, lon: float, manifest: Dict[str, Any]) -> Tuple[float, float]:
    t = manifest.get("transform") or {}
    epsg = t.get("epsg_projected")
    if epsg is None:
        raise TransformError("Manifest missing transform.epsg_projected")

    x_proj, y_proj = wgs84_to_projected_m(lat, lon, int(epsg))
    return projected_to_green_local_m(x_proj, y_proj, manifest)


def bounds_warnings(x_m: float, y_m: float, manifest: Dict[str, Any], label: str) -> List[str]:
    ext = manifest.get("extents_m") or {}
    x_max = float(ext.get("x_max_m", 0.0))
    y_max = float(ext.get("y_max_m", 0.0))
    warnings: List[str] = []
    if x_m < 0.0 or x_m > x_max or y_m < 0.0 or y_m > y_max:
        warnings.append(
            f"{label} out of extents: ({x_m:.2f},{y_m:.2f}) not in [0..{x_max:.2f}]×[0..{y_max:.2f}]"
        )
    return warnings
