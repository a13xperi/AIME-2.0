#!/usr/bin/env python3
"""
Unified development server script for AIME POC.
This script starts both the Next.js frontend and FastAPI backend servers.
"""

import os
import sys
import time
import signal
import subprocess
import threading
from pathlib import Path
import socket

# Check if required packages are installed
try:
    import psutil
    import colorama
    from colorama import Fore, Style
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
except ImportError as e:
    missing_package = str(e).split("'")[1]
    print(f"Missing required package: {missing_package}")
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "psutil", "colorama", "watchdog"])
    print("Packages installed. Restarting script...")
    # Restart the script
    os.execv(sys.executable, [sys.executable] + sys.argv)

# Initialize colorama
colorama.init(autoreset=True)

# Base directory
BASE_DIR = Path(__file__).resolve().parent

# Frontend and backend directories
FRONTEND_DIR = BASE_DIR / "frontend"
BACKEND_DIR = BASE_DIR / "backend"

# Flags for running servers
frontend_process = None
backend_process = None
should_exit = False

def get_local_ip():
    try:
        # Create a socket that connects to an external server
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # It doesn't actually connect but tells the OS to allocate a network interface
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        return local_ip
    except:
        return "unknown"

def print_header():
    """Print a beautiful header for the dev server."""
    local_ip = get_local_ip()
    
    print(f"\n{Fore.CYAN}{'=' * 80}")
    print(f"{Fore.CYAN}{'AIME Development Server':^80}")
    print(f"{Fore.CYAN}{'=' * 80}")
    print(f"{Fore.GREEN}Frontend (local): {Fore.WHITE}http://localhost:3000")
    print(f"{Fore.GREEN}Frontend (network): {Fore.WHITE}http://{local_ip}:3000")
    print(f"{Fore.GREEN}Backend:  {Fore.WHITE}http://localhost:8000")
    print(f"{Fore.GREEN}API Docs: {Fore.WHITE}http://localhost:8000/docs")
    print(f"{Fore.CYAN}{'-' * 80}")
    print(f"{Fore.YELLOW}Press Ctrl+C to stop all servers")
    print(f"{Fore.CYAN}{'=' * 80}\n")

def prefix_output(line, prefix, color):
    """Add prefix to each output line with color."""
    if not line:
        return None
    return f"{color}[{prefix}]{Style.RESET_ALL} {line.decode('utf-8', errors='replace').rstrip()}"

def stream_output(process, prefix, color):
    """Stream and format output from a subprocess."""
    for line in iter(process.stdout.readline, b''):
        prefixed_line = prefix_output(line, prefix, color)
        if prefixed_line:
            print(prefixed_line)
    
    # Process error output if available
    for line in iter(process.stderr.readline, b''):
        prefixed_line = prefix_output(line, prefix, color)
        if prefixed_line:
            print(f"{Fore.RED}{prefixed_line}")

def start_backend():
    """Start the FastAPI backend server."""
    global backend_process
    
    # Activate conda environment and run the backend
    conda_executable = os.environ.get('CONDA_EXE', 'conda')
    conda_env = 'aime'
    
    # Make sure the conda initialization script is sourced for non-interactive shells
    if sys.platform == 'win32':
        # Windows command
        activate_cmd = f"{conda_executable} activate {conda_env} && "
        cmd = f"{activate_cmd}python {BACKEND_DIR}/main.py"
        backend_process = subprocess.Popen(
            cmd, 
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            cwd=BACKEND_DIR,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )
    else:
        # Unix command
        shell_path = os.environ.get('SHELL', '/bin/bash')
        cmd = f"source {os.path.dirname(conda_executable)}/../etc/profile.d/conda.sh && conda activate {conda_env} && python {BACKEND_DIR}/main.py"
        backend_process = subprocess.Popen(
            [shell_path, '-c', cmd],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            cwd=BACKEND_DIR,
            preexec_fn=os.setsid
        )
    
    # Start a thread to stream output
    threading.Thread(target=stream_output, args=(backend_process, "BACKEND", Fore.BLUE), daemon=True).start()
    print(f"{Fore.GREEN}Backend server started at http://localhost:8000")

def start_frontend():
    """Start the Next.js frontend server."""
    global frontend_process
    
    # Run npm dev command
    cmd = ["npm", "run", "dev"]
    
    if sys.platform == 'win32':
        frontend_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            cwd=FRONTEND_DIR,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )
    else:
        frontend_process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            cwd=FRONTEND_DIR,
            preexec_fn=os.setsid
        )
    
    # Start a thread to stream output
    threading.Thread(target=stream_output, args=(frontend_process, "FRONTEND", Fore.GREEN), daemon=True).start()
    print(f"{Fore.GREEN}Frontend server started at http://localhost:3000")

def stop_servers():
    """Stop all running servers."""
    global frontend_process, backend_process, should_exit
    
    print(f"\n{Fore.YELLOW}Shutting down servers...")
    should_exit = True
    
    # Stop frontend
    if frontend_process:
        if sys.platform == 'win32':
            frontend_process.terminate()
        else:
            try:
                os.killpg(os.getpgid(frontend_process.pid), signal.SIGTERM)
            except:
                # Fallback to simple terminate if process group kill fails
                frontend_process.terminate()
    
    # Stop backend
    if backend_process:
        if sys.platform == 'win32':
            backend_process.terminate()
        else:
            try:
                os.killpg(os.getpgid(backend_process.pid), signal.SIGTERM)
            except:
                # Fallback to simple terminate if process group kill fails
                backend_process.terminate()
    
    # Wait for processes to terminate
    if frontend_process:
        try:
            frontend_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            # Force kill if graceful shutdown fails
            if sys.platform == 'win32':
                frontend_process.kill()
            else:
                os.killpg(os.getpgid(frontend_process.pid), signal.SIGKILL)
    
    if backend_process:
        try:
            backend_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            # Force kill if graceful shutdown fails
            if sys.platform == 'win32':
                backend_process.kill()
            else:
                os.killpg(os.getpgid(backend_process.pid), signal.SIGKILL)
    
    print(f"{Fore.GREEN}All servers stopped.")

def cleanup_orphaned_processes():
    """Clean up any orphaned Node.js or Python processes from previous runs."""
    current_pid = os.getpid()
    
    # Find and kill orphaned processes
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        try:
            proc_info = proc.info
            if proc.pid == current_pid:
                continue
            
            # Check for Node.js processes related to Next.js
            if ('node' in proc_info['name'].lower() and 
                proc_info['cmdline'] and 
                any('next' in cmd.lower() for cmd in proc_info['cmdline'] if cmd)):
                print(f"{Fore.YELLOW}Killing orphaned Next.js process: {proc.pid}")
                proc.terminate()
            
            # Check for Python processes running the backend
            if ('python' in proc_info['name'].lower() and 
                proc_info['cmdline'] and 
                any('main.py' in cmd for cmd in proc_info['cmdline'] if cmd)):
                print(f"{Fore.YELLOW}Killing orphaned Python backend process: {proc.pid}")
                proc.terminate()
                
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

def signal_handler(sig, frame):
    """Handle keyboard interrupts."""
    if not should_exit:
        print(f"\n{Fore.YELLOW}Received interrupt signal. Shutting down...")
        stop_servers()
        sys.exit(0)

def main():
    """Main function to start development servers."""
    # Register signal handler for clean exit
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print_header()
    
    # Clean up any orphaned processes
    cleanup_orphaned_processes()
    
    try:
        # Start servers
        start_backend()
        time.sleep(2)  # Give backend a moment to start
        start_frontend()
        
        # Keep the main thread alive
        while not should_exit:
            # Check if processes are still running
            if frontend_process and frontend_process.poll() is not None:
                print(f"{Fore.RED}Frontend server exited unexpectedly. Exit code: {frontend_process.returncode}")
                if not should_exit:
                    print(f"{Fore.YELLOW}Restarting frontend server...")
                    start_frontend()
            
            if backend_process and backend_process.poll() is not None:
                print(f"{Fore.RED}Backend server exited unexpectedly. Exit code: {backend_process.returncode}")
                if not should_exit:
                    print(f"{Fore.YELLOW}Restarting backend server...")
                    start_backend()
            
            time.sleep(1)
    
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Keyboard interrupt received")
    finally:
        stop_servers()

if __name__ == "__main__":
    main() 