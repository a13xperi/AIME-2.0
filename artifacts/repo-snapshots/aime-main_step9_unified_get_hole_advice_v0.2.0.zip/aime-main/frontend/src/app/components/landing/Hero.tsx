'use client';

import Link from "next/link";
import { Button } from "@/app/components/ui/button";
import Image from "next/image";
import { ArrowDown } from "lucide-react";

export default function Hero() {
  return (
    <section className="pt-6 pb-12 md:py-20">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center text-center space-y-4 mb-8">
          <div className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium bg-green-50 text-green-700 border-green-200">
            <span>Mobile-First Experience</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight">
            <span className="text-green-600">AIME Golf</span> Lorem Ipsum
          </h1>
          <p className="text-base md:text-lg text-gray-500 max-w-md">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 h-12 text-base w-full sm:w-auto">
              Get Started
            </Button>
            <Button size="lg" variant="outline" className="h-12 text-base w-full sm:w-auto">
              Learn More
            </Button>
          </div>
        </div>
        <div className="flex justify-center mt-8 px-4 md:mt-12">
          <div className="relative w-full max-w-[320px] md:max-w-[360px] aspect-[1/2]">
            <div className="absolute inset-0 rounded-[40px] overflow-hidden border-8 border-gray-800 shadow-xl">
              <div className="absolute top-0 w-32 h-6 bg-gray-800 left-1/2 transform -translate-x-1/2 rounded-b-xl"></div>
              <Image
                src="/placeholder.svg?height=800&width=400&text=AIME Golf App"
                alt="AIME Golf mobile app preview"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
        <div className="flex justify-center mt-12">
          <a 
            href="#features" 
            className="flex items-center justify-center w-12 h-12 rounded-full bg-white shadow-md hover:shadow-lg transition-all"
          >
            <ArrowDown className="h-5 w-5 text-gray-700" />
          </a>
        </div>
      </div>
    </section>
  );
} 