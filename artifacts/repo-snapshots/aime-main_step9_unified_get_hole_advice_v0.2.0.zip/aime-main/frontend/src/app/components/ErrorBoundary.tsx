'use client';

import { useState, useEffect } from 'react';
import logger from '../lib/logger';

type HTMLElementWithSource = HTMLElement & {
  src?: string;
  href?: string;
};

export default function ErrorBoundary({ 
  children 
}: { 
  children: React.ReactNode 
}) {
  const [hasError, setHasError] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    // Handle JavaScript errors
    const handleError = (error: ErrorEvent) => {
      logger.error('Caught in ErrorBoundary', error);
      setHasError(true);
      setError(error.error);
    };

    // Handle resource loading errors (404s, etc.)
    const handleResourceError = (event: Event) => {
      const target = event.target as HTMLElementWithSource;
      if (target.tagName === 'LINK' || target.tagName === 'SCRIPT' || target.tagName === 'IMG') {
        logger.error(`Failed to load resource: ${target.src || target.href}`, event);
      }
    };

    window.addEventListener('error', handleError);
    window.addEventListener('error', handleResourceError, true);
    
    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('error', handleResourceError, true);
    };
  }, []);

  if (hasError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg max-w-md w-full">
          <h2 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-4">
            Something went wrong
          </h2>
          <div className="bg-red-50 dark:bg-red-900/30 p-4 rounded-md overflow-auto">
            <p className="text-red-800 dark:text-red-200 font-mono text-sm whitespace-pre-wrap">
              {error?.message || 'An unexpected error occurred'}
            </p>
            {error?.stack && (
              <details className="mt-4">
                <summary className="text-sm text-gray-600 dark:text-gray-400 cursor-pointer">
                  Stack trace
                </summary>
                <pre className="mt-2 text-xs text-gray-800 dark:text-gray-300 whitespace-pre-wrap overflow-auto max-h-60">
                  {error.stack}
                </pre>
              </details>
            )}
          </div>
          <button
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
            onClick={() => {
              setHasError(false);
              setError(null);
              window.location.reload();
            }}
          >
            Try again
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
} 