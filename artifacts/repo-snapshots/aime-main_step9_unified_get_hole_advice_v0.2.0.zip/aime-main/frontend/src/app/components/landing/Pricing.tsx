'use client';

import { Check } from "lucide-react";
import { Button } from "@/app/components/ui/button";

interface PricingCardProps {
  title: string;
  price: string;
  description: string;
  features: string[];
  highlighted?: boolean;
  buttonText?: string;
}

function PricingCard({
  title,
  price,
  description,
  features,
  highlighted = false,
  buttonText = "Get Started"
}: PricingCardProps) {
  return (
    <div className={`flex flex-col rounded-lg border ${highlighted ? 'border-green-600 shadow-lg' : 'border-gray-200 shadow-sm'} bg-white`}>
      <div className="p-6">
        <h3 className="text-lg font-semibold">{title}</h3>
        <div className="mt-4 flex items-baseline text-3xl font-bold">
          {price}
          {price !== "Free" && <span className="ml-1 text-sm font-medium text-gray-500">/month</span>}
        </div>
        <p className="mt-2 text-sm text-gray-500">{description}</p>
      </div>
      <div className="flex flex-1 flex-col justify-between p-6 pt-0">
        <div>
          <ul className="space-y-3">
            {features.map((feature, index) => (
              <li key={index} className="flex items-center">
                <Check className="mr-2 h-4 w-4 text-green-600" />
                <span className="text-sm">{feature}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="mt-6">
          <Button
            className={`w-full ${highlighted ? 'bg-green-600 hover:bg-green-700' : ''}`}
            variant={highlighted ? "default" : "outline"}
          >
            {buttonText}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function Pricing() {
  return (
    <section id="pricing" className="py-12 md:py-20 bg-gray-50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
          <div className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium bg-green-50 text-green-700 border-green-200 mb-2">
            <span>Pricing</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Simple, transparent pricing</h2>
          <p className="max-w-[700px] text-gray-500 md:text-lg">
            No hidden fees, no surprises. Choose the plan that works best for you.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3 mt-8">
          <PricingCard
            title="Basic"
            price="Free"
            description="Perfect for individuals just getting started."
            features={[
              "Basic features",
              "1 user",
              "5 projects",
              "2GB storage",
              "Email support"
            ]}
          />
          <PricingCard
            title="Pro"
            price="$29"
            description="Great for professionals and small teams."
            features={[
              "All Basic features",
              "5 users",
              "20 projects",
              "10GB storage",
              "Priority support",
              "Advanced analytics"
            ]}
            highlighted
            buttonText="Try Pro"
          />
          <PricingCard
            title="Enterprise"
            price="$99"
            description="For large teams with advanced needs."
            features={[
              "All Pro features",
              "Unlimited users",
              "Unlimited projects",
              "100GB storage",
              "24/7 dedicated support",
              "Custom integration",
              "Advanced security"
            ]}
          />
        </div>
      </div>
    </section>
  );
} 