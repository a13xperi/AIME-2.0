'use client';

import Link from "next/link";
import { Button } from "@/app/components/ui/button";

export default function CTA() {
  return (
    <section className="py-12 md:py-20 bg-green-600 text-white">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold md:text-4xl mb-4">Ready to get started?</h2>
            <p className="text-lg text-green-50 mb-6 max-w-md">
              Join thousands of users who have already transformed their experience with our platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button size="lg" className="bg-white text-green-600 hover:bg-green-50 h-12 text-base" asChild>
                <Link href="/signup">Sign up now</Link>
              </Button>
              <Button size="lg" variant="outline" className="text-white border-white hover:bg-green-700 h-12 text-base" asChild>
                <Link href="/login">Log in</Link>
              </Button>
            </div>
          </div>
          <div className="hidden md:flex justify-end">
            <div className="relative w-full max-w-[320px] h-[320px] rounded-full bg-green-500 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-green-500 opacity-50 animate-ping" style={{ animationDuration: '3s' }}></div>
              <div className="z-10 text-white text-xl font-bold">Start Today</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
} 