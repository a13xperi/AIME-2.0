import { ChevronDown, ChevronUp, X, Route, Info } from "lucide-react";

export type AdviceData = {
  fetching?: boolean;
  error?: string;
  request_id?: string;
  plan_type?: "TEE_TO_GREEN" | "PUTT" | "ERROR";
  warnings?: string[];
  next_actions?: string[];
  hole_state?: any;
  plan?: any;
};

type Props = {
  show: boolean;
  expanded: boolean;
  isSessionActive: boolean;
  connectionStatus: string;
  data: AdviceData | null;
  onToggle: () => void;
  onClose: () => void;
};

export default function AdvicePanel({
  show,
  expanded,
  isSessionActive,
  connectionStatus,
  data,
  onToggle,
  onClose,
}: Props) {
  if (!show) return null;

  const statusDotClass =
    connectionStatus === "connected" && isSessionActive
      ? "bg-green-500"
      : connectionStatus === "connecting"
        ? "bg-yellow-500"
        : connectionStatus === "error"
          ? "bg-red-500"
          : "bg-gray-400";

  const warnings = data?.warnings ?? [];
  const nextActions = data?.next_actions ?? [];
  const planType = data?.plan_type ?? "ERROR";

  // Best-effort plan rendering
  const puttInstruction =
    planType === "PUTT" ? String(data?.plan?.instruction_text ?? "").trim() : "";
  const teeToGreenMsg =
    planType === "TEE_TO_GREEN"
      ? String(data?.plan?.message ?? data?.plan?.summary ?? "").trim()
      : "";

  const debugDtmId = String(data?.hole_state?.dtm_id ?? "");

  return (
    <div className="absolute left-4 top-4 w-[380px] rounded-xl bg-white shadow-lg border border-gray-200 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <span className={`h-2.5 w-2.5 rounded-full ${statusDotClass}`} />
          <div className="font-semibold text-gray-900">Hole Advice</div>
          <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-700">
            {planType}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onToggle}
            className="p-1 rounded hover:bg-gray-100"
            aria-label={expanded ? "Collapse" : "Expand"}
          >
            {expanded ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-gray-100"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {expanded && (
        <div className="px-4 py-3 space-y-3">
          {/* Status */}
          {data?.fetching && (
            <div className="text-sm text-gray-600">
              Getting advice… (waiting for response)
            </div>
          )}

          {/* Error */}
          {data?.error && (
            <div className="rounded-md bg-red-50 border border-red-200 p-2 text-sm text-red-800">
              {data.error}
            </div>
          )}

          {/* Summary */}
          <div className="rounded-md bg-gray-50 border border-gray-200 p-2">
            <div className="text-sm font-medium text-gray-800 mb-1 flex items-center gap-2">
              <Info size={16} />
              Summary
            </div>
            {planType === "PUTT" ? (
              <div className="text-sm text-gray-900 whitespace-pre-wrap">
                {puttInstruction || "(No instruction returned)"}
              </div>
            ) : planType === "TEE_TO_GREEN" ? (
              <div className="text-sm text-gray-900 whitespace-pre-wrap">
                {teeToGreenMsg || "(No tee-to-green plan available yet)"}
              </div>
            ) : (
              <div className="text-sm text-gray-900">
                (No plan returned)
              </div>
            )}
          </div>

          {/* Warnings */}
          {warnings.length > 0 && (
            <div className="rounded-md bg-yellow-50 border border-yellow-200 p-2 text-sm text-yellow-900">
              <div className="font-medium mb-1">Warnings</div>
              <ul className="list-disc pl-5 space-y-1">
                {warnings.slice(0, 5).map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
              </ul>
              {warnings.length > 5 && (
                <div className="text-xs mt-1 opacity-70">
                  +{warnings.length - 5} more…
                </div>
              )}
            </div>
          )}

          {/* Next actions */}
          {nextActions.length > 0 && (
            <div className="rounded-md bg-blue-50 border border-blue-200 p-2 text-sm text-blue-900">
              <div className="font-medium mb-1 flex items-center gap-2">
                <Route size={16} />
                Next actions
              </div>
              <ul className="list-disc pl-5 space-y-1">
                {nextActions.slice(0, 5).map((a, idx) => (
                  <li key={idx}>{a}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Debug metadata */}
          <div className="text-xs text-gray-600 space-y-1">
            {data?.request_id && (
              <div>
                <span className="font-medium">request_id:</span> {data.request_id}
              </div>
            )}
            {debugDtmId && (
              <div>
                <span className="font-medium">dtm_id:</span> {debugDtmId}
              </div>
            )}
            {data?.hole_state?.surface_state && (
              <div>
                <span className="font-medium">surface_state:</span>{" "}
                {String(data.hole_state.surface_state)}
                {typeof data.hole_state.surface_confidence === "number" ? (
                  <span className="opacity-70">
                    {" "}
                    ({data.hole_state.surface_confidence.toFixed(2)})
                  </span>
                ) : null}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
