import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const backendUrl = process.env.BACKEND_URL || 'http://localhost:8000';
    const body = await request.json();

    const response = await fetch(`${backendUrl}/api/get_hole_advice`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      cache: 'no-store',
    });

    const data = await response.json().catch(() => ({}));
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    console.error('Error proxying get_hole_advice to backend:', error);
    return NextResponse.json(
      {
        error: 'Could not connect to backend server',
        serverStatus: 'unreachable',
      },
      { status: 503 }
    );
  }
}
