#!/usr/bin/env python3
"""Playback harness for the unified /api/get_hole_advice endpoint.

Safe: This does NOT execute any native binaries. It only sends HTTP requests to the running backend.

Usage (example):
  python backend/scripts/playback_get_hole_advice.py \
    --backend-url http://localhost:8000 \
    --course-id riverside --hole-id 1 \
    --sequence backend/scripts/playback_sequence.sample.json \
    --cup-lat 40.268251 --cup-lon -111.659486

The sequence JSON is an array of:
  {"lat": <float>, "lon": <float>, "label": "optional"}
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx


def load_sequence(path: Path) -> List[Dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise ValueError("Sequence file must be a JSON array")
    out: List[Dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict) or "lat" not in item or "lon" not in item:
            raise ValueError("Each item must be an object with lat/lon")
        out.append(item)
    return out


def summarize(result: Dict[str, Any]) -> str:
    plan_type = str(result.get("plan_type", ""))
    hole_state = result.get("hole_state") or {}
    surface_state = str(hole_state.get("surface_state", ""))
    instr = str((result.get("plan") or {}).get("instruction_text", ""))[:80].replace("\n", " ").strip()
    if plan_type == "PUTT" and instr:
        return f"{plan_type} | {surface_state} | instr: {instr}..."
    if plan_type == "TEE_TO_GREEN":
        msg = str((result.get("plan") or {}).get("message", ""))[:80].replace("\n", " ").strip()
        return f"{plan_type} | {surface_state} | msg: {msg}..."
    return f"{plan_type} | {surface_state}"


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--backend-url", default="http://localhost:8000")
    p.add_argument("--course-id", default="riverside")
    p.add_argument("--hole-id", type=int, default=1)
    p.add_argument("--sequence", type=str, required=True)
    p.add_argument("--cup-lat", type=float, default=None)
    p.add_argument("--cup-lon", type=float, default=None)
    p.add_argument("--stimp-ft", type=int, default=None)
    p.add_argument("--stimp-in", type=int, default=None)
    p.add_argument("--timeout-s", type=float, default=3.0)
    args = p.parse_args()

    seq = load_sequence(Path(args.sequence))

    cup = None
    if args.cup_lat is not None and args.cup_lon is not None:
        cup = {"lat": float(args.cup_lat), "lon": float(args.cup_lon)}

    stimp = None
    if args.stimp_ft is not None and args.stimp_in is not None:
        stimp = {"ft": int(args.stimp_ft), "in": int(args.stimp_in)}

    url = args.backend_url.rstrip("/") + "/api/get_hole_advice"

    print(f"→ POST {url}")
    print(f"sequence length: {len(seq)}\n")

    with httpx.Client(timeout=args.timeout_s) as client:
        for i, pos in enumerate(seq):
            payload: Dict[str, Any] = {
                "contract_version": "0.5.0",
                "course_id": args.course_id,
                "hole_id": int(args.hole_id),
                "ball_wgs84": {"lat": float(pos["lat"]), "lon": float(pos["lon"])},
                "want_plot": False,
            }
            if cup is not None:
                payload["cup_wgs84"] = cup
            if stimp is not None:
                payload["stimp"] = stimp

            label = str(pos.get("label", ""))
            r = client.post(url, json=payload)
            try:
                data = r.json()
            except Exception:
                data = {"error": r.text}

            prefix = f"[{i+1}/{len(seq)}]" + (f" {label}" if label else "")
            if r.status_code >= 400:
                print(f"{prefix} ERROR {r.status_code}: {data}")
                continue

            print(f"{prefix} {summarize(data)}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
