from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


def _json_default(o: Any) -> Any:
    """Best-effort JSON serializer for non-JSON-native objects."""
    if o is None:
        return None
    if hasattr(o, "model_dump"):
        try:
            return o.model_dump(by_alias=True)
        except Exception:
            pass
    if hasattr(o, "dict"):
        try:
            return o.dict()
        except Exception:
            pass
    if isinstance(o, Path):
        return str(o)
    return str(o)


def _round_wgs84_point(p: Any, ndigits: int = 6) -> Any:
    """Round lat/lon in debug bundles to reduce precision leakage."""
    if not isinstance(p, dict):
        return p
    if "lat" in p and "lon" in p:
        try:
            return {
                **p,
                "lat": round(float(p["lat"]), ndigits),
                "lon": round(float(p["lon"]), ndigits),
            }
        except Exception:
            return p
    return p


@dataclass
class DebugBundleWriter:
    """Write per-request debug bundles to disk.

    Enable via env (recommended for staging/dev only):
      - DEBUG_BUNDLE_ENABLED=true
      - DEBUG_BUNDLE_DIR=/path/to/dir

    Notes:
    - Bundles may contain sensitive location data. Treat the directory as sensitive.
    - This writer never logs or stores API keys.
    """

    enabled: bool
    dir_path: Path
    max_bytes: int = 1_000_000

    def write(self, request_id: str, bundle: Dict[str, Any]) -> Optional[Path]:
        if not self.enabled:
            return None

        self.dir_path.mkdir(parents=True, exist_ok=True)

        # Add some standard metadata
        bundle = dict(bundle)
        bundle.setdefault("request_id", request_id)
        bundle.setdefault("timestamp_utc", datetime.now(timezone.utc).isoformat())

        # Light sanitization: round WGS84 points (if present)
        try:
            args = bundle.get("args")
            if isinstance(args, dict):
                if "ball_wgs84" in args:
                    args["ball_wgs84"] = _round_wgs84_point(args["ball_wgs84"])
                if "cup_wgs84" in args:
                    args["cup_wgs84"] = _round_wgs84_point(args["cup_wgs84"])
                if "pin_wgs84" in args:
                    args["pin_wgs84"] = _round_wgs84_point(args["pin_wgs84"])
                bundle["args"] = args
        except Exception:
            pass

        path = self.dir_path / f"{request_id}.json"

        text = json.dumps(bundle, indent=2, ensure_ascii=False, default=_json_default)
        raw = text.encode("utf-8")

        # Clamp to max bytes (best-effort) by trimming heavy fields.
        if len(raw) > self.max_bytes:
            try:
                plan = bundle.get("plan")
                if isinstance(plan, dict):
                    plot = plan.get("plot")
                    if isinstance(plot, dict) and isinstance(plot.get("points"), list):
                        pts = plot.get("points") or []
                        plot["points_preview"] = pts[:10]
                        plot["points_count"] = len(pts)
                        plot.pop("points", None)
                        plan["plot"] = plot
                        bundle["plan"] = plan
                text = json.dumps(bundle, indent=2, ensure_ascii=False, default=_json_default)
            except Exception:
                # fall back to original text
                pass

        path.write_text(text, encoding="utf-8")
        return path
