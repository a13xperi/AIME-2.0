"""Debug and observability helpers.

These modules are safe to include in production builds, but most features are
expected to be enabled only in staging/dev (via env vars).
"""
