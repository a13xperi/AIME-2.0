from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import httpx


class PuttSolverClientError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


@dataclass(frozen=True)
class PuttSolverClientConfig:
    base_url: str
    timeout_s: float = 3.0
    # Optional service-to-service auth
    api_key: Optional[str] = None


class PuttSolverClient:
    def __init__(self, cfg: PuttSolverClientConfig) -> None:
        self.cfg = cfg

    def solve_putt(
        self,
        *,
        request_id: str,
        dtm_id: str,
        ball_local: Dict[str, float],
        cup_local: Dict[str, float],
        stimp: Optional[Dict[str, int]] = None,
        want_plot: bool = True,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "request_id": request_id,
            "dtm_id": dtm_id,
            "ball": ball_local,
            "cup": cup_local,
            "want_plot": want_plot,
        }
        if stimp is not None:
            payload["stimp"] = stimp

        url = f"{self.cfg.base_url.rstrip('/')}/solve_putt"

        headers: Dict[str, str] = {}
        if self.cfg.api_key:
            # Do not log this value anywhere
            headers["X-API-Key"] = self.cfg.api_key

        try:
            with httpx.Client(timeout=self.cfg.timeout_s) as client:
                r = client.post(url, json=payload, headers=headers)
                if r.status_code >= 400:
                    raise PuttSolverClientError(
                        f"PuttSolver service error {r.status_code}: {r.text}",
                        status_code=r.status_code,
                    )
                return r.json()
        except httpx.RequestError as e:
            raise PuttSolverClientError(f"Failed to reach PuttSolver service: {e}") from e
