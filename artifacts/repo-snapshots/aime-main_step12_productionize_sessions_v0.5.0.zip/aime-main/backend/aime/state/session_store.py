from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from threading import RLock
from typing import Any, Dict, Optional, Tuple

from aime.models.putt import GeoPointWGS84, Point2D, Stimp


@dataclass
class HoleSession:
    """State for a single hole session.

    This object is intentionally small and JSON-serializable so it can be stored
    in-memory (MVP) or in Redis (Step 12 productionization).

    NOTE: We store both:
      - a stable surface_state, and
      - a candidate streak (surface_candidate_state/count) used for hysteresis.
    """

    session_id: str
    course_id: str
    hole_id: int
    dtm_id: Optional[str] = None
    green_id: Optional[str] = None

    ball_wgs84: Optional[GeoPointWGS84] = None
    cup_wgs84: Optional[GeoPointWGS84] = None
    stimp: Optional[Stimp] = None

    ball_local_green: Optional[Point2D] = None
    cup_local_green: Optional[Point2D] = None

    surface_state: str = "UNKNOWN"
    surface_confidence: Optional[float] = None

    # Hysteresis / debouncing state
    surface_candidate_state: Optional[str] = None
    surface_candidate_count: int = 0

    last_updated_utc: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        def dump_model(m: Any) -> Any:
            if m is None:
                return None
            # Pydantic v2
            if hasattr(m, "model_dump"):
                return m.model_dump(by_alias=True)
            # Pydantic v1
            if hasattr(m, "dict"):
                return m.dict()
            return m

        return {
            "session_id": self.session_id,
            "course_id": self.course_id,
            "hole_id": int(self.hole_id),
            "dtm_id": self.dtm_id,
            "green_id": self.green_id,
            "ball_wgs84": dump_model(self.ball_wgs84),
            "cup_wgs84": dump_model(self.cup_wgs84),
            "stimp": dump_model(self.stimp),
            "ball_local_green": dump_model(self.ball_local_green),
            "cup_local_green": dump_model(self.cup_local_green),
            "surface_state": self.surface_state,
            "surface_confidence": self.surface_confidence,
            "surface_candidate_state": self.surface_candidate_state,
            "surface_candidate_count": int(self.surface_candidate_count),
            "last_updated_utc": self.last_updated_utc.isoformat(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "HoleSession":
        def load_model(model_cls: Any, v: Any) -> Any:
            if v is None:
                return None
            if isinstance(v, model_cls):
                return v
            if isinstance(v, dict):
                try:
                    return model_cls(**v)
                except Exception:
                    return None
            return None

        last_updated_raw = d.get("last_updated_utc")
        last_updated = datetime.now(timezone.utc)
        if isinstance(last_updated_raw, str):
            try:
                # accept either ISO with Z or explicit offset
                last_updated = datetime.fromisoformat(last_updated_raw.replace("Z", "+00:00"))
            except Exception:
                last_updated = datetime.now(timezone.utc)

        return cls(
            session_id=str(d.get("session_id")),
            course_id=str(d.get("course_id")),
            hole_id=int(d.get("hole_id")),
            dtm_id=d.get("dtm_id"),
            green_id=d.get("green_id"),
            ball_wgs84=load_model(GeoPointWGS84, d.get("ball_wgs84")),
            cup_wgs84=load_model(GeoPointWGS84, d.get("cup_wgs84")),
            stimp=load_model(Stimp, d.get("stimp")),
            ball_local_green=load_model(Point2D, d.get("ball_local_green")),
            cup_local_green=load_model(Point2D, d.get("cup_local_green")),
            surface_state=str(d.get("surface_state", "UNKNOWN")),
            surface_confidence=d.get("surface_confidence"),
            surface_candidate_state=d.get("surface_candidate_state"),
            surface_candidate_count=int(d.get("surface_candidate_count", 0)),
            last_updated_utc=last_updated,
        )


class SessionStoreError(RuntimeError):
    pass


class SessionStore:
    """In-memory hole session store.

    This is the default backend for local development and for environments
    where Redis is not configured.
    """

    def __init__(self, ttl_seconds: int = 2 * 60 * 60) -> None:
        self._ttl = timedelta(seconds=int(ttl_seconds))
        self._lock = RLock()
        self._sessions: Dict[str, HoleSession] = {}

    def _prune_locked(self) -> None:
        now = datetime.now(timezone.utc)
        expired = [sid for sid, s in self._sessions.items() if (now - s.last_updated_utc) > self._ttl]
        for sid in expired:
            self._sessions.pop(sid, None)

    def create(self, session: HoleSession) -> None:
        with self._lock:
            self._prune_locked()
            self._sessions[session.session_id] = session

    def get(self, session_id: str) -> HoleSession:
        with self._lock:
            self._prune_locked()
            if session_id not in self._sessions:
                raise SessionStoreError(f"Unknown or expired session_id: {session_id}")
            return self._sessions[session_id]

    def update(self, session: HoleSession) -> None:
        with self._lock:
            self._sessions[session.session_id] = session

    def touch(self, session_id: str) -> None:
        with self._lock:
            s = self.get(session_id)
            s.last_updated_utc = datetime.now(timezone.utc)
            self._sessions[session_id] = s

    def delete(self, session_id: str) -> None:
        with self._lock:
            self._sessions.pop(session_id, None)

    def count(self) -> int:
        with self._lock:
            self._prune_locked()
            return len(self._sessions)


class RedisSessionStore:
    """Redis-backed session store.

    Requirements:
    - `redis` python package installed
    - a reachable Redis instance

    This store uses per-session keys with TTL.
    """

    def __init__(
        self,
        *,
        redis_url: str,
        ttl_seconds: int,
        key_prefix: str = "aime:hole_session",
    ) -> None:
        try:
            import redis  # type: ignore
        except Exception as e:
            raise SessionStoreError("redis-py not installed; add `redis` to requirements") from e

        self._redis = redis.Redis.from_url(str(redis_url), decode_responses=True)
        self._ttl_seconds = int(ttl_seconds)
        self._prefix = str(key_prefix)

    def _key(self, session_id: str) -> str:
        return f"{self._prefix}:{session_id}"

    def ping(self) -> bool:
        try:
            return bool(self._redis.ping())
        except Exception as e:
            raise SessionStoreError(f"Redis ping failed: {e}") from e

    def create(self, session: HoleSession) -> None:
        key = self._key(session.session_id)
        payload = json.dumps(session.to_dict(), ensure_ascii=False)
        try:
            self._redis.setex(key, self._ttl_seconds, payload)
        except Exception as e:
            raise SessionStoreError(f"Redis write failed: {e}") from e

    def get(self, session_id: str) -> HoleSession:
        key = self._key(session_id)
        try:
            raw = self._redis.get(key)
        except Exception as e:
            raise SessionStoreError(f"Redis read failed: {e}") from e
        if raw is None:
            raise SessionStoreError(f"Unknown or expired session_id: {session_id}")
        try:
            return HoleSession.from_dict(json.loads(raw))
        except Exception as e:
            raise SessionStoreError(f"Corrupt session payload in Redis for {session_id}: {e}") from e

    def update(self, session: HoleSession) -> None:
        # refresh TTL on update
        self.create(session)

    def touch(self, session_id: str) -> None:
        s = self.get(session_id)
        s.last_updated_utc = datetime.now(timezone.utc)
        self.update(s)

    def delete(self, session_id: str) -> None:
        key = self._key(session_id)
        try:
            self._redis.delete(key)
        except Exception:
            # best-effort
            return

    def count(self) -> int:
        # NOTE: SCAN is O(N); this is for debug only.
        try:
            n = 0
            for _ in self._redis.scan_iter(match=f"{self._prefix}:*"):
                n += 1
            return n
        except Exception as e:
            raise SessionStoreError(f"Redis count failed: {e}") from e


def build_session_store(ttl_seconds: int) -> Tuple[Any, Dict[str, Any]]:
    """Factory: choose a session store backend from environment.

    Env:
      - SESSION_STORE_BACKEND: 'memory' (default) or 'redis'
      - REDIS_URL: e.g. redis://localhost:6379/0
      - REDIS_SESSION_PREFIX: optional key prefix

    Returns: (store, meta)
    """
    backend = os.getenv("SESSION_STORE_BACKEND", "memory").strip().lower()
    redis_url = os.getenv("REDIS_URL", "").strip() or None
    prefix = os.getenv("REDIS_SESSION_PREFIX", "aime:hole_session").strip() or "aime:hole_session"

    # If REDIS_URL is set, we treat it as an opt-in to Redis unless explicitly forced to memory.
    wants_redis = backend == "redis" or (redis_url is not None and backend != "memory")

    if wants_redis:
        try:
            url = redis_url or "redis://localhost:6379/0"
            store = RedisSessionStore(redis_url=url, ttl_seconds=int(ttl_seconds), key_prefix=prefix)
            meta = {
                "backend": "redis",
                "redis_url": url,
                "key_prefix": prefix,
                "ttl_seconds": int(ttl_seconds),
            }
            return store, meta
        except Exception as e:
            # Fall back safely to memory
            store = SessionStore(ttl_seconds=int(ttl_seconds))
            meta = {
                "backend": "memory",
                "ttl_seconds": int(ttl_seconds),
                "warning": f"Redis session store unavailable; falling back to memory: {e}",
            }
            return store, meta

    store = SessionStore(ttl_seconds=int(ttl_seconds))
    meta = {"backend": "memory", "ttl_seconds": int(ttl_seconds)}
    return store, meta
