from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from .green_mask import mask_status_at_xy, GridLoadError


DEFAULT_UNKNOWN_MARGIN_M = 0.50
DEFAULT_COMMIT_ON_STREAK = 2
DEFAULT_COMMIT_OFF_STREAK = 2


def classify_surface_state(
    ball_x_m: float,
    ball_y_m: float,
    manifest: Dict[str, Any],
    grid_path: Optional[str] = None,
    unknown_margin_m: float = DEFAULT_UNKNOWN_MARGIN_M,
) -> Tuple[str, float, List[str]]:
    """Classify whether the ball is on the green.

    Priority order (most reliable first):
    1) No-data mask check (grid cell validity) if grid_path is provided and grid is readable.
    2) Manifest extents check.
    3) Near-boundary UNKNOWN to avoid flicker when conventions are uncertain.

    Returns: (surface_state, confidence, warnings)
    """
    warnings: List[str] = []

    ext = (manifest.get("extents_m") or {})
    x_max = float(ext.get("x_max_m", 0.0))
    y_max = float(ext.get("y_max_m", 0.0))

    inside_extents = (0.0 <= ball_x_m <= x_max) and (0.0 <= ball_y_m <= y_max)
    near_extents = (
        (-unknown_margin_m <= ball_x_m <= x_max + unknown_margin_m)
        and (-unknown_margin_m <= ball_y_m <= y_max + unknown_margin_m)
    )

    # If we can use the grid mask, it improves confidence inside extents.
    if grid_path and inside_extents:
        try:
            is_valid, has_neighbor, grid_warnings = mask_status_at_xy(ball_x_m, ball_y_m, manifest, grid_path)
            warnings += grid_warnings

            if is_valid:
                return ("ON_GREEN", 0.97, warnings)

            # If the cell is no-data but a neighbor is valid, treat as UNKNOWN (boundary / discretization)
            if has_neighbor:
                warnings.append("ball maps to a no-data cell but neighbors contain valid cells; treating as UNKNOWN")
                return ("UNKNOWN", 0.60, warnings)

            # Inside extents but in a no-data region → OFF_GREEN (likely fringe/outside boundary)
            warnings.append("ball inside extents but maps to no-data region; treating as OFF_GREEN")
            return ("OFF_GREEN", 0.85, warnings)

        except GridLoadError as e:
            warnings.append(f"grid mask unavailable: {e}")

    # Fallback: extents-only
    if inside_extents:
        warnings.append("surface classification using extents only (grid mask unavailable)")
        return ("ON_GREEN", 0.90, warnings)

    if near_extents:
        warnings.append("ball near extents boundary; surface_state set to UNKNOWN to avoid flicker")
        return ("UNKNOWN", 0.50, warnings)

    return ("OFF_GREEN", 0.95, warnings)


def apply_surface_hysteresis(
    *,
    prev_state: str,
    prev_confidence: Optional[float],
    candidate_state: str,
    candidate_confidence: float,
    candidate_prev_state: Optional[str],
    candidate_count: int,
    commit_on_streak: int = DEFAULT_COMMIT_ON_STREAK,
    commit_off_streak: int = DEFAULT_COMMIT_OFF_STREAK,
) -> Tuple[str, float, Optional[str], int, List[str]]:
    """Debounce surface state transitions to reduce flicker.

    We keep a small "candidate streak" state:
      - candidate_prev_state
      - candidate_count

    Rule of thumb:
      - If the candidate matches the stable state: accept immediately.
      - If candidate is UNKNOWN: hold stable state.
      - If candidate flips stable ON↔OFF: require N consecutive observations.

    Returns: (stable_state, stable_confidence, new_candidate_state, new_candidate_count, warnings)
    """
    warnings: List[str] = []

    # Update candidate streak
    if candidate_state == candidate_prev_state:
        candidate_count = int(candidate_count) + 1
    else:
        candidate_prev_state = candidate_state
        candidate_count = 1

    # If we had no stable state yet, adopt candidate immediately.
    if not prev_state or prev_state == "UNKNOWN":
        return candidate_state, float(candidate_confidence), candidate_prev_state, candidate_count, warnings

    # If candidate agrees with stable state, accept immediately.
    if candidate_state == prev_state:
        return prev_state, float(candidate_confidence), candidate_prev_state, candidate_count, warnings

    # Candidate is UNKNOWN → hold previous
    if candidate_state == "UNKNOWN":
        conf = min(float(prev_confidence or 0.80), float(candidate_confidence))
        warnings.append("hysteresis: candidate surface_state=UNKNOWN; holding previous surface_state")
        return prev_state, conf, candidate_prev_state, candidate_count, warnings

    # Candidate differs and is not UNKNOWN.
    if candidate_state == "ON_GREEN":
        required = max(1, int(commit_on_streak))
    elif candidate_state == "OFF_GREEN":
        required = max(1, int(commit_off_streak))
    else:
        required = 2

    if candidate_count >= required:
        warnings.append(
            f"hysteresis: switched surface_state {prev_state}→{candidate_state} after {candidate_count} consistent observations"
        )
        return candidate_state, float(candidate_confidence), candidate_prev_state, candidate_count, warnings

    warnings.append(
        f"hysteresis: candidate {candidate_state} observed {candidate_count}/{required}; holding {prev_state}"
    )

    # Keep previous confidence if present; otherwise provide a conservative default.
    conf_out = float(prev_confidence) if prev_confidence is not None else 0.60
    return prev_state, conf_out, candidate_prev_state, candidate_count, warnings
