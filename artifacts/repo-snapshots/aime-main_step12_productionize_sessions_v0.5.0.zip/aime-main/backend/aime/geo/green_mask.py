from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Tuple


class GridLoadError(RuntimeError):
    pass


@lru_cache(maxsize=32)
def load_grid_values(grid_path_str: str) -> Tuple[Tuple[float, ...], ...]:
    """Load a tab-delimited DTM grid into an immutable tuple-of-tuples.

    Safe / static: this reads a text file and parses floats. No code execution.
    """
    grid_path = Path(grid_path_str)
    if not grid_path.exists():
        raise GridLoadError(f"Grid file not found: {grid_path}")

    rows: List[Tuple[float, ...]] = []
    with grid_path.open("r", encoding="utf-8", errors="replace") as f:
        for line_no, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            parts = line.split("\t")
            try:
                vals = tuple(float(p) for p in parts)
            except Exception as e:
                raise GridLoadError(f"Failed to parse float on line {line_no}: {e}") from e
            rows.append(vals)

    if not rows:
        raise GridLoadError(f"Empty grid file: {grid_path}")

    # Validate consistent column counts
    ncols = len(rows[0])
    for i, r in enumerate(rows, start=1):
        if len(r) != ncols:
            raise GridLoadError(f"Inconsistent column count at row {i}: expected {ncols}, got {len(r)}")

    return tuple(rows)


def _index_from_xy(
    x_m: float,
    y_m: float,
    spacing_m: float,
    rows: int,
    cols: int,
    axis_mapping: str,
) -> Tuple[int, int]:
    """Map (x_m, y_m) to (row_idx, col_idx) based on a mapping hint.

    axis_mapping:
      - "x_row_y_col" (default): row = x/spacing, col = y/spacing
      - "x_col_y_row": row = y/spacing, col = x/spacing

    NOTE: This is a *convention choice* and must match the DLL's expectation.
    """
    if spacing_m <= 0:
        return (0, 0)

    if axis_mapping == "x_col_y_row":
        row = int(y_m / spacing_m)
        col = int(x_m / spacing_m)
    else:
        row = int(x_m / spacing_m)
        col = int(y_m / spacing_m)

    # Clamp into valid index range to avoid IndexErrors at the boundary
    row = max(0, min(rows - 1, row))
    col = max(0, min(cols - 1, col))
    return (row, col)


def mask_status_at_xy(
    x_m: float,
    y_m: float,
    manifest: Dict[str, Any],
    grid_path_str: str,
    neighbor_radius_cells: int = 1,
) -> Tuple[bool, bool, List[str]]:
    """Return (is_valid_cell, has_valid_neighbor, warnings).

    - is_valid_cell: the mapped cell is not no-data
    - has_valid_neighbor: a nearby cell (within radius) is valid (helps handle discretization)
    """
    warnings: List[str] = []
    grid_meta = manifest.get("grid") or {}
    spacing_m = float(grid_meta.get("spacing_m", 0.0))
    rows_exp = int(grid_meta.get("rows", 0))
    cols_exp = int(grid_meta.get("cols", 0))
    no_data = float(grid_meta.get("no_data_value", -1.0))
    axis_mapping = str(grid_meta.get("axis_mapping", "x_row_y_col"))

    grid = load_grid_values(grid_path_str)

    # Dimensions: trust file, warn if manifest disagrees
    rows = len(grid)
    cols = len(grid[0]) if rows else 0
    if rows_exp and rows != rows_exp:
        warnings.append(f"grid rows mismatch: manifest={rows_exp}, file={rows}")
    if cols_exp and cols != cols_exp:
        warnings.append(f"grid cols mismatch: manifest={cols_exp}, file={cols}")

    row_idx, col_idx = _index_from_xy(x_m, y_m, spacing_m, rows, cols, axis_mapping)
    v = grid[row_idx][col_idx]
    is_valid = (v != no_data)

    # If the mapped cell is no-data, check a small neighborhood for a valid cell
    has_neighbor = False
    if not is_valid and neighbor_radius_cells > 0:
        r0 = max(0, row_idx - neighbor_radius_cells)
        r1 = min(rows - 1, row_idx + neighbor_radius_cells)
        c0 = max(0, col_idx - neighbor_radius_cells)
        c1 = min(cols - 1, col_idx + neighbor_radius_cells)
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if grid[r][c] != no_data:
                    has_neighbor = True
                    break
            if has_neighbor:
                break

    return (is_valid, has_neighbor, warnings)
