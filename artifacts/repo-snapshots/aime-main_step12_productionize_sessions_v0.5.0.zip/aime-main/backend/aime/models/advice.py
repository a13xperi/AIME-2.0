from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field, ConfigDict

from .putt import GeoPointWGS84, Point2D, Stimp, PlotData, RawData


SurfaceState = Literal["OFF_GREEN", "ON_GREEN", "UNKNOWN", "TRANSITION"]
PlanType = Literal["TEE_TO_GREEN", "PUTT", "ERROR"]


class HoleStateSnapshot(BaseModel):
    contract_version: str = "0.5.0"
    session_id: Optional[str] = None
    course_id: str
    hole_id: int
    dtm_id: Optional[str] = None
    green_id: Optional[str] = None

    ball_wgs84: Optional[GeoPointWGS84] = None
    cup_wgs84: Optional[GeoPointWGS84] = None

    ball_local_green: Optional[Point2D] = None
    cup_local_green: Optional[Point2D] = None

    surface_state: SurfaceState = "UNKNOWN"
    surface_confidence: Optional[float] = Field(default=None, ge=0.0, le=1.0)

    green_frame: Optional[Dict[str, Any]] = None
    warnings: List[str] = Field(default_factory=list)


class GetHoleAdviceArgs(BaseModel):
    """Args for the unified router tool (frontend → backend)."""
    contract_version: str = "0.5.0"
    session_id: Optional[str] = None
    course_id: Optional[str] = None
    hole_id: Optional[int] = None
    ball_wgs84: Optional[GeoPointWGS84] = None
    cup_wgs84: Optional[GeoPointWGS84] = None
    stimp: Optional[Stimp] = None
    want_plot: bool = True
    request_id: Optional[str] = None

    model_config = ConfigDict(populate_by_name=True)


class GetHoleAdvicePlanPutt(BaseModel):
    instruction_text: str = ""
    plot: Optional[PlotData] = None
    raw: Optional[RawData] = None


class GetHoleAdvicePlanTeeToGreen(BaseModel):
    summary: str
    recommended_club: Optional[str] = None
    carry_m: Optional[float] = None
    total_m: Optional[float] = None
    bearing_deg: Optional[float] = None
    target_wgs84: Optional[GeoPointWGS84] = None
    confidence: Optional[float] = None
    debug: Optional[Dict[str, Any]] = None


class GetHoleAdviceResult(BaseModel):
    contract_version: str = "0.5.0"
    request_id: str
    plan_type: PlanType
    hole_state: HoleStateSnapshot
    plan: Dict[str, Any] = Field(default_factory=dict)
    warnings: List[str] = Field(default_factory=list)
    next_actions: List[str] = Field(default_factory=list)
    error: Optional[str] = None
