from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, Field, ConfigDict

from .putt import GeoPointWGS84, Stimp
from .advice import HoleStateSnapshot


class StartHoleSessionArgs(BaseModel):
    """Create a hole session so clients can stream ball/cup updates without re-sending full payloads."""
    contract_version: str = "0.5.0"
    course_id: str
    hole_id: int
    ball_wgs84: Optional[GeoPointWGS84] = None
    cup_wgs84: Optional[GeoPointWGS84] = None
    stimp: Optional[Stimp] = None
    request_id: Optional[str] = None

    model_config = ConfigDict(populate_by_name=True)


class StartHoleSessionResult(BaseModel):
    contract_version: str = "0.5.0"
    request_id: str
    session_id: str
    hole_state: HoleStateSnapshot
    warnings: List[str] = Field(default_factory=list)


class SetBallLocationArgs(BaseModel):
    contract_version: str = "0.5.0"
    session_id: str
    ball_wgs84: GeoPointWGS84
    request_id: Optional[str] = None

    model_config = ConfigDict(populate_by_name=True)


class SetCupLocationArgs(BaseModel):
    contract_version: str = "0.5.0"
    session_id: str
    cup_wgs84: GeoPointWGS84
    request_id: Optional[str] = None

    model_config = ConfigDict(populate_by_name=True)


class SetLocationResult(BaseModel):
    contract_version: str = "0.5.0"
    request_id: str
    session_id: str
    hole_state: HoleStateSnapshot
    warnings: List[str] = Field(default_factory=list)
