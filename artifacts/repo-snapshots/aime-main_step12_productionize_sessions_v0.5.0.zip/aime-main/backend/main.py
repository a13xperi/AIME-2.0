from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware

import os
import time
from dotenv import load_dotenv
from typing import Dict, Any, List, Optional
from datetime import datetime
from pathlib import Path
import uuid

from aime.data.datasets import DatasetRegistry, DatasetRegistryError
from aime.geo.transforms import wgs84_to_green_local_m, bounds_warnings, TransformError
from aime.clients.putt_solver_client import PuttSolverClient, PuttSolverClientConfig, PuttSolverClientError
from aime.clients.tee_to_green_client import TeeToGreenClient, TeeToGreenClientConfig, TeeToGreenClientError
from aime.models.putt import SolvePuttArgs, SolvePuttResult, Point2D, PlotData, RawData
from aime.models.advice import GetHoleAdviceArgs, GetHoleAdviceResult, HoleStateSnapshot
from aime.geo.surface import classify_surface_state, apply_surface_hysteresis
from aime.state.session_store import build_session_store, HoleSession, SessionStoreError
from aime.models.session import (
    StartHoleSessionArgs, StartHoleSessionResult,
    SetBallLocationArgs, SetCupLocationArgs, SetLocationResult,
)
from aime.debug.bundles import DebugBundleWriter


# Load environment variables
load_dotenv()

# Configuration from environment variables
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:3000")
DEBUG = os.getenv("DEBUG", "True").lower() in ("true", "1", "t")

# Repo root
REPO_ROOT = Path(__file__).resolve().parent.parent  # aime-main/

# Dataset registry paths
COURSE_DATA_ROOT = Path(os.getenv('COURSE_DATA_ROOT', str(REPO_ROOT / 'course_data'))).resolve()
DATASET_REGISTRY_PATH = Path(os.getenv('DATASET_REGISTRY_PATH', str(COURSE_DATA_ROOT / 'datasets.json'))).resolve()

# Putt solver service config
PUTT_SOLVER_URL = os.getenv('PUTT_SOLVER_URL', 'http://localhost:7071')
PUTT_SOLVER_TIMEOUT_S = float(os.getenv('PUTT_SOLVER_TIMEOUT_S', '3.0'))
PUTT_SOLVER_API_KEY = os.getenv('PUTT_SOLVER_API_KEY') or None

# Tee-to-green service config (optional)
TEE_TO_GREEN_URL = os.getenv('TEE_TO_GREEN_URL', '')
TEE_TO_GREEN_TIMEOUT_S = float(os.getenv('TEE_TO_GREEN_TIMEOUT_S', '3.0'))
TEE_TO_GREEN_API_KEY = os.getenv('TEE_TO_GREEN_API_KEY') or None

# Surface classification tuning
UNKNOWN_MARGIN_M = float(os.getenv('UNKNOWN_MARGIN_M', '1.0'))
SURFACE_COMMIT_ON_STREAK = int(os.getenv('SURFACE_COMMIT_ON_STREAK', '2'))
SURFACE_COMMIT_OFF_STREAK = int(os.getenv('SURFACE_COMMIT_OFF_STREAK', '2'))

# Session store
SESSION_TTL_S = int(os.getenv('SESSION_TTL_S', '7200'))

# Debug bundle
DEBUG_BUNDLE_ENABLED = os.getenv('DEBUG_BUNDLE_ENABLED', 'false').lower() in ('true', '1', 't')
DEBUG_BUNDLE_DIR = Path(os.getenv('DEBUG_BUNDLE_DIR', str(REPO_ROOT / 'backend' / 'debug_bundles'))).resolve()


# Initialize dataset registry + solver clients (loaded once at startup)
dataset_registry = DatasetRegistry(COURSE_DATA_ROOT, DATASET_REGISTRY_PATH)
try:
    dataset_registry.load()
except Exception as e:
    # Avoid crashing import; surface error via /health endpoint
    dataset_registry_error = str(e)
else:
    dataset_registry_error = None

putt_client = PuttSolverClient(
    PuttSolverClientConfig(
        base_url=PUTT_SOLVER_URL,
        timeout_s=PUTT_SOLVER_TIMEOUT_S,
        api_key=PUTT_SOLVER_API_KEY,
    )
)

tee_client = None
if TEE_TO_GREEN_URL:
    tee_client = TeeToGreenClient(
        TeeToGreenClientConfig(
            base_url=TEE_TO_GREEN_URL,
            timeout_s=TEE_TO_GREEN_TIMEOUT_S,
            api_key=TEE_TO_GREEN_API_KEY,
        )
    )

# Session store factory (memory by default; Redis if configured)
session_store, session_store_meta = build_session_store(ttl_seconds=SESSION_TTL_S)

# Debug bundle writer
bundle_writer = DebugBundleWriter(enabled=DEBUG_BUNDLE_ENABLED, dir_path=DEBUG_BUNDLE_DIR)


app = FastAPI(
    title="AIME API",
    description="Backend API for AIME integration",
    version="0.5.0",
    debug=DEBUG
)

# Configure CORS to allow requests from the frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_URL],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def read_root() -> Dict[str, Any]:
    return {
        "status": "ok",
        "message": "Backend API is running",
        "version": app.version,
        "environment": "development" if DEBUG else "production",
    }


@app.get("/health")
def health() -> Dict[str, Any]:
    """Health endpoint for orchestration / deployments."""
    status = "ok"

    # Dataset registry
    registry_ok = dataset_registry_error is None
    dataset_count = 0
    if registry_ok:
        try:
            dataset_count = len(dataset_registry.list())
        except Exception:
            dataset_count = 0

    # Session store backend
    store_meta = dict(session_store_meta)
    if store_meta.get("backend") == "redis" and hasattr(session_store, "ping"):
        try:
            store_meta["redis_ping"] = bool(session_store.ping())
        except Exception as e:
            store_meta["redis_ping"] = False
            store_meta["redis_ping_error"] = str(e)
            status = "degraded"

    return {
        "status": status if registry_ok else "degraded",
        "version": app.version,
        "dataset_registry_loaded": registry_ok,
        "dataset_registry_error": dataset_registry_error,
        "dataset_count": dataset_count,
        "session_store": store_meta,
        "services": {
            "putt_solver": {
                "base_url": PUTT_SOLVER_URL,
                "api_key_configured": bool(PUTT_SOLVER_API_KEY),
            },
            "tee_to_green": {
                "enabled": bool(TEE_TO_GREEN_URL),
                "base_url": TEE_TO_GREEN_URL,
                "api_key_configured": bool(TEE_TO_GREEN_API_KEY),
            },
        },
        "debug_bundle": {
            "enabled": DEBUG_BUNDLE_ENABLED,
            "dir": str(DEBUG_BUNDLE_DIR),
        },
    }


@app.get("/api/status")
def get_status() -> Dict[str, Any]:
    return {
        "authenticated": True,
        "serverTime": datetime.now().isoformat(),
        "serverStatus": "operational" if dataset_registry_error is None else "degraded",
    }


@app.get('/api/datasets')
def list_registered_datasets() -> Dict[str, Any]:
    """List allowlisted datasets (debug/scaffold)."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    out = []
    for rec in dataset_registry.list():
        out.append({
            'dtm_id': rec.dtm_id,
            'course_id': rec.course_id,
            'hole_id': rec.hole_id,
            'green_id': rec.green_id,
            'manifest_path': str(rec.manifest_path),
        })
    return {'datasets': out}


@app.post('/api/session/start', response_model=StartHoleSessionResult)
def start_hole_session(args: StartHoleSessionArgs) -> StartHoleSessionResult:
    """Start a stateful hole session.

    Clients can then call set_ball_location / set_cup_location with only session_id.
    """
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    request_id = args.request_id or str(uuid.uuid4())
    warnings: List[str] = []

    try:
        rec = dataset_registry.get_by_course_hole(args.course_id, int(args.hole_id))
        manifest = dataset_registry.load_manifest(rec)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    session_id = str(uuid.uuid4())

    sess = HoleSession(
        session_id=session_id,
        course_id=args.course_id,
        hole_id=int(args.hole_id),
        dtm_id=rec.dtm_id,
        green_id=rec.green_id,
        ball_wgs84=args.ball_wgs84,
        cup_wgs84=args.cup_wgs84,
        stimp=args.stimp,
    )

    # Best-effort local transforms if we have positions
    if args.ball_wgs84 is not None:
        try:
            bx, by = wgs84_to_green_local_m(args.ball_wgs84.lat, args.ball_wgs84.lon, manifest)
            sess.ball_local_green = Point2D(x_m=float(bx), y_m=float(by))

            cand_state, cand_conf, sw = classify_surface_state(
                bx, by,
                manifest,
                grid_path=str(rec.grid_path),
                unknown_margin_m=UNKNOWN_MARGIN_M,
            )
            stable_state, stable_conf, cs, cc, hw = apply_surface_hysteresis(
                prev_state=sess.surface_state,
                prev_confidence=sess.surface_confidence,
                candidate_state=cand_state,
                candidate_confidence=cand_conf,
                candidate_prev_state=sess.surface_candidate_state,
                candidate_count=sess.surface_candidate_count,
                commit_on_streak=SURFACE_COMMIT_ON_STREAK,
                commit_off_streak=SURFACE_COMMIT_OFF_STREAK,
            )
            sess.surface_state = stable_state
            sess.surface_confidence = stable_conf
            sess.surface_candidate_state = cs
            sess.surface_candidate_count = cc
            warnings += sw + hw
        except TransformError as e:
            warnings.append(f'ball transform failed: {e}')

    if args.cup_wgs84 is not None:
        try:
            cx, cy = wgs84_to_green_local_m(args.cup_wgs84.lat, args.cup_wgs84.lon, manifest)
            sess.cup_local_green = Point2D(x_m=float(cx), y_m=float(cy))
        except TransformError as e:
            warnings.append(f'cup transform failed: {e}')

    session_store.create(sess)

    hole_state = HoleStateSnapshot(
        session_id=session_id,
        course_id=args.course_id,
        hole_id=int(args.hole_id),
        dtm_id=rec.dtm_id,
        green_id=rec.green_id,
        ball_wgs84=args.ball_wgs84,
        cup_wgs84=args.cup_wgs84,
        ball_local_green=sess.ball_local_green,
        cup_local_green=sess.cup_local_green,
        surface_state=sess.surface_state,  # type: ignore
        surface_confidence=sess.surface_confidence,
        green_frame={
            'frame': 'green_local_m',
            'extents_m': (manifest.get('extents_m') or {}),
            'grid': (manifest.get('grid') or {}),
        },
        warnings=warnings,
    )

    return StartHoleSessionResult(
        request_id=request_id,
        session_id=session_id,
        hole_state=hole_state,
        warnings=warnings,
    )


@app.post('/api/session/set_ball_location', response_model=SetLocationResult)
def set_ball_location(args: SetBallLocationArgs) -> SetLocationResult:
    """Update the ball location for an existing session."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    request_id = args.request_id or str(uuid.uuid4())
    warnings: List[str] = []

    try:
        sess = session_store.get(args.session_id)
    except SessionStoreError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    try:
        rec = dataset_registry.get_by_course_hole(sess.course_id, int(sess.hole_id))
        manifest = dataset_registry.load_manifest(rec)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    sess.ball_wgs84 = args.ball_wgs84

    try:
        bx, by = wgs84_to_green_local_m(args.ball_wgs84.lat, args.ball_wgs84.lon, manifest)
        sess.ball_local_green = Point2D(x_m=float(bx), y_m=float(by))

        cand_state, cand_conf, sw = classify_surface_state(
            bx, by,
            manifest,
            grid_path=str(rec.grid_path),
            unknown_margin_m=UNKNOWN_MARGIN_M,
        )
        stable_state, stable_conf, cs, cc, hw = apply_surface_hysteresis(
            prev_state=sess.surface_state,
            prev_confidence=sess.surface_confidence,
            candidate_state=cand_state,
            candidate_confidence=cand_conf,
            candidate_prev_state=sess.surface_candidate_state,
            candidate_count=sess.surface_candidate_count,
            commit_on_streak=SURFACE_COMMIT_ON_STREAK,
            commit_off_streak=SURFACE_COMMIT_OFF_STREAK,
        )
        sess.surface_state = stable_state
        sess.surface_confidence = stable_conf
        sess.surface_candidate_state = cs
        sess.surface_candidate_count = cc
        warnings += sw + hw

    except TransformError as e:
        warnings.append(f'ball transform failed: {e}')

    session_store.update(sess)

    hole_state = HoleStateSnapshot(
        session_id=sess.session_id,
        course_id=sess.course_id,
        hole_id=int(sess.hole_id),
        dtm_id=rec.dtm_id,
        green_id=rec.green_id,
        ball_wgs84=sess.ball_wgs84,
        cup_wgs84=sess.cup_wgs84,
        ball_local_green=sess.ball_local_green,
        cup_local_green=sess.cup_local_green,
        surface_state=sess.surface_state,  # type: ignore
        surface_confidence=sess.surface_confidence,
        green_frame={
            'frame': 'green_local_m',
            'extents_m': (manifest.get('extents_m') or {}),
            'grid': (manifest.get('grid') or {}),
        },
        warnings=warnings,
    )

    return SetLocationResult(
        request_id=request_id,
        session_id=sess.session_id,
        hole_state=hole_state,
        warnings=warnings,
    )


@app.post('/api/session/set_cup_location', response_model=SetLocationResult)
def set_cup_location(args: SetCupLocationArgs) -> SetLocationResult:
    """Update the cup/pin location for an existing session."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    request_id = args.request_id or str(uuid.uuid4())
    warnings: List[str] = []

    try:
        sess = session_store.get(args.session_id)
    except SessionStoreError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    try:
        rec = dataset_registry.get_by_course_hole(sess.course_id, int(sess.hole_id))
        manifest = dataset_registry.load_manifest(rec)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    sess.cup_wgs84 = args.cup_wgs84

    try:
        cx, cy = wgs84_to_green_local_m(args.cup_wgs84.lat, args.cup_wgs84.lon, manifest)
        sess.cup_local_green = Point2D(x_m=float(cx), y_m=float(cy))
    except TransformError as e:
        warnings.append(f'cup transform failed: {e}')

    session_store.update(sess)

    hole_state = HoleStateSnapshot(
        session_id=sess.session_id,
        course_id=sess.course_id,
        hole_id=int(sess.hole_id),
        dtm_id=rec.dtm_id,
        green_id=rec.green_id,
        ball_wgs84=sess.ball_wgs84,
        cup_wgs84=sess.cup_wgs84,
        ball_local_green=sess.ball_local_green,
        cup_local_green=sess.cup_local_green,
        surface_state=sess.surface_state,  # type: ignore
        surface_confidence=sess.surface_confidence,
        green_frame={
            'frame': 'green_local_m',
            'extents_m': (manifest.get('extents_m') or {}),
            'grid': (manifest.get('grid') or {}),
        },
        warnings=warnings,
    )

    return SetLocationResult(
        request_id=request_id,
        session_id=sess.session_id,
        hole_state=hole_state,
        warnings=warnings,
    )


@app.get('/api/session/{session_id}', response_model=HoleStateSnapshot)
def get_session_state(session_id: str) -> HoleStateSnapshot:
    """Fetch current session state."""
    try:
        sess = session_store.get(session_id)
    except SessionStoreError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    # Load dataset for metadata (best-effort)
    try:
        rec = dataset_registry.get_by_course_hole(sess.course_id, int(sess.hole_id))
        manifest = dataset_registry.load_manifest(rec)
    except Exception:
        rec = None
        manifest = {}

    return HoleStateSnapshot(
        session_id=sess.session_id,
        course_id=sess.course_id,
        hole_id=int(sess.hole_id),
        dtm_id=(rec.dtm_id if rec else sess.dtm_id),
        green_id=(rec.green_id if rec else sess.green_id),
        ball_wgs84=sess.ball_wgs84,
        cup_wgs84=sess.cup_wgs84,
        ball_local_green=sess.ball_local_green,
        cup_local_green=sess.cup_local_green,
        surface_state=sess.surface_state,  # type: ignore
        surface_confidence=sess.surface_confidence,
        green_frame={
            'frame': 'green_local_m',
            'extents_m': (manifest.get('extents_m') or {}),
            'grid': (manifest.get('grid') or {}),
        } if manifest else None,
        warnings=[],
    )


@app.post('/api/session/end')
def end_session(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Explicitly delete a session (optional)."""
    sid = str(payload.get('session_id') or '').strip()
    if not sid:
        raise HTTPException(status_code=400, detail='Missing session_id')
    try:
        session_store.delete(sid)
    except Exception:
        pass
    return {'status': 'ok', 'session_id': sid}


@app.post('/api/solve_putt', response_model=SolvePuttResult)
def solve_putt(args: SolvePuttArgs) -> SolvePuttResult:
    """Resolve dataset, transform WGS84→green_local_m, then call the PuttSolver Service."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    request_id = args.request_id or str(uuid.uuid4())

    try:
        rec = dataset_registry.get_by_course_hole(args.course_id, int(args.hole_id))
        manifest = dataset_registry.load_manifest(rec)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    # Transform ball/cup into green-local meters
    try:
        ball_x, ball_y = wgs84_to_green_local_m(args.ball_wgs84.lat, args.ball_wgs84.lon, manifest)
        cup_x, cup_y = wgs84_to_green_local_m(args.cup_wgs84.lat, args.cup_wgs84.lon, manifest)
    except TransformError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    ball_local = {'x_m': float(ball_x), 'y_m': float(ball_y)}
    cup_local = {'x_m': float(cup_x), 'y_m': float(cup_y)}

    warnings = []
    warnings += bounds_warnings(ball_x, ball_y, manifest, 'ball_local')
    warnings += bounds_warnings(cup_x, cup_y, manifest, 'cup_local')

    # Stimp defaulting: use provided value, else manifest defaults
    stimp_payload = None
    if args.stimp is not None:
        stimp_payload = {'ft': int(args.stimp.ft), 'in': int(args.stimp.inches)}
    else:
        defaults = (manifest.get('defaults') or {}).get('stimp')
        if isinstance(defaults, dict) and 'ft' in defaults and 'in' in defaults:
            stimp_payload = {'ft': int(defaults['ft']), 'in': int(defaults['in'])}

    # Call the putt solver service
    try:
        service_resp = putt_client.solve_putt(
            request_id=request_id,
            dtm_id=rec.dtm_id,
            ball_local=ball_local,
            cup_local=cup_local,
            stimp=stimp_payload,
            want_plot=bool(args.want_plot),
        )
    except PuttSolverClientError as e:
        status = getattr(e, 'status_code', None)
        if status in (400, 404):
            raise HTTPException(status_code=int(status), detail=str(e)) from e
        raise HTTPException(status_code=502, detail=str(e)) from e

    instruction_text = str(service_resp.get('instruction_text', ''))
    plot = service_resp.get('plot')
    raw = service_resp.get('raw')
    service_warnings = service_resp.get('warnings') or []
    if isinstance(service_warnings, list):
        warnings += [str(w) for w in service_warnings]

    plot_model = None
    if isinstance(plot, dict):
        try:
            plot_model = PlotData(**plot)
        except Exception:
            warnings.append('Plot present but failed to validate; verify plot schema')

    raw_model = None
    if isinstance(raw, dict):
        try:
            raw_model = RawData(**raw)
        except Exception:
            warnings.append('Raw solver data present but failed to validate')

    return SolvePuttResult(
        request_id=request_id,
        dtm_id=rec.dtm_id,
        ball_local=Point2D(**ball_local),
        cup_local=Point2D(**cup_local),
        instruction_text=instruction_text,
        plot=plot_model,
        warnings=warnings,
        raw=raw_model,
    )


@app.post('/api/get_hole_advice', response_model=GetHoleAdviceResult)
def get_hole_advice(args: GetHoleAdviceArgs) -> GetHoleAdviceResult:
    """Unified router: decide tee-to-green vs putting using session state + surface classification."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    request_id = args.request_id or str(uuid.uuid4())
    t0 = time.monotonic()

    # Resolve args from session (optional)
    course_id = args.course_id
    hole_id = args.hole_id
    ball_wgs84 = args.ball_wgs84
    cup_wgs84 = args.cup_wgs84
    stimp_arg = args.stimp

    sess = None
    if args.session_id:
        try:
            sess = session_store.get(args.session_id)
        except SessionStoreError as e:
            raise HTTPException(status_code=404, detail=str(e)) from e

        course_id = course_id or sess.course_id
        hole_id = hole_id or sess.hole_id
        ball_wgs84 = ball_wgs84 or sess.ball_wgs84
        cup_wgs84 = cup_wgs84 or sess.cup_wgs84
        stimp_arg = stimp_arg or sess.stimp

    if course_id is None or hole_id is None:
        raise HTTPException(status_code=400, detail='Missing course_id/hole_id (or provide session_id)')
    if ball_wgs84 is None:
        raise HTTPException(status_code=400, detail='Missing ball_wgs84 (provide directly or call /api/session/set_ball_location)')

    warnings: List[str] = []
    next_actions: List[str] = []

    # Debug bundle payload (filled progressively)
    dbg: Dict[str, Any] = {
        "endpoint": "/api/get_hole_advice",
        "args": {
            "session_id": args.session_id,
            "course_id": course_id,
            "hole_id": hole_id,
            "ball_wgs84": ball_wgs84.model_dump() if hasattr(ball_wgs84, 'model_dump') else getattr(ball_wgs84, 'dict', lambda: ball_wgs84)(),
            "cup_wgs84": cup_wgs84.model_dump() if (cup_wgs84 is not None and hasattr(cup_wgs84, 'model_dump')) else (cup_wgs84.dict() if hasattr(cup_wgs84, 'dict') else None),
            "want_plot": bool(args.want_plot),
        },
        "timings_ms": {},
        "surface": {},
        "routing": {},
    }

    try:
        rec = dataset_registry.get_by_course_hole(str(course_id), int(hole_id))
        manifest = dataset_registry.load_manifest(rec)
        dbg["resolved"] = {
            "dtm_id": rec.dtm_id,
            "green_id": rec.green_id,
            "manifest_path": str(rec.manifest_path),
            "grid_path": str(rec.grid_path),
        }
    except DatasetRegistryError as e:
        dbg["error"] = str(e)
        bundle_writer.write(request_id, dbg)
        raise HTTPException(status_code=404, detail=str(e)) from e

    # Transform ball/cup into green-local meters
    try:
        ball_x, ball_y = wgs84_to_green_local_m(ball_wgs84.lat, ball_wgs84.lon, manifest)
    except TransformError as e:
        dbg["error"] = str(e)
        bundle_writer.write(request_id, dbg)
        raise HTTPException(status_code=400, detail=str(e)) from e

    ball_local = Point2D(x_m=float(ball_x), y_m=float(ball_y))
    warnings += bounds_warnings(ball_x, ball_y, manifest, 'ball_local')

    cup_local = None
    if cup_wgs84 is not None:
        try:
            cx, cy = wgs84_to_green_local_m(cup_wgs84.lat, cup_wgs84.lon, manifest)
            cup_local = Point2D(x_m=float(cx), y_m=float(cy))
            warnings += bounds_warnings(cx, cy, manifest, 'cup_local')
        except TransformError as e:
            warnings.append(f'cup transform failed: {e}')
            cup_local = None

    dbg["transforms"] = {
        "ball_local_green": {"x_m": float(ball_local.x_m), "y_m": float(ball_local.y_m)},
        "cup_local_green": {"x_m": float(cup_local.x_m), "y_m": float(cup_local.y_m)} if cup_local else None,
    }

    # Candidate surface classification
    cand_state, cand_conf, surface_warnings = classify_surface_state(
        float(ball_local.x_m),
        float(ball_local.y_m),
        manifest,
        grid_path=str(rec.grid_path),
        unknown_margin_m=UNKNOWN_MARGIN_M,
    )
    warnings += surface_warnings

    # Apply hysteresis in session mode
    surface_state = cand_state
    surface_conf = cand_conf
    if sess is not None:
        stable_state, stable_conf, cs, cc, hw = apply_surface_hysteresis(
            prev_state=sess.surface_state,
            prev_confidence=sess.surface_confidence,
            candidate_state=cand_state,
            candidate_confidence=cand_conf,
            candidate_prev_state=sess.surface_candidate_state,
            candidate_count=sess.surface_candidate_count,
            commit_on_streak=SURFACE_COMMIT_ON_STREAK,
            commit_off_streak=SURFACE_COMMIT_OFF_STREAK,
        )
        surface_state = stable_state
        surface_conf = stable_conf
        warnings += hw

        # Persist the resolved state for subsequent calls.
        sess.course_id = str(course_id)
        sess.hole_id = int(hole_id)
        sess.ball_wgs84 = ball_wgs84
        sess.cup_wgs84 = cup_wgs84
        sess.stimp = stimp_arg
        sess.ball_local_green = ball_local
        sess.cup_local_green = cup_local
        sess.surface_state = surface_state
        sess.surface_confidence = surface_conf
        sess.surface_candidate_state = cs
        sess.surface_candidate_count = cc
        session_store.update(sess)

    dbg["surface"] = {
        "candidate_state": cand_state,
        "candidate_confidence": cand_conf,
        "stable_state": surface_state,
        "stable_confidence": surface_conf,
        "commit_on_streak": SURFACE_COMMIT_ON_STREAK,
        "commit_off_streak": SURFACE_COMMIT_OFF_STREAK,
    }

    hole_state = HoleStateSnapshot(
        session_id=args.session_id,
        course_id=str(course_id),
        hole_id=int(hole_id),
        dtm_id=rec.dtm_id,
        green_id=rec.green_id,
        ball_wgs84=ball_wgs84,
        cup_wgs84=cup_wgs84,
        ball_local_green=ball_local,
        cup_local_green=cup_local,
        surface_state=surface_state,  # type: ignore
        surface_confidence=surface_conf,
        green_frame={
            'frame': 'green_local_m',
            'extents_m': (manifest.get('extents_m') or {}),
            'grid': (manifest.get('grid') or {}),
        },
        warnings=[],
    )

    # --- Routing decision ---
    should_putt = surface_state in ('ON_GREEN', 'UNKNOWN')

    if should_putt:
        dbg["routing"] = {"plan_type": "PUTT"}

        if cup_local is None:
            next_actions.append('Provide cup_wgs84 (pin) location to compute a putt.')
            plan = {
                'instruction_text': '',
                'plot': None,
                'raw': {'dll_return_code': -1, 'dll_error_text': 'Missing cup_wgs84'},
            }
            dbg["plan"] = plan
            dbg["warnings"] = warnings
            dbg["timings_ms"]["total"] = int((time.monotonic() - t0) * 1000)
            bundle_writer.write(request_id, dbg)
            return GetHoleAdviceResult(
                request_id=request_id,
                plan_type='PUTT',
                hole_state=hole_state,
                plan=plan,
                warnings=warnings,
                next_actions=next_actions,
                error=None,
            )

        # Stimp defaulting: use provided value, else manifest defaults
        stimp_payload = None
        if stimp_arg is not None:
            stimp_payload = {'ft': int(stimp_arg.ft), 'in': int(stimp_arg.inches)}
        else:
            defaults = (manifest.get('defaults') or {}).get('stimp')
            if isinstance(defaults, dict) and 'ft' in defaults and 'in' in defaults:
                stimp_payload = {'ft': int(defaults['ft']), 'in': int(defaults['in'])}

        # Call the putt solver service
        t_call = time.monotonic()
        try:
            service_resp = putt_client.solve_putt(
                request_id=request_id,
                dtm_id=rec.dtm_id,
                ball_local={'x_m': float(ball_local.x_m), 'y_m': float(ball_local.y_m)},
                cup_local={'x_m': float(cup_local.x_m), 'y_m': float(cup_local.y_m)},
                stimp=stimp_payload,
                want_plot=bool(args.want_plot),
            )
        except PuttSolverClientError as e:
            dbg["error"] = str(e)
            dbg["timings_ms"]["putt_solver_call"] = int((time.monotonic() - t_call) * 1000)
            dbg["timings_ms"]["total"] = int((time.monotonic() - t0) * 1000)
            dbg["warnings"] = warnings
            bundle_writer.write(request_id, dbg)

            status = getattr(e, 'status_code', None)
            if status in (400, 404):
                raise HTTPException(status_code=int(status), detail=str(e)) from e
            raise HTTPException(status_code=502, detail=str(e)) from e

        dbg["timings_ms"]["putt_solver_call"] = int((time.monotonic() - t_call) * 1000)

        instruction_text = str(service_resp.get('instruction_text', ''))
        plot = service_resp.get('plot')
        raw = service_resp.get('raw')
        service_warnings = service_resp.get('warnings') or []
        if isinstance(service_warnings, list):
            warnings += [str(w) for w in service_warnings]

        plan: Dict[str, Any] = {
            'instruction_text': instruction_text,
            'plot': plot if isinstance(plot, dict) else None,
            'raw': raw if isinstance(raw, dict) else None,
        }

        dbg["plan"] = {
            "instruction_text": instruction_text,
            "plot": {"points_count": len(plot.get('points', []))} if isinstance(plot, dict) else None,
            "raw": raw,
        }
        dbg["warnings"] = warnings
        dbg["timings_ms"]["total"] = int((time.monotonic() - t0) * 1000)
        bundle_writer.write(request_id, dbg)

        return GetHoleAdviceResult(
            request_id=request_id,
            plan_type='PUTT',
            hole_state=hole_state,
            plan=plan,
            warnings=warnings,
            next_actions=next_actions,
            error=None,
        )

    # OFF_GREEN -> tee-to-green
    dbg["routing"] = {"plan_type": "TEE_TO_GREEN"}

    if tee_client is None:
        next_actions.append('Configure TEE_TO_GREEN_URL to enable tee-to-green planning.')
        plan = {
            'summary': 'Ball is off green; tee-to-green planner not configured.',
            'debug': {
                'surface_state': surface_state,
                'ball_wgs84': ball_wgs84.model_dump(),
            },
        }
        dbg["plan"] = plan
        dbg["warnings"] = warnings
        dbg["timings_ms"]["total"] = int((time.monotonic() - t0) * 1000)
        bundle_writer.write(request_id, dbg)

        return GetHoleAdviceResult(
            request_id=request_id,
            plan_type='TEE_TO_GREEN',
            hole_state=hole_state,
            plan=plan,
            warnings=warnings,
            next_actions=next_actions,
        )

    # Call tee-to-green planner service
    t_call = time.monotonic()
    try:
        ttg_resp = tee_client.plan_shot(
            request_id=request_id,
            course_id=str(course_id),
            hole_id=int(hole_id),
            ball_wgs84=ball_wgs84.model_dump(),
            pin_wgs84=cup_wgs84.model_dump() if cup_wgs84 else None,
            player=None,
            conditions=None,
            contract_version="0.5.0",
        )
    except TeeToGreenClientError as e:
        dbg["error"] = str(e)
        dbg["timings_ms"]["tee_to_green_call"] = int((time.monotonic() - t_call) * 1000)
        dbg["timings_ms"]["total"] = int((time.monotonic() - t0) * 1000)
        dbg["warnings"] = warnings
        bundle_writer.write(request_id, dbg)

        warnings.append(str(e))
        plan = {
            'summary': 'Tee-to-green planner error; unable to produce plan.',
            'debug': {
                'error': str(e),
                'surface_state': surface_state,
            },
        }
        return GetHoleAdviceResult(
            request_id=request_id,
            plan_type='TEE_TO_GREEN',
            hole_state=hole_state,
            plan=plan,
            warnings=warnings,
            next_actions=next_actions,
        )

    dbg["timings_ms"]["tee_to_green_call"] = int((time.monotonic() - t_call) * 1000)

    # Normalize response fields into our unified plan contract
    plan = {
        'summary': str(ttg_resp.get('summary') or ttg_resp.get('message') or '').strip() or 'Tee-to-green plan returned.',
        'recommended_club': ttg_resp.get('recommended_club'),
        'carry_m': ttg_resp.get('carry_m'),
        'total_m': ttg_resp.get('total_m'),
        'bearing_deg': ttg_resp.get('bearing_deg'),
        'target_wgs84': ttg_resp.get('target_wgs84'),
        'confidence': ttg_resp.get('confidence'),
        'debug': ttg_resp.get('debug'),
    }

    dbg["plan"] = plan
    dbg["warnings"] = warnings
    dbg["timings_ms"]["total"] = int((time.monotonic() - t0) * 1000)
    bundle_writer.write(request_id, dbg)

    return GetHoleAdviceResult(
        request_id=request_id,
        plan_type='TEE_TO_GREEN',
        hole_state=hole_state,
        plan=plan,
        warnings=warnings,
        next_actions=next_actions,
    )


if __name__ == "__main__":
    import uvicorn

    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))

    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info" if DEBUG else "error",
    )
