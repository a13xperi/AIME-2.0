import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Paths that require authentication
const protectedPaths = ['/dashboard']

// Paths that are only accessible to users who are NOT logged in
const authOnlyPaths = ['/login', '/signup']

export function middleware(request: NextRequest) {
  const currentUser = request.cookies.get('user')?.value
  
  // Check if the path is protected
  const isProtectedPath = protectedPaths.some(path => 
    request.nextUrl.pathname === path || 
    request.nextUrl.pathname.startsWith(`${path}/`)
  )
  
  // Check if path is auth-only (login/signup)
  const isAuthOnlyPath = authOnlyPaths.some(path => 
    request.nextUrl.pathname === path || 
    request.nextUrl.pathname.startsWith(`${path}/`)
  )
  
  // If path requires auth and user isn't logged in, redirect to login
  if (isProtectedPath && !currentUser) {
    const loginUrl = new URL('/login', request.url)
    return NextResponse.redirect(loginUrl)
  }
  
  // If path is auth-only and user is logged in, redirect to dashboard
  if (isAuthOnlyPath && currentUser) {
    const dashboardUrl = new URL('/dashboard', request.url)
    return NextResponse.redirect(dashboardUrl)
  }
  
  return NextResponse.next()
}

export const config = {
  matcher: [
    // Match all paths except for API routes, static files, images, 
    // and other assets
    '/((?!api|_next/static|_next/image|favicon.ico|images).*)',
  ],
} 