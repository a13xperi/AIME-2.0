import React from "react";

type Point2D = { x_m: number; y_m: number };

type Props = {
  widthPx: number;
  heightPx: number;
  extents: { x_max_m: number; y_max_m: number };
  ball?: Point2D;
  cup?: Point2D;
  path?: Point2D[];
  invertY?: boolean; // if local Y increases "up", set invertY=true for top-left pixel origin
};

export default function GreenOverlay({
  widthPx,
  heightPx,
  extents,
  ball,
  cup,
  path = [],
  invertY = true,
}: Props) {
  const toPx = (p: Point2D) => {
    const x = (p.x_m / extents.x_max_m) * widthPx;
    const yRaw = (p.y_m / extents.y_max_m) * heightPx;
    const y = invertY ? heightPx - yRaw : yRaw;
    return { x, y };
  };

  const pathD =
    path.length > 0
      ? "M " +
        path
          .map((p) => {
            const q = toPx(p);
            return `${q.x.toFixed(2)} ${q.y.toFixed(2)}`;
          })
          .join(" L ")
      : "";

  const ballPx = ball ? toPx(ball) : null;
  const cupPx = cup ? toPx(cup) : null;

  return (
    <svg
      width={widthPx}
      height={heightPx}
      viewBox={`0 0 ${widthPx} ${heightPx}`}
      className="absolute inset-0 pointer-events-none"
    >
      {/* Path */}
      {pathD && (
        <path
          d={pathD}
          fill="none"
          stroke="white"
          strokeWidth="2"
          opacity="0.9"
        />
      )}

      {/* Ball */}
      {ballPx && (
        <circle cx={ballPx.x} cy={ballPx.y} r="4" fill="white" opacity="0.9" />
      )}

      {/* Cup */}
      {cupPx && (
        <circle cx={cupPx.x} cy={cupPx.y} r="4" fill="black" opacity="0.9" />
      )}
    </svg>
  );
}
