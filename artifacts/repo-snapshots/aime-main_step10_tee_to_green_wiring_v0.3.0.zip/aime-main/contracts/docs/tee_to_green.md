# Tee-to-Green Planning Contract

**Contract version:** `0.3.0`

This contract describes a *tee-to-green* planner integration as a **separate service** that the AIME backend can call when the ball is **OFF_GREEN**.

> In Step 10, tee-to-green is integrated into the unified `/api/get_hole_advice` router via `TEE_TO_GREEN_URL`.
> The actual tee-to-green engine may be internal/existing; this contract defines the stable interface we will route through.

---

## Endpoint
`POST /plan_shot`

### Request schema
- `contracts/schemas/tee_to_green.request.schema.json`

**Required fields**
- `contract_version`
- `course_id`
- `hole_id`
- `ball_wgs84`

**Optional fields**
- `pin_wgs84` (if known)
- `player` (free-form; future)
- `conditions` (free-form; future)

### Response schema
- `contracts/schemas/tee_to_green.response.schema.json`

**Required fields**
- `contract_version`
- `request_id`
- `summary` (human-readable plan summary)

**Optional structured fields** (recommended)
- `recommended_club`
- `carry_m`, `total_m`
- `bearing_deg`
- `target_wgs84`
- `confidence`
- `debug`

---

## Integration in AIME

### Routing
When `/api/get_hole_advice` determines the ball is OFF_GREEN:
- If `TEE_TO_GREEN_URL` is set, AIME calls:  
  `{TEE_TO_GREEN_URL}/plan_shot`
- If `TEE_TO_GREEN_URL` is not set, AIME returns a placeholder plan with `next_actions` telling you to configure it.

### Environment variables
- `TEE_TO_GREEN_URL` (example: `http://localhost:7072`)
- `TEE_TO_GREEN_TIMEOUT_S` (default: `3.0`)

---

## Notes
- The tee-to-green service is allowed to be “best effort” and return only `summary` initially.
- Over time, we can add structured fields to improve UI rendering and downstream evaluation.
