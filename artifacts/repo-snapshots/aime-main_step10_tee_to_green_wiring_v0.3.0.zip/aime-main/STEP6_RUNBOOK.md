# Step 6 Scaffold Runbook (MOCK Putt Solver)

This scaffold validates integration plumbing without loading any DLLs.

## 1) Start the mock solver service
From the `putt-solver-service-mock` zip you downloaded:

- Set `DATA_ROOT` to point at `aime-main/course_data`
- Start FastAPI on port 7071

## 2) Start the AIME backend
From `aime-main/backend`:

Environment (example):
- `COURSE_DATA_ROOT=../course_data`
- `PUTT_SOLVER_URL=http://localhost:7071`

Then run:
```bash
uvicorn main:app --reload --port 8000
```

## 3) Smoke test
```bash
curl -X POST http://localhost:8000/api/solve_putt \
  -H "Content-Type: application/json" \
  -d '{
    "course_id": "riverside",
    "hole_id": 1,
    "ball_wgs84": {"lat": 40.268251, "lon": -111.659486},
    "cup_wgs84": {"lat": 40.268260, "lon": -111.659470},
    "want_plot": true
  }'
```

You should receive:
- a `request_id`
- a `dtm_id` of `riverside_2023_20cm`
- `ball_local` and `cup_local` (green_local_m)
- `instruction_text` starting with `MOCK SOLVER`

## Notes
- Coordinate axis/origin conventions remain **UNCONFIRMED** until the developer blockers call.
- This step is to validate service boundaries, allowlisting, and tool plumbing.
