from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import os
from dotenv import load_dotenv
from typing import Dict, Any, List
from datetime import datetime
from pathlib import Path
import uuid

from aime.data.datasets import DatasetRegistry, DatasetRegistryError
from aime.geo.transforms import wgs84_to_green_local_m, bounds_warnings, TransformError
from aime.clients.putt_solver_client import PuttSolverClient, PuttSolverClientConfig, PuttSolverClientError
from aime.clients.tee_to_green_client import TeeToGreenClient, TeeToGreenClientConfig, TeeToGreenClientError
from aime.models.putt import SolvePuttArgs, SolvePuttResult, Point2D, PlotData, RawData
from aime.models.advice import GetHoleAdviceArgs, GetHoleAdviceResult, HoleStateSnapshot


# Load environment variables
load_dotenv()

# Configuration from environment variables
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:3000")
DEBUG = os.getenv("DEBUG", "True").lower() in ("true", "1", "t")

# Step 6 scaffold config
REPO_ROOT = Path(__file__).resolve().parent.parent  # aime-main/
COURSE_DATA_ROOT = Path(os.getenv('COURSE_DATA_ROOT', str(REPO_ROOT / 'course_data'))).resolve()
DATASET_REGISTRY_PATH = Path(os.getenv('DATASET_REGISTRY_PATH', str(COURSE_DATA_ROOT / 'datasets.json'))).resolve()
PUTT_SOLVER_URL = os.getenv('PUTT_SOLVER_URL', 'http://localhost:7071')  # mock service default
PUTT_SOLVER_TIMEOUT_S = float(os.getenv('PUTT_SOLVER_TIMEOUT_S', '3.0'))

# Step 9 scaffold config
SURFACE_MARGIN_M = float(os.getenv('SURFACE_MARGIN_M', '0.5'))
UNKNOWN_MARGIN_M = float(os.getenv('UNKNOWN_MARGIN_M', '1.0'))
TEE_TO_GREEN_URL = os.getenv('TEE_TO_GREEN_URL', '')  # optional (future)


# Initialize dataset registry + solver client (loaded once at startup)
dataset_registry = DatasetRegistry(COURSE_DATA_ROOT, DATASET_REGISTRY_PATH)
try:
    dataset_registry.load()
except Exception as e:
    # Avoid crashing import; surface error via /health endpoint later if needed
    dataset_registry_error = str(e)
else:
    dataset_registry_error = None

putt_client = PuttSolverClient(PuttSolverClientConfig(base_url=PUTT_SOLVER_URL, timeout_s=PUTT_SOLVER_TIMEOUT_S))

tee_client = None
if TEE_TO_GREEN_URL:
    tee_client = TeeToGreenClient(TeeToGreenClientConfig(base_url=TEE_TO_GREEN_URL, timeout_s=TEE_TO_GREEN_TIMEOUT_S))

def classify_surface_state(ball_x_m: float, ball_y_m: float, manifest: Dict[str, Any]) -> tuple[str, float, List[str]]:
    """Classify whether the ball is on the green using only manifest extents (safe, deterministic).

    Returns: (surface_state, confidence, warnings)
    """
    warnings: List[str] = []
    ext = (manifest.get('extents_m') or {})
    x_max = float(ext.get('x_max_m', 0.0))
    y_max = float(ext.get('y_max_m', 0.0))

    # Primary: strict bounds check
    inside = (0.0 <= ball_x_m <= x_max) and (0.0 <= ball_y_m <= y_max)

    if inside:
        return ("ON_GREEN", 0.90, warnings)

    # Secondary: near-boundary zone -> UNKNOWN (handles coordinate-frame uncertainty)
    near = (-UNKNOWN_MARGIN_M <= ball_x_m <= x_max + UNKNOWN_MARGIN_M) and (-UNKNOWN_MARGIN_M <= ball_y_m <= y_max + UNKNOWN_MARGIN_M)
    if near:
        warnings.append("ball appears near green extents boundary; surface_state set to UNKNOWN until coordinate frame is confirmed")
        return ("UNKNOWN", 0.55, warnings)

    return ("OFF_GREEN", 0.90, warnings)


app = FastAPI(
    title="AIME API",
    description="Backend API for AIME POC",
    version="0.1.0",
    debug=DEBUG
)

# Configure CORS to allow requests from the frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_URL],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root() -> Dict[str, Any]:
    """Root endpoint that confirms the API is running."""
    return {
        "status": "ok",
        "message": "Backend API is running",
        "version": "0.1.0",
        "environment": "development" if DEBUG else "production"
    }

@app.get("/api/hello")
def hello_world() -> Dict[str, str]:
    """Simple hello world endpoint for testing."""
    return {"message": "Hello from the backend!"}

@app.get("/api/config")
def get_config() -> Dict[str, Any]:
    """Return configuration information for the client."""
    return {
        "apiVersion": "0.1.0",
        "environment": "development" if DEBUG else "production",
        "features": {
            "logging": True,
            "authentication": True
        }
    }

@app.get("/api/status")
def get_status() -> Dict[str, Any]:
    """Return authentication status for the client."""
    return {
        "authenticated": True,  # For demo, we'll always return true
        "serverTime": datetime.now().isoformat(),
        "serverStatus": "operational"
    }

# Only run the server directly when this file is executed as a script

@app.get('/api/datasets')
def list_registered_datasets() -> Dict[str, Any]:
    """List allowlisted datasets (debug/scaffold)."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')
    out = []
    for rec in dataset_registry.list():
        out.append({
            'dtm_id': rec.dtm_id,
            'course_id': rec.course_id,
            'hole_id': rec.hole_id,
            'green_id': rec.green_id,
            'manifest_path': str(rec.manifest_path),
        })
    return {'datasets': out}

@app.post('/api/solve_putt', response_model=SolvePuttResult)
def solve_putt(args: SolvePuttArgs) -> SolvePuttResult:
    """Resolve dataset, transform WGS84→green_local_m, then call the PuttSolver Service."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    request_id = args.request_id or str(uuid.uuid4())

    try:
        rec = dataset_registry.get_by_course_hole(args.course_id, int(args.hole_id))
        manifest = dataset_registry.load_manifest(rec)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    # Transform ball/cup into green-local meters
    try:
        ball_x, ball_y = wgs84_to_green_local_m(args.ball_wgs84.lat, args.ball_wgs84.lon, manifest)
        cup_x, cup_y = wgs84_to_green_local_m(args.cup_wgs84.lat, args.cup_wgs84.lon, manifest)
    except TransformError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    ball_local = {'x_m': ball_x, 'y_m': ball_y}
    cup_local = {'x_m': cup_x, 'y_m': cup_y}

    warnings = []
    warnings += bounds_warnings(ball_x, ball_y, manifest, 'ball_local')
    warnings += bounds_warnings(cup_x, cup_y, manifest, 'cup_local')

    # Stimp defaulting: use provided value, else manifest defaults, else None
    stimp_payload = None
    if args.stimp is not None:
        stimp_payload = {'ft': int(args.stimp.ft), 'in': int(args.stimp.inches)}
    else:
        defaults = (manifest.get('defaults') or {}).get('stimp')
        if isinstance(defaults, dict) and 'ft' in defaults and 'in' in defaults:
            stimp_payload = {'ft': int(defaults['ft']), 'in': int(defaults['in'])}

    # Call the (mock) putt solver service
    try:
        service_resp = putt_client.solve_putt(
            request_id=request_id,
            dtm_id=rec.dtm_id,
            ball_local=ball_local,
            cup_local=cup_local,
            stimp=stimp_payload,
            want_plot=bool(args.want_plot),
        )
    except PuttSolverClientError as e:
        status = getattr(e, 'status_code', None)
        if status in (400, 404):
            raise HTTPException(status_code=int(status), detail=str(e)) from e
        raise HTTPException(status_code=502, detail=str(e)) from e

    # Merge response (always include local points for UI overlay debugging)
    instruction_text = str(service_resp.get('instruction_text', ''))
    plot = service_resp.get('plot')
    raw = service_resp.get('raw')
    service_warnings = service_resp.get('warnings') or []
    if isinstance(service_warnings, list):
        warnings += [str(w) for w in service_warnings]

    plot_model = None
    if isinstance(plot, dict):
        try:
            plot_model = PlotData(**plot)
        except Exception:
            warnings.append('Plot present but failed to validate; verify plot schema')

    raw_model = None
    if isinstance(raw, dict):
        try:
            raw_model = RawData(**raw)
        except Exception:
            warnings.append('Raw solver data present but failed to validate')

    return SolvePuttResult(
        request_id=request_id,
        dtm_id=rec.dtm_id,
        ball_local=Point2D(**ball_local),
        cup_local=Point2D(**cup_local),
        instruction_text=instruction_text,
        plot=plot_model,
        warnings=warnings,
        raw=raw_model,
    )



@app.post('/api/get_hole_advice', response_model=GetHoleAdviceResult)
def get_hole_advice(args: GetHoleAdviceArgs) -> GetHoleAdviceResult:
    """Unified router: decide tee-to-green vs putting based on ball position and manifest extents.

    NOTE: Tee-to-green routing is enabled when TEE_TO_GREEN_URL is configured; otherwise a placeholder plan is returned.
    """
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    request_id = args.request_id or str(uuid.uuid4())

    warnings: List[str] = []
    next_actions: List[str] = []

    try:
        rec = dataset_registry.get_by_course_hole(args.course_id, int(args.hole_id))
        manifest = dataset_registry.load_manifest(rec)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    # Transform ball/cup into green-local meters (best effort)
    try:
        ball_x, ball_y = wgs84_to_green_local_m(args.ball_wgs84.lat, args.ball_wgs84.lon, manifest)
    except TransformError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    ball_local = Point2D(x_m=float(ball_x), y_m=float(ball_y))
    warnings += bounds_warnings(ball_x, ball_y, manifest, 'ball_local')

    cup_local = None
    if args.cup_wgs84 is not None:
        try:
            cx, cy = wgs84_to_green_local_m(args.cup_wgs84.lat, args.cup_wgs84.lon, manifest)
            cup_local = Point2D(x_m=float(cx), y_m=float(cy))
            warnings += bounds_warnings(cx, cy, manifest, 'cup_local')
        except TransformError as e:
            warnings.append(f'cup transform failed: {e}')
            cup_local = None

    surface_state, surface_conf, surface_warnings = classify_surface_state(ball_x, ball_y, manifest)
    warnings += surface_warnings

    hole_state = HoleStateSnapshot(
        course_id=args.course_id,
        hole_id=int(args.hole_id),
        dtm_id=rec.dtm_id,
        green_id=rec.green_id,
        ball_wgs84=args.ball_wgs84,
        cup_wgs84=args.cup_wgs84,
        ball_local_green=ball_local,
        cup_local_green=cup_local,
        surface_state=surface_state,  # type: ignore
        surface_confidence=surface_conf,
        green_frame={
            'frame': 'green_local_m',
            'extents_m': (manifest.get('extents_m') or {}),
            'grid': (manifest.get('grid') or {}),
        },
        warnings=[],
    )

    # --- Routing decision ---
    should_putt = surface_state in ('ON_GREEN', 'UNKNOWN')

    if should_putt:
        if cup_local is None:
            next_actions.append('Provide cup_wgs84 (pin) location to compute a putt.')
            plan = {
                'instruction_text': '',
                'plot': None,
                'raw': {'dll_return_code': -1, 'dll_error_text': 'Missing cup_wgs84'},
            }
            return GetHoleAdviceResult(
                request_id=request_id,
                plan_type='PUTT',
                hole_state=hole_state,
                plan=plan,
                warnings=warnings,
                next_actions=next_actions,
                error=None,
            )

        # Stimp defaulting: use provided value, else manifest defaults, else None
        stimp_payload = None
        if args.stimp is not None:
            stimp_payload = {'ft': int(args.stimp.ft), 'in': int(args.stimp.inches)}
        else:
            defaults = (manifest.get('defaults') or {}).get('stimp')
            if isinstance(defaults, dict) and 'ft' in defaults and 'in' in defaults:
                stimp_payload = {'ft': int(defaults['ft']), 'in': int(defaults['in'])}

        # Call the putt solver service
        try:
            service_resp = putt_client.solve_putt(
                request_id=request_id,
                dtm_id=rec.dtm_id,
                ball_local={'x_m': float(ball_local.x_m), 'y_m': float(ball_local.y_m)},
                cup_local={'x_m': float(cup_local.x_m), 'y_m': float(cup_local.y_m)},
                stimp=stimp_payload,
                want_plot=bool(args.want_plot),
            )
        except PuttSolverClientError as e:
            status = getattr(e, 'status_code', None)
            if status in (400, 404):
                raise HTTPException(status_code=int(status), detail=str(e)) from e
            raise HTTPException(status_code=502, detail=str(e)) from e

        instruction_text = str(service_resp.get('instruction_text', ''))
        plot = service_resp.get('plot')
        raw = service_resp.get('raw')
        service_warnings = service_resp.get('warnings') or []
        if isinstance(service_warnings, list):
            warnings += [str(w) for w in service_warnings]

        plan: Dict[str, Any] = {
            'instruction_text': instruction_text,
            'plot': plot if isinstance(plot, dict) else None,
            'raw': raw if isinstance(raw, dict) else None,
        }

        return GetHoleAdviceResult(
            request_id=request_id,
            plan_type='PUTT',
            hole_state=hole_state,
            plan=plan,
            warnings=warnings,
            next_actions=next_actions,
            error=None,
        )

    # OFF_GREEN -> tee-to-green (scaffold)
        # --- Tee-to-green branch (OFF_GREEN) ---
    if surface_state in ('OFF_GREEN', 'TRANSITION'):
        if tee_client is None:
            next_actions.append('Configure TEE_TO_GREEN_URL to enable tee-to-green planning.')
            plan = {
                'summary': 'Ball is off green; tee-to-green planner not configured.',
                'debug': {
                    'surface_state': surface_state,
                    'ball_wgs84': args.ball_wgs84.model_dump(),
                },
            }
            return GetHoleAdviceResult(
                request_id=request_id,
                plan_type='TEE_TO_GREEN',
                hole_state=hole_state,
                plan=plan,
                warnings=warnings,
                next_actions=next_actions,
            )

        # Call tee-to-green planner service
        try:
            ttg_resp = tee_client.plan_shot(
                request_id=request_id,
                course_id=args.course_id,
                hole_id=int(args.hole_id),
                ball_wgs84=args.ball_wgs84.model_dump(),
                pin_wgs84=args.cup_wgs84.model_dump() if args.cup_wgs84 else None,
                player=None,
                conditions=None,
            )
        except TeeToGreenClientError as e:
            warnings.append(str(e))
            plan = {
                'summary': 'Tee-to-green planner error; unable to produce plan.',
                'debug': {
                    'error': str(e),
                    'surface_state': surface_state,
                },
            }
            return GetHoleAdviceResult(
                request_id=request_id,
                plan_type='TEE_TO_GREEN',
                hole_state=hole_state,
                plan=plan,
                warnings=warnings,
                next_actions=next_actions,
            )

        # Normalize response fields into our unified plan contract
        plan = {
            'summary': str(ttg_resp.get('summary') or ttg_resp.get('message') or '').strip() or 'Tee-to-green plan returned.',
            'recommended_club': ttg_resp.get('recommended_club'),
            'carry_m': ttg_resp.get('carry_m'),
            'total_m': ttg_resp.get('total_m'),
            'bearing_deg': ttg_resp.get('bearing_deg'),
            'target_wgs84': ttg_resp.get('target_wgs84'),
            'confidence': ttg_resp.get('confidence'),
            'debug': ttg_resp.get('debug'),
        }

        return GetHoleAdviceResult(
            request_id=request_id,
            plan_type='TEE_TO_GREEN',
            hole_state=hole_state,
            plan=plan,
            warnings=warnings,
            next_actions=next_actions,
        )

if __name__ == "__main__":
    import uvicorn
    
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info" if DEBUG else "error"
    ) 
