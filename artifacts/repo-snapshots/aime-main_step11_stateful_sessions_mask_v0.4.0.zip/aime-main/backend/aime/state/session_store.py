from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from threading import RLock
from typing import Dict, Optional

from aime.models.putt import GeoPointWGS84, Point2D, Stimp


@dataclass
class HoleSession:
    session_id: str
    course_id: str
    hole_id: int
    dtm_id: Optional[str] = None
    green_id: Optional[str] = None

    ball_wgs84: Optional[GeoPointWGS84] = None
    cup_wgs84: Optional[GeoPointWGS84] = None
    stimp: Optional[Stimp] = None

    ball_local_green: Optional[Point2D] = None
    cup_local_green: Optional[Point2D] = None

    surface_state: str = "UNKNOWN"
    surface_confidence: Optional[float] = None

    last_updated_utc: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class SessionStoreError(RuntimeError):
    pass


class SessionStore:
    """In-memory hole session store (MVP).

    Notes:
    - This is intentionally in-memory for Phase 0–1 integration work.
    - In production, replace with Redis or a durable store if needed.
    """

    def __init__(self, ttl_seconds: int = 2 * 60 * 60) -> None:
        self._ttl = timedelta(seconds=ttl_seconds)
        self._lock = RLock()
        self._sessions: Dict[str, HoleSession] = {}

    def _prune_locked(self) -> None:
        now = datetime.now(timezone.utc)
        expired = [sid for sid, s in self._sessions.items() if (now - s.last_updated_utc) > self._ttl]
        for sid in expired:
            self._sessions.pop(sid, None)

    def create(self, session: HoleSession) -> None:
        with self._lock:
            self._prune_locked()
            self._sessions[session.session_id] = session

    def get(self, session_id: str) -> HoleSession:
        with self._lock:
            self._prune_locked()
            if session_id not in self._sessions:
                raise SessionStoreError(f"Unknown or expired session_id: {session_id}")
            return self._sessions[session_id]

    def update(self, session: HoleSession) -> None:
        with self._lock:
            self._sessions[session.session_id] = session

    def touch(self, session_id: str) -> None:
        with self._lock:
            s = self.get(session_id)
            s.last_updated_utc = datetime.now(timezone.utc)
            self._sessions[session_id] = s

    def delete(self, session_id: str) -> None:
        with self._lock:
            self._sessions.pop(session_id, None)

    def count(self) -> int:
        with self._lock:
            self._prune_locked()
            return len(self._sessions)
