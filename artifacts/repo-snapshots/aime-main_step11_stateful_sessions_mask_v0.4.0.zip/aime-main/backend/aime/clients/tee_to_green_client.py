from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import httpx


@dataclass(frozen=True)
class TeeToGreenClientConfig:
    base_url: str
    timeout_s: float = 3.0


class TeeToGreenClientError(RuntimeError):
    """Raised when the tee-to-green service returns an error or cannot be reached."""
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class TeeToGreenClient:
    def __init__(self, config: TeeToGreenClientConfig):
        self._base_url = config.base_url.rstrip("/")
        self._timeout_s = float(config.timeout_s)

    def plan_shot(
        self,
        *,
        request_id: str,
        course_id: str,
        hole_id: int,
        ball_wgs84: Dict[str, float],
        pin_wgs84: Optional[Dict[str, float]] = None,
        player: Optional[Dict[str, Any]] = None,
        conditions: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Call tee-to-green planner service.

        NOTE: This is a *service-to-service* call. The planner is treated as a black box.
        The stable contract is enforced by the JSON schemas under /contracts.
        """
        payload: Dict[str, Any] = {
            "contract_version": "0.3.0",
            "request_id": request_id,
            "course_id": course_id,
            "hole_id": int(hole_id),
            "ball_wgs84": ball_wgs84,
        }
        if pin_wgs84 is not None:
            payload["pin_wgs84"] = pin_wgs84
        if player is not None:
            payload["player"] = player
        if conditions is not None:
            payload["conditions"] = conditions

        url = f"{self._base_url}/plan_shot"
        try:
            resp = httpx.post(url, json=payload, timeout=self._timeout_s)
        except Exception as e:
            raise TeeToGreenClientError(f"Failed to reach tee-to-green service: {e}") from e

        if resp.status_code >= 400:
            # Try to surface any JSON error payload
            try:
                detail = resp.json()
            except Exception:
                detail = {"text": resp.text[:500]}
            raise TeeToGreenClientError(
                f"Tee-to-green service error {resp.status_code}: {detail}",
                status_code=resp.status_code,
            )

        try:
            data = resp.json()
        except Exception as e:
            raise TeeToGreenClientError(f"Invalid JSON from tee-to-green service: {e}") from e

        return data
