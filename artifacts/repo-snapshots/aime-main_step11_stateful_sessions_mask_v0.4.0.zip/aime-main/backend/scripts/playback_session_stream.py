#!/usr/bin/env python3
"""Playback harness for session-based updates.

Safe: This does NOT execute any native binaries. It only sends HTTP requests to the running backend.

Usage (example):
  python backend/scripts/playback_session_stream.py \
    --backend-url http://localhost:8000 \
    --course-id riverside --hole-id 1 \
    --sequence backend/scripts/playback_sequence.sample.json \
    --cup-lat 40.268251 --cup-lon -111.659486

This will:
  1) POST /api/session/start
  2) POST /api/session/set_cup_location (optional)
  3) Stream ball positions via POST /api/session/set_ball_location
  4) Call /api/get_hole_advice with only session_id after each update
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import httpx


def load_sequence(path: Path) -> List[Dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise ValueError("Sequence file must be a JSON array")
    out: List[Dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict) or "lat" not in item or "lon" not in item:
            raise ValueError("Each item must be an object with lat/lon")
        out.append(item)
    return out


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--backend-url", default="http://localhost:8000")
    p.add_argument("--course-id", default="riverside")
    p.add_argument("--hole-id", type=int, default=1)
    p.add_argument("--sequence", type=str, required=True)
    p.add_argument("--cup-lat", type=float, default=None)
    p.add_argument("--cup-lon", type=float, default=None)
    args = p.parse_args()

    seq = load_sequence(Path(args.sequence))

    with httpx.Client(timeout=5.0) as client:
        # 1) Start session
        start_payload: Dict[str, Any] = {
            "contract_version": "0.4.0",
            "course_id": args.course_id,
            "hole_id": int(args.hole_id),
        }
        start_resp = client.post(f"{args.backend_url}/api/session/start", json=start_payload)
        start_resp.raise_for_status()
        start = start_resp.json()
        session_id = start.get("session_id")
        print(f"session_id={session_id}")

        # 2) Set cup if provided
        if args.cup_lat is not None and args.cup_lon is not None:
            cup_payload = {
                "contract_version": "0.4.0",
                "session_id": session_id,
                "cup_wgs84": {"lat": float(args.cup_lat), "lon": float(args.cup_lon)},
            }
            cup_resp = client.post(f"{args.backend_url}/api/session/set_cup_location", json=cup_payload)
            print("set_cup:", cup_resp.status_code, (cup_resp.json().get("hole_state") or {}).get("cup_local_green"))

        # 3) Stream ball updates + 4) call get_hole_advice
        for i, pt in enumerate(seq, start=1):
            label = pt.get("label", f"pt{i}")
            ball_payload = {
                "contract_version": "0.4.0",
                "session_id": session_id,
                "ball_wgs84": {"lat": float(pt["lat"]), "lon": float(pt["lon"])},
            }
            bresp = client.post(f"{args.backend_url}/api/session/set_ball_location", json=ball_payload)
            bresp.raise_for_status()
            hole_state = (bresp.json().get("hole_state") or {})
            surface_state = hole_state.get("surface_state")
            conf = hole_state.get("surface_confidence")
            print(f"[{label}] set_ball -> surface={surface_state} conf={conf}")

            advice_payload = {"contract_version": "0.4.0", "session_id": session_id, "want_plot": False}
            aresp = client.post(f"{args.backend_url}/api/get_hole_advice", json=advice_payload)
            print(f"[{label}] get_hole_advice -> status={aresp.status_code} plan_type={(aresp.json().get('plan_type'))}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
