'use client';

import Image from "next/image";

interface TestimonialProps {
  quote: string;
  name: string;
  role: string;
  avatarSrc: string;
}

function Testimonial({ quote, name, role, avatarSrc }: TestimonialProps) {
  return (
    <div className="flex flex-col gap-4 rounded-lg border bg-white p-6 shadow-sm">
      <div className="text-sm leading-relaxed text-gray-500">"{quote}"</div>
      <div className="flex items-center gap-3">
        <div className="relative h-10 w-10 overflow-hidden rounded-full">
          <Image
            src={avatarSrc}
            alt={name}
            fill
            className="object-cover"
          />
        </div>
        <div>
          <div className="font-medium">{name}</div>
          <div className="text-xs text-gray-500">{role}</div>
        </div>
      </div>
    </div>
  );
}

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-12 md:py-20">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
          <div className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium bg-green-50 text-green-700 border-green-200 mb-2">
            <span>Testimonials</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">What our users say</h2>
          <p className="max-w-[700px] text-gray-500 md:text-lg">
            Hear from our satisfied users about how our product has transformed their experience.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 mt-8">
          <Testimonial
            quote="This product has changed the way I work. It's intuitive, powerful, and exactly what I needed."
            name="Alex Johnson"
            role="Marketing Director"
            avatarSrc="/placeholder.svg?height=40&width=40"
          />
          <Testimonial
            quote="I've tried many similar tools, but this one stands out with its amazing features and support."
            name="Sarah Williams"
            role="Product Manager"
            avatarSrc="/placeholder.svg?height=40&width=40"
          />
          <Testimonial
            quote="The interface is clean, the features are powerful, and it has helped our team collaboration tremendously."
            name="Michael Brown"
            role="Team Lead"
            avatarSrc="/placeholder.svg?height=40&width=40"
          />
        </div>
      </div>
    </section>
  );
} 