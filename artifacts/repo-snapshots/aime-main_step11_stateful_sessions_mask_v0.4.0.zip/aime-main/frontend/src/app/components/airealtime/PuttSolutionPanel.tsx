import { ChevronDown, ChevronUp, X, MapPin, Route } from "lucide-react";

export type PuttPoint = { x_m: number; y_m: number };

export type PuttSolutionData = {
  fetching?: boolean;
  error?: string;
  request_id?: string;
  dtm_id?: string;
  instruction_text?: string;
  warnings?: string[];
  ball_local?: PuttPoint;
  cup_local?: PuttPoint;
  plot?: { frame: "green_local_m"; points: PuttPoint[] };
  raw?: { dll_return_code: number; dll_error_text?: string };
};

type Props = {
  show: boolean;
  expanded: boolean;
  isSessionActive: boolean;
  connectionStatus: string;
  data: PuttSolutionData | null;
  onToggle: () => void;
  onClose: () => void;
};

export default function PuttSolutionPanel({
  show,
  expanded,
  isSessionActive,
  connectionStatus,
  data,
  onToggle,
  onClose,
}: Props) {
  if (!show) return null;

  const statusDotClass =
    connectionStatus === "connected" && isSessionActive
      ? "bg-green-500"
      : connectionStatus === "connecting"
        ? "bg-yellow-500"
        : connectionStatus === "error"
          ? "bg-red-500"
          : "bg-gray-400";

  const instruction = data?.instruction_text?.trim();
  const warnings = data?.warnings ?? [];
  const plotCount = data?.plot?.points?.length ?? 0;

  return (
    <div className="absolute right-4 top-4 w-[360px] rounded-xl bg-white shadow-lg border border-gray-200 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <span className={`h-2.5 w-2.5 rounded-full ${statusDotClass}`} />
          <div className="font-semibold text-gray-900">Putt Solver</div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onToggle}
            className="p-1 rounded hover:bg-gray-100"
            aria-label={expanded ? "Collapse" : "Expand"}
          >
            {expanded ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-gray-100"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {expanded && (
        <div className="px-4 py-3 space-y-3">
          {/* Status */}
          {data?.fetching && (
            <div className="text-sm text-gray-600">
              Solving putt… (waiting for response)
            </div>
          )}

          {/* Error */}
          {data?.error && (
            <div className="rounded-md bg-red-50 border border-red-200 p-2 text-sm text-red-800">
              {data.error}
            </div>
          )}

          {/* Warnings */}
          {warnings.length > 0 && (
            <div className="rounded-md bg-yellow-50 border border-yellow-200 p-2 text-sm text-yellow-900">
              <div className="font-medium mb-1">Warnings</div>
              <ul className="list-disc pl-5 space-y-1">
                {warnings.slice(0, 5).map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
              </ul>
              {warnings.length > 5 && (
                <div className="text-xs mt-1 opacity-70">
                  +{warnings.length - 5} more…
                </div>
              )}
            </div>
          )}

          {/* Instruction */}
          <div className="rounded-md bg-gray-50 border border-gray-200 p-2">
            <div className="text-sm font-medium text-gray-800 mb-1 flex items-center gap-2">
              <Route size={16} />
              Instruction
            </div>
            <div className="text-sm text-gray-900 whitespace-pre-wrap">
              {instruction || "(No instruction returned)"}
            </div>
          </div>

          {/* Debug metadata */}
          <div className="text-xs text-gray-600 space-y-1">
            {data?.request_id && (
              <div>
                <span className="font-medium">request_id:</span> {data.request_id}
              </div>
            )}
            {data?.dtm_id && (
              <div>
                <span className="font-medium">dtm_id:</span> {data.dtm_id}
              </div>
            )}
            <div>
              <span className="font-medium">plot points:</span> {plotCount}
            </div>

            {(data?.ball_local || data?.cup_local) && (
              <div className="pt-2 border-t border-gray-200">
                <div className="font-medium text-gray-700 mb-1 flex items-center gap-2">
                  <MapPin size={16} />
                  Local coords (m)
                </div>
                {data?.ball_local && (
                  <div>
                    <span className="font-medium">ball:</span> ({data.ball_local.x_m.toFixed(2)}, {data.ball_local.y_m.toFixed(2)})
                  </div>
                )}
                {data?.cup_local && (
                  <div>
                    <span className="font-medium">cup:</span> ({data.cup_local.x_m.toFixed(2)}, {data.cup_local.y_m.toFixed(2)})
                  </div>
                )}
              </div>
            )}

            {data?.raw && (
              <div className="pt-2 border-t border-gray-200">
                <div>
                  <span className="font-medium">dll_return_code:</span> {data.raw.dll_return_code}
                </div>
                {data.raw.dll_error_text && (
                  <div className="text-red-700">
                    <span className="font-medium">dll_error_text:</span>{" "}
                    {data.raw.dll_error_text}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
