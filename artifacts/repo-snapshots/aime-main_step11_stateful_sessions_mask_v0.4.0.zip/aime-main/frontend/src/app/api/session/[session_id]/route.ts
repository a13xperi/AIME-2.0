import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest, { params }: { params: { session_id: string } }) {
  try {
    const backendUrl = process.env.BACKEND_URL || 'http://localhost:8000';
    const sessionId = params.session_id;

    const response = await fetch(`${backendUrl}/api/session/${sessionId}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
    });

    const data = await response.json().catch(() => ({}));
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    console.error('Error proxying session GET to backend:', error);
    return NextResponse.json(
      {
        error: 'Could not connect to backend server',
        serverStatus: 'unreachable',
      },
      { status: 503 }
    );
  }
}
