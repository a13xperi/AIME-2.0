# get_hole_advice (Unified Router)

**Contract version:** `0.4.0`

This endpoint/tool is the **single entrypoint** for hole guidance. It returns **one of**:
- `plan_type = TEE_TO_GREEN` (ball OFF_GREEN)
- `plan_type = PUTT` (ball ON_GREEN or near-green; requires cup/pin location)

---

## Input options (two modes)

### A) Stateless mode (classic)
Provide:
- `course_id`
- `hole_id`
- `ball_wgs84`
- `cup_wgs84` (required only when the ball is ON_GREEN / near-green and we need a putt)

### B) Session mode (preferred for app integration)
Provide:
- `session_id`

In session mode, the backend uses the most recently streamed ball/cup positions for that session.
See `hole_sessions.md` for how to create and update sessions.

---

## Routing behavior
- If the ball is OFF_GREEN and `TEE_TO_GREEN_URL` is set, AIME calls:
  - `{TEE_TO_GREEN_URL}/plan_shot`
- If the ball is OFF_GREEN and `TEE_TO_GREEN_URL` is NOT set, AIME returns a placeholder tee-to-green plan with `next_actions`.
- If the ball is ON_GREEN (or near green), AIME calls the PuttSolver Service.

---

## Surface classification (ON_GREEN vs OFF_GREEN)
AIME uses:
1) **Grid no-data mask** (preferred, if the DTM grid is available and readable).
   - A cell is considered valid if it is not `grid.no_data_value` (default `-1`).
2) **Manifest extents fallback** (rectangular bounds) if the grid mask cannot be used.
3) A **near-boundary UNKNOWN band** (to reduce flicker when near edges or discretization effects).

This classification drives whether we putt vs tee-to-green.

---

## Schemas
- Request: `get_hole_advice.request.schema.json`
- Response: `get_hole_advice.response.schema.json`
- Tool args: `tool.get_hole_advice.args.schema.json`
- Tool output: `tool.get_hole_advice.output.schema.json`

---

## Notes
- `grid.axis_mapping` is a convention hint for mapping `(x_m, y_m)` to grid `(row, col)` indices. If unsure, keep it at the default and validate with real-world spot checks.
- Tee-to-green engines vary widely; this contract keeps `summary` mandatory and makes everything else optional/extendable.
