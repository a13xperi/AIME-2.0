from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import os
from dotenv import load_dotenv
from typing import Dict, Any
from datetime import datetime
from pathlib import Path
import uuid

from aime.data.datasets import DatasetRegistry, DatasetRegistryError
from aime.geo.transforms import wgs84_to_green_local_m, bounds_warnings, TransformError
from aime.clients.putt_solver_client import PuttSolverClient, PuttSolverClientConfig, PuttSolverClientError
from aime.models.putt import SolvePuttArgs, SolvePuttResult, Point2D, PlotData, RawData


# Load environment variables
load_dotenv()

# Configuration from environment variables
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:3000")
DEBUG = os.getenv("DEBUG", "True").lower() in ("true", "1", "t")

# Step 6 scaffold config
REPO_ROOT = Path(__file__).resolve().parent.parent  # aime-main/
COURSE_DATA_ROOT = Path(os.getenv('COURSE_DATA_ROOT', str(REPO_ROOT / 'course_data'))).resolve()
DATASET_REGISTRY_PATH = Path(os.getenv('DATASET_REGISTRY_PATH', str(COURSE_DATA_ROOT / 'datasets.json'))).resolve()
PUTT_SOLVER_URL = os.getenv('PUTT_SOLVER_URL', 'http://localhost:7071')  # mock service default
PUTT_SOLVER_TIMEOUT_S = float(os.getenv('PUTT_SOLVER_TIMEOUT_S', '3.0'))

# Initialize dataset registry + solver client (loaded once at startup)
dataset_registry = DatasetRegistry(COURSE_DATA_ROOT, DATASET_REGISTRY_PATH)
try:
    dataset_registry.load()
except Exception as e:
    # Avoid crashing import; surface error via /health endpoint later if needed
    dataset_registry_error = str(e)
else:
    dataset_registry_error = None

putt_client = PuttSolverClient(PuttSolverClientConfig(base_url=PUTT_SOLVER_URL, timeout_s=PUTT_SOLVER_TIMEOUT_S))

app = FastAPI(
    title="AIME API",
    description="Backend API for AIME POC",
    version="0.1.0",
    debug=DEBUG
)

# Configure CORS to allow requests from the frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_URL],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root() -> Dict[str, Any]:
    """Root endpoint that confirms the API is running."""
    return {
        "status": "ok",
        "message": "Backend API is running",
        "version": "0.1.0",
        "environment": "development" if DEBUG else "production"
    }

@app.get("/api/hello")
def hello_world() -> Dict[str, str]:
    """Simple hello world endpoint for testing."""
    return {"message": "Hello from the backend!"}

@app.get("/api/config")
def get_config() -> Dict[str, Any]:
    """Return configuration information for the client."""
    return {
        "apiVersion": "0.1.0",
        "environment": "development" if DEBUG else "production",
        "features": {
            "logging": True,
            "authentication": True
        }
    }

@app.get("/api/status")
def get_status() -> Dict[str, Any]:
    """Return authentication status for the client."""
    return {
        "authenticated": True,  # For demo, we'll always return true
        "serverTime": datetime.now().isoformat(),
        "serverStatus": "operational"
    }

# Only run the server directly when this file is executed as a script

@app.get('/api/datasets')
def list_registered_datasets() -> Dict[str, Any]:
    """List allowlisted datasets (debug/scaffold)."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')
    out = []
    for rec in dataset_registry.list():
        out.append({
            'dtm_id': rec.dtm_id,
            'course_id': rec.course_id,
            'hole_id': rec.hole_id,
            'green_id': rec.green_id,
            'manifest_path': str(rec.manifest_path),
        })
    return {'datasets': out}

@app.post('/api/solve_putt', response_model=SolvePuttResult)
def solve_putt(args: SolvePuttArgs) -> SolvePuttResult:
    """Resolve dataset, transform WGS84→green_local_m, then call the PuttSolver Service."""
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f'Dataset registry failed to load: {dataset_registry_error}')

    request_id = args.request_id or str(uuid.uuid4())

    try:
        rec = dataset_registry.get_by_course_hole(args.course_id, int(args.hole_id))
        manifest = dataset_registry.load_manifest(rec)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    # Transform ball/cup into green-local meters
    try:
        ball_x, ball_y = wgs84_to_green_local_m(args.ball_wgs84.lat, args.ball_wgs84.lon, manifest)
        cup_x, cup_y = wgs84_to_green_local_m(args.cup_wgs84.lat, args.cup_wgs84.lon, manifest)
    except TransformError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e

    ball_local = {'x_m': ball_x, 'y_m': ball_y}
    cup_local = {'x_m': cup_x, 'y_m': cup_y}

    warnings = []
    warnings += bounds_warnings(ball_x, ball_y, manifest, 'ball_local')
    warnings += bounds_warnings(cup_x, cup_y, manifest, 'cup_local')

    # Stimp defaulting: use provided value, else manifest defaults, else None
    stimp_payload = None
    if args.stimp is not None:
        stimp_payload = {'ft': int(args.stimp.ft), 'in': int(args.stimp.inches)}
    else:
        defaults = (manifest.get('defaults') or {}).get('stimp')
        if isinstance(defaults, dict) and 'ft' in defaults and 'in' in defaults:
            stimp_payload = {'ft': int(defaults['ft']), 'in': int(defaults['in'])}

    # Call the (mock) putt solver service
    try:
        service_resp = putt_client.solve_putt(
            request_id=request_id,
            dtm_id=rec.dtm_id,
            ball_local=ball_local,
            cup_local=cup_local,
            stimp=stimp_payload,
            want_plot=bool(args.want_plot),
        )
    except PuttSolverClientError as e:
        status = getattr(e, 'status_code', None)
        if status in (400, 404):
            raise HTTPException(status_code=int(status), detail=str(e)) from e
        raise HTTPException(status_code=502, detail=str(e)) from e

    # Merge response (always include local points for UI overlay debugging)
    instruction_text = str(service_resp.get('instruction_text', ''))
    plot = service_resp.get('plot')
    raw = service_resp.get('raw')
    service_warnings = service_resp.get('warnings') or []
    if isinstance(service_warnings, list):
        warnings += [str(w) for w in service_warnings]

    plot_model = None
    if isinstance(plot, dict):
        try:
            plot_model = PlotData(**plot)
        except Exception:
            warnings.append('Plot present but failed to validate; verify plot schema')

    raw_model = None
    if isinstance(raw, dict):
        try:
            raw_model = RawData(**raw)
        except Exception:
            warnings.append('Raw solver data present but failed to validate')

    return SolvePuttResult(
        request_id=request_id,
        dtm_id=rec.dtm_id,
        ball_local=Point2D(**ball_local),
        cup_local=Point2D(**cup_local),
        instruction_text=instruction_text,
        plot=plot_model,
        warnings=warnings,
        raw=raw_model,
    )

if __name__ == "__main__":
    import uvicorn
    
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info" if DEBUG else "error"
    ) 
