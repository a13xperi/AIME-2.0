'use client'

import React, { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '../context/auth-context'
import dynamic from 'next/dynamic'

// Import AIRealtime component dynamically to avoid SSR issues with WebRTC
const AIRealtime = dynamic(
  () => import('../components/airealtime/AIRealtime'),
  { ssr: false }
)

export default function DashboardPage() {
  const router = useRouter()
  const { user, logout } = useAuth()

  // Redirect if not logged in
  useEffect(() => {
    if (!user) {
      router.push('/login')
    }
  }, [user, router])

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Main content - AIRealtime now handles its own layout */}
      <div className="flex-1 h-full">
        <AIRealtime apiKey={process.env.NEXT_PUBLIC_API_KEY || ''} />
      </div>
    </div>
  )
} 