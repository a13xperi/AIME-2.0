import type { Metadata } from "next";
import { Inter } from 'next/font/google';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: "Authentication - AIME Golf",
  description: "Log in or create an account for AIME Golf",
};

export default function AuthLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div className={`${inter.variable} antialiased bg-gray-50 min-h-screen`}>
      {children}
    </div>
  );
} 