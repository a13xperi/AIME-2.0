import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // In a production application, you would securely fetch or generate 
    // an ephemeral token here or proxy the request to a backend service
    // that handles authentication with OpenAI.
    
    // For this demo, we'll just use the environment variable directly
    // but in a real application, you should NEVER expose your API key directly to clients
    const apiKey = process.env.OPENAI_API_KEY;
    
    if (!apiKey) {
      return NextResponse.json({ error: 'OpenAI API key not configured' }, { status: 500 });
    }
    
    // Return the token in the format expected by the client - matches the sample code format
    return NextResponse.json({
      client_secret: apiKey
    });
  } catch (error) {
    console.error('Error generating token:', error);
    return NextResponse.json({ error: 'Failed to generate token' }, { status: 500 });
  }
} 