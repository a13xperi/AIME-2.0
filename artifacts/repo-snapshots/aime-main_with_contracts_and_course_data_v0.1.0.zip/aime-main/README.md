# AIME - AI Mobile Experience

AIME is a proof-of-concept application that demonstrates a simple login system with an integrated AI chat interface powered by OpenAI's GPT-4o.

## Features

- Mobile-friendly responsive design
- Simple authentication system (for development purposes)
- Integration with OpenAI's GPT-4o
- Real-time chat interface 
- Network-accessible development server

## Tech Stack

- **Frontend**: Next.js 15, TypeScript, TailwindCSS
- **Backend**: FastAPI, Python
- **AI**: OpenAI GPT-4o

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- Python 3.8+
- Conda environment (optional, but recommended)

### Installation

1. Clone this repository
   ```
   git clone [repository-url]
   cd aime-poc
   ```

2. Set up environment variables
   - Create a `.env.local` file in the `frontend` directory with your OpenAI API key:
   ```
   OPENAI_API_KEY=your-api-key-here
   OPENAI_MODEL=gpt-4o
   ```

3. Start the development servers
   ```
   python start.py
   ```

4. Access the application
   - Local: http://localhost:3000
   - Network: http://your-ip-address:3000

## Usage

1. Sign up or login with any valid email and password (8+ characters)
2. Use the chat interface to interact with the AI assistant

## Project Structure

- `frontend/`: Next.js application
  - `src/app/`: Application code using Next.js App Router
  - `src/app/(auth)/`: Authentication pages (login, signup)
  - `src/app/dashboard/`: Chat interface after login
  - `src/app/api/`: API routes including OpenAI proxy
  
- `backend/`: FastAPI server
  - `main.py`: Main backend application

- `start.py`: Unified development server script

## License

MIT 