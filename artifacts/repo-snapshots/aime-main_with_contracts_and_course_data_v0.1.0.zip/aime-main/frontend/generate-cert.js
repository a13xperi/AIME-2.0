const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Create the certificates directory if it doesn't exist
const certsDir = path.join(__dirname, '.certificates');
if (!fs.existsSync(certsDir)) {
  fs.mkdirSync(certsDir);
}

console.log('Generating self-signed certificate for local development...');

try {
  // Generate a self-signed certificate using OpenSSL
  execSync(`openssl req -x509 -newkey rsa:2048 -nodes -sha256 -subj '/CN=localhost' \
    -keyout ${path.join(certsDir, 'localhost-key.pem')} \
    -out ${path.join(certsDir, 'localhost.pem')} \
    -days 365`, 
    { stdio: 'inherit' });
  
  console.log('Certificate generated successfully!');
  console.log(`Certificate files saved to ${certsDir}`);
  console.log('\nTo trust this certificate in macOS:');
  console.log(`1. Open Keychain Access`);
  console.log(`2. Import ${path.join(certsDir, 'localhost.pem')}`);
  console.log(`3. Double-click the imported certificate`);
  console.log(`4. Expand the "Trust" section`);
  console.log(`5. Change "When using this certificate" to "Always Trust"`);
  console.log(`6. Close the window and enter your password when prompted`);
} catch (error) {
  console.error('Failed to generate certificate:', error.message);
  process.exit(1);
} 