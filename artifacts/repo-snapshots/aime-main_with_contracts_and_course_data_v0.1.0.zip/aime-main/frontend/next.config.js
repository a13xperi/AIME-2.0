const fs = require('fs');
const path = require('path');

/** @type {import('next').NextConfig} */
const nextConfig = {
  // Your existing config options
  devIndicators: false,
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: '/api/:path*',
      },
    ];
  },
  // Ensure we use localhost instead of 0.0.0.0
  webpack: (config, { isServer }) => {
    // Custom webpack config if needed
    return config;
  },
};

// Log environment check on startup
console.log('Environment check:');
console.log('- NODE_ENV:', process.env.NODE_ENV);
console.log('- API key configured:', !!process.env.OPENAI_API_KEY);

// The httpOptions property isn't needed when using --experimental-https
// Next.js now handles the certificates automatically

module.exports = nextConfig; 