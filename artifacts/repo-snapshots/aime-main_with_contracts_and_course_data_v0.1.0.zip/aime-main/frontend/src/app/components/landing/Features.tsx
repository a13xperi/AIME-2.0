'use client';

import { Check, BarChart3, Target, Users, Zap } from "lucide-react";

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="rounded-lg border bg-white p-5 shadow-sm transition-all hover:shadow-md">
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-lg bg-green-50 text-green-600">
        {icon}
      </div>
      <h3 className="mb-2 text-lg font-semibold">{title}</h3>
      <p className="text-gray-500">{description}</p>
    </div>
  );
}

export default function Features() {
  return (
    <section id="features" className="py-12 md:py-20 bg-gray-50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
          <div className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium bg-green-50 text-green-700 border-green-200 mb-2">
            <span>Key Benefits</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">All-in-one solution</h2>
          <p className="max-w-[700px] text-gray-500 md:text-lg">
            Everything you need to succeed, in one powerful platform. We've combined the best tools to give you an edge.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 mt-8">
          <FeatureCard
            icon={<Target className="h-6 w-6" />}
            title="Feature One"
            description="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nunc sit amet ultricies lacinia."
          />
          <FeatureCard
            icon={<BarChart3 className="h-6 w-6" />}
            title="Feature Two"
            description="Praesent sagittis nisl orci, ac euismod purus sodales nec. Sed nisi velit, ultrices id commodo."
          />
          <FeatureCard
            icon={<Users className="h-6 w-6" />}
            title="Feature Three"
            description="Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas."
          />
          <FeatureCard
            icon={<Zap className="h-6 w-6" />}
            title="Feature Four"
            description="Cras fringilla ipsum magna, in fringilla dui commodo a. Fusce pellentesque odio."
          />
          <FeatureCard
            icon={<Check className="h-6 w-6" />}
            title="Feature Five"
            description="Nullam volutpat risus nec leo commodo, ut interdum diam laoreet."
          />
          <FeatureCard
            icon={<BarChart3 className="h-6 w-6" />}
            title="Feature Six"
            description="Vivamus nec odio at quam finibus sollicitudin. Praesent tincidunt facilisis nisl."
          />
        </div>
      </div>
    </section>
  );
} 