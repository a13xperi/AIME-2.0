import { NextRequest, NextResponse } from 'next/server';
import logger from '@/app/lib/logger';

// Create a logger for the weather API
const weatherLogger = logger.createLogger('WeatherAPI');

// Initialize OpenWeatherMap API key
const OPEN_WEATHER_API_KEY = process.env.OPEN_WEATHER_API_KEY;

// Function to get coordinates by city name using the Geocoding API
async function getCoordinatesByCityName(city: string): Promise<{ lat: number; lon: number } | null> {
  try {
    weatherLogger.info(`Getting coordinates for ${city}`);
    
    // Check if this is a ZIP/postal code request (format: "90210, US" or similar)
    const zipCodeMatch = city.match(/^(\d{5,10}),\s*([A-Z]{2})$/);
    if (zipCodeMatch) {
      const [_, zipCode, countryCode] = zipCodeMatch;
      weatherLogger.info(`Detected ZIP code format: ${zipCode}, ${countryCode}`);
      
      try {
        // Use the ZIP code geocoding endpoint
        const url = `https://api.openweathermap.org/geo/1.0/zip?zip=${zipCode},${countryCode}&appid=${OPEN_WEATHER_API_KEY}`;
        
        // Log the request URL (with API key partially hidden)
        const logUrl = url.replace(OPEN_WEATHER_API_KEY || '', '***API_KEY***');
        weatherLogger.info(`ZIP Geocoding API Request: ${logUrl}`);
        
        const response = await fetch(url);
        
        if (!response.ok) {
          const errorText = await response.text();
          weatherLogger.error(`ZIP Geocoding API error: ${response.status}`, { error: errorText });
          // If ZIP fails, we'll fall through to the regular geocoding below
        } else {
          const data = await response.json();
          
          // Log the response data
          weatherLogger.info(`ZIP Geocoding API Response: ${JSON.stringify(data)}`);
          
          if (data && data.lat && data.lon) {
            weatherLogger.info(`Found coordinates for ZIP "${zipCode}": lat=${data.lat}, lon=${data.lon}`);
            return {
              lat: data.lat,
              lon: data.lon
            };
          }
        }
      } catch (error) {
        weatherLogger.error(`Error in ZIP geocoding`, { error, zipCode, countryCode });
        // Continue to regular geocoding as fallback
      }
    }
    
    // Try multiple formats for the location
    const locationFormats = [
      city,                            // Original format
      city.replace(/,\s+/g, ','),      // Remove spaces after commas
      // Add US country code if not already specified
      !city.toLowerCase().includes(', us') && !city.match(/,\s*[a-z]{2}$/i) ? `${city}, US` : city,  
      city.split(',')[0].trim(),       // Try just the city name without state/country
      // Try city name with US appended
      `${city.split(',')[0].trim()}, US`,
      city.replace(/country club/i, '').trim(),  // Remove "Country Club" from name
      city.replace(/golf club/i, '').trim(),     // Remove "Golf Club" from name
      city.replace(/golf course/i, '').trim(),   // Remove "Golf Course" from name
      city.split(' ')[0]               // Try just the first word (for compound names)
    ];
    
    // Try each format until one works
    for (const formattedCity of locationFormats) {
      if (!formattedCity || formattedCity.length < 2) continue; // Skip empty or too short names
      
      weatherLogger.info(`Trying location format: "${formattedCity}"`);
      
      // Build URL for OpenWeatherMap Geocoding API (using HTTPS)
      const url = `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(formattedCity)}&limit=1&appid=${OPEN_WEATHER_API_KEY}`;
      
      // Log the request URL (with API key partially hidden)
      const logUrl = url.replace(OPEN_WEATHER_API_KEY || '', '***API_KEY***');
      weatherLogger.info(`Geocoding API Request: ${logUrl}`);
      
      const response = await fetch(url);
      
      if (!response.ok) {
        const errorText = await response.text();
        weatherLogger.error(`Geocoding API error for "${formattedCity}": ${response.status}`, { error: errorText });
        continue; // Try next format
      }
      
      const data = await response.json();
      
      // Log the response data
      weatherLogger.info(`Geocoding API Response: ${JSON.stringify(data)}`);
      
      if (!data || data.length === 0) {
        weatherLogger.info(`No coordinates found for "${formattedCity}"`);
        continue; // Try next format
      }
      
      weatherLogger.info(`Found coordinates for "${formattedCity}": lat=${data[0].lat}, lon=${data[0].lon}`);
      return {
        lat: data[0].lat,
        lon: data[0].lon
      };
    }
    
    // If we get here, we've tried all formats and none worked
    weatherLogger.error(`Could not find coordinates for any variation of "${city}"`);
    return null;
  } catch (error) {
    weatherLogger.error(`Error getting coordinates for ${city}`, { error });
    return null;
  }
}

// Function to get current weather data by coordinates
async function getWeatherByCoordinates(lat: number, lon: number) {
  try {
    weatherLogger.info(`Getting weather data for coordinates lat=${lat}, lon=${lon}`);
    
    // Get current timestamp
    const now = Math.floor(Date.now() / 1000);
    
    // Build URL for OpenWeatherMap API with imperial units (Fahrenheit)
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=imperial&appid=${OPEN_WEATHER_API_KEY}`;
    
    // Log the request URL (with API key partially hidden)
    const logUrl = url.replace(OPEN_WEATHER_API_KEY || '', '***API_KEY***');
    weatherLogger.info(`Weather API Request: ${logUrl}`);
    
    const response = await fetch(url);
    
    if (!response.ok) {
      const errorText = await response.text();
      weatherLogger.error(`Weather API error: ${response.status}`, { error: errorText });
      return { error: `Failed to fetch weather: ${response.status} - ${errorText}` };
    }
    
    const data = await response.json();
    
    // Log the complete response data
    weatherLogger.info(`Weather API Response: ${JSON.stringify(data)}`);
    
    weatherLogger.info(`Successfully retrieved weather for coordinates`, { temp: data.main.temp });
    
    // Process the data to match our expected format with golf-relevant data
    return {
      location: data.name,
      temperature: Math.round(data.main.temp),
      unit: "fahrenheit",
      description: data.weather[0].description,
      windSpeed: data.wind.speed, // Wind speed in mph (imperial)
      windDirection: data.wind.deg, // Wind direction in degrees
      humidity: data.main.humidity, // Humidity percentage
      pressure: data.main.pressure, // Atmospheric pressure
      visibility: data.visibility, // Visibility in meters
      cloudCover: data.clouds?.all || 0, // Cloud cover percentage
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    weatherLogger.error(`Error getting weather data`, { error, coordinates: { lat, lon } });
    return { error: `Failed to fetch weather: ${error instanceof Error ? error.message : String(error)}` };
  }
}

// Main function to get weather by city name
async function getWeatherByCityName(city: string) {
  try {
    // First get the coordinates
    const coordinates = await getCoordinatesByCityName(city);
    
    if (!coordinates) {
      return { error: `Could not find coordinates for: ${city}` };
    }
    
    // Then get the weather data
    return await getWeatherByCoordinates(coordinates.lat, coordinates.lon);
  } catch (error) {
    weatherLogger.error(`Error in weather pipeline for ${city}`, { error });
    return { error: `Failed to fetch weather: ${error instanceof Error ? error.message : String(error)}` };
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const city = searchParams.get('city');

    if (!city) {
      weatherLogger.error('City parameter missing');
      return NextResponse.json({ error: 'City parameter is required' }, { status: 400 });
    }

    weatherLogger.info(`Processing weather request for city: ${city}`);
    
    // Log API key presence (don't log the key itself)
    weatherLogger.info(`API key configured: ${!!OPEN_WEATHER_API_KEY}`);
    
    if (!OPEN_WEATHER_API_KEY) {
      weatherLogger.error('OpenWeatherMap API key is missing');
      return NextResponse.json({ error: 'API key configuration error' }, { status: 500 });
    }

    const weatherData = await getWeatherByCityName(city);
    
    if ('error' in weatherData) {
      weatherLogger.error(`Error in weather data for ${city}`, { error: weatherData.error });
      return NextResponse.json(weatherData, { status: 500 });
    }
    
    weatherLogger.info(`Successfully returned weather for ${city}`);
    return NextResponse.json(weatherData);
  } catch (error) {
    weatherLogger.error('Unexpected error in weather API route', { error });
    return NextResponse.json({ 
      error: `Server error: ${error instanceof Error ? error.message : String(error)}` 
    }, { status: 500 });
  }
}