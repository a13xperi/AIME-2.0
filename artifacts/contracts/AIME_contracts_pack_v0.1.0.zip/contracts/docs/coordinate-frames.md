# Coordinate Frames & Units (SSOT)

This document defines the **single source of truth** for coordinates used across:
- AIME (tools + UI)
- AIME backend transforms
- Green dataset manifests
- PuttSolver Service (DLL-hosted)

If a value does not match these definitions, it is a bug.

---

## Frame A: `wgs84`
**Type:** geographic  
**EPSG:** 4326  
**Units:** degrees (decimal)

Schema shape:
```json
{ "lat": 40.268251, "lon": -111.659486 }
```

Notes:
- `lat` in `[-90, 90]`
- `lon` in `[-180, 180]`

---

## Frame B: `projected_m`
**Type:** projected planar (course CRS)  
**Units:** meters  
**EPSG:** dataset-specific (example: Riverside uses EPSG 3675)

Schema shape:
```json
{ "x_m": 486435.36, "y_m": 2214826.62, "epsg": 3675 }
```

---

## Frame C: `green_local_m`
**Type:** local planar frame aligned to the green DTM/grid  
**Units:** meters

Schema shape:
```json
{ "x_m": 22.24, "y_m": 10.98 }
```

This is the frame required by the **PuttSolver Service** and is the canonical frame for:
- DTM grid indexing
- Plot/path points returned from the solver
- UI overlays (meters → pixels mapping)

---

## Transformation Chain (authoritative)
All production pipelines should follow:

`wgs84(lat, lon)` → `projected_m(x_m, y_m, epsg)` → `green_local_m(x_m, y_m)`

The transform is defined by fields in `green_manifest.json`:
- `transform.epsg_projected`
- `transform.sp_origin_x_m`, `transform.sp_origin_y_m`
- `transform.local_origin_wgs84`
- `transform.local_offset_x_m`, `transform.local_offset_y_m`
- `transform.rotation_offset_deg`

### Recommended canonical transform equations
Let:
- `(Xsp, Ysp)` be the **projected** coordinates (meters) of a point
- `(X0, Y0)` be `sp_origin_x_m`, `sp_origin_y_m`
- `θ` be `rotation_offset_deg` (degrees)

Compute projected deltas:
- `dx = Xsp - X0`
- `dy = Ysp - Y0`

Apply rotation (convention MUST be locked):
- `x =  cos(θ) * dx - sin(θ) * dy`
- `y =  sin(θ) * dx + cos(θ) * dy`

Apply local offsets:
- `x_local = x + local_offset_x_m`
- `y_local = y + local_offset_y_m`

---

## BLOCKING Uncertainties (must be confirmed)
These items **must be confirmed with the original developer** (or validated by tie-point tests) before production:

1) **Origin corner**: which physical corner of the green is `(0,0)`?
2) **Axis direction**:
   - does increasing `x_m` go “down rows” or “across columns” in the grid?
   - does increasing `y_m` go “up” in the UI or down (pixel-style)?
3) **Rotation sign convention**:
   - is positive rotation clockwise or counterclockwise?
   - is rotation applied projected→local or local→projected?

### MVP default assumptions (UNCONFIRMED)
Until confirmed, we assume:
- `x_m` corresponds to **grid row index** direction (long dimension)
- `y_m` corresponds to **grid column index** direction (short dimension)
- `rotation_offset_deg` uses **standard math CCW** rotation about the origin

These assumptions must be validated using the dataset’s known tie points (e.g., sprinkler coordinates).

---

## Validation Tests (required)
For each dataset:
- **Origin sanity:** Transform `local_origin_wgs84` to `projected_m` and verify it lands near `(sp_origin_x_m, sp_origin_y_m)` within an agreed tolerance.
- **Bounds sanity:** Known ball/cup points must land inside `extents_m`.
- **Tie-point sanity:** If tie points exist (sprinklers), verify they land in plausible locations within bounds.

