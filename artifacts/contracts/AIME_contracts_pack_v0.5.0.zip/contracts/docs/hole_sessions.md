# Hole Sessions (Stateful Updates)

**Contract version:** `0.5.0`

Hole sessions let the client (AIME frontend, mobile app, simulator, etc.) **stream** ball and cup/pin updates without re-sending a full payload on every call.

This is especially useful when:
- the UI continuously updates ball position (dragging, GPS drift, repeated shots),
- pin location is set once, then reused,
- the model/tool calls should not need to carry raw coordinates every time.

---

## Endpoints

### 1) Start session
`POST /api/session/start`

Create a session for a given `course_id` + `hole_id`.

**Request schema:** `session.start.request.schema.json`  
**Response schema:** `session.start.response.schema.json`

Returns:
- `session_id`
- `hole_state` snapshot (may include optional local transforms if positions were provided)

---

### 2) Update ball location
`POST /api/session/set_ball_location`

**Request schema:** `session.set_ball_location.request.schema.json`  
**Response schema:** `session.set_location.response.schema.json`

Updates:
- `ball_wgs84`
- `ball_local_green` (best effort)
- `surface_state` + `surface_confidence` (mask + extents logic)

---

### 3) Update cup/pin location
`POST /api/session/set_cup_location`

**Request schema:** `session.set_cup_location.request.schema.json`  
**Response schema:** `session.set_location.response.schema.json`

Updates:
- `cup_wgs84`
- `cup_local_green` (best effort)

---

### 4) Read session state
`GET /api/session/{session_id}`

Returns the current `HoleStateSnapshot`.

---

## Recommended call flow (client)

1. Start session once per hole:
   - `/api/session/start` → store `session_id`

2. Whenever the ball changes:
   - `/api/session/set_ball_location`

3. When the pin/cup is known or changes:
   - `/api/session/set_cup_location`

4. When you want advice:
   - call `/api/get_hole_advice` with only `{ "session_id": "..." }`
   - (or override specific values if needed)

---

## Implementation notes
- Current implementation is **in-memory** (TTL-based) for Phase 0–1 integration work.
- If you need multi-instance scaling or persistence across restarts, replace the in-memory store with Redis.
