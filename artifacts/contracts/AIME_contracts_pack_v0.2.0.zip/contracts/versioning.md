# Contract Versioning

This repository uses **Semantic Versioning** for integration contracts shared across:
- AIME Frontend tools (Realtime function calling)
- AIME Backend orchestrator endpoints
- PuttSolver Service (DLL-hosted server)
- Dataset manifests (green/DTM metadata)

## Contract Version
Current contract version: `0.2.0`

Every request/response payload **should include**:
- `contract_version`: the schema version the payload conforms to

## Version Bump Rules
- **MAJOR** (`X.0.0`) — breaking changes:
  - removing or renaming fields
  - changing field meaning or units
  - changing required/optional status in a way that breaks old clients
  - changing coordinate frame definitions
- **MINOR** (`0.Y.0`) — backward-compatible additions:
  - adding new optional fields
  - adding new enum values in a backward-compatible way
  - adding new endpoints/tools without changing existing ones
- **PATCH** (`0.0.Z`) — non-breaking documentation or clarifications:
  - typos, comments, examples
  - stricter validation that does not break valid existing payloads

## Compatibility Policy
- AIME Backend should accept the current contract version and (optionally) the previous **minor** version.
- Services should **fail fast** with a clear error when an unsupported `contract_version` is received.

## How to Extend Safely
When adding new data:
1. Prefer adding **optional** fields.
2. Include a clear `frame`/`unit` label for any numeric quantities.
3. Add a matching sample payload under `contracts/samples/`.
4. Update documentation under `contracts/docs/`.
