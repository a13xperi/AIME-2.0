# get_hole_advice (Unified Router)

**Contract version:** `0.2.0`

This endpoint/tool is the single entrypoint for hole guidance.

## When to use
- If you need advice and have the ball position (and optionally cup/pin).
- It will route to:
  - Tee-to-green planning if the ball is off green
  - Putt solving if the ball is on green (requires cup)

## Request
See schema:
- `get_hole_advice.request.schema.json`
- `tool.get_hole_advice.args.schema.json`

## Response
See schema:
- `get_hole_advice.response.schema.json`
- `tool.get_hole_advice.output.schema.json`

## Notes
- Tee-to-green is scaffolded until the upstream planner contract is confirmed.
- Surface classification currently uses manifest extents only.
