# PuttSolver Service Contract (SSOT)

This document defines the **server contract** for the DLL-hosted PuttSolver service.

## Purpose
Expose a stable HTTP API (JSON in/out) that wraps `PuttSolver.dll` so AIME can call it as a tool.

## Key boundary decisions
- The service accepts **`dtm_id`** (allowlisted) — **not** arbitrary filesystem paths.
- The service accepts coordinates in **`green_local_m`** — the AIME backend performs GPS→local transforms.
- The service returns:
  - `instruction_text` (free-text; format currently **UNCONFIRMED**)
  - optional `plot.points` for overlay rendering

## Expected DLL call order (based on exported API)
1. `DLL_SolveSingle(...)`
2. `DLL_GetPlotLength()`
3. allocate `PlotX[]` and `PlotY[]`
4. `DLL_GetPlotData(PlotX, PlotY, LengthX, LengthY)`
5. on error, call `LVDLLStatus(...)` to retrieve readable error text (if supported)

## Known unknowns (BLOCKING)
These must be confirmed with the original developer:
- meaning and safe buffer length for `Instruction[]`
- meaning of `DLL_GetPlotLength()` (points? grid dimension?)
- meaning of `LengthX`/`LengthY` in `DLL_GetPlotData`
- thread-safety / statefulness across calls (can the service be concurrent?)

## Request/Response examples
See:
- `contracts/samples/solve_putt.service.request.sample.json`
- `contracts/samples/solve_putt.service.response.sample.json`
