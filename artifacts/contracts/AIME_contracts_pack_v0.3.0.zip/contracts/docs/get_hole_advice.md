# get_hole_advice (Unified Router)

**Contract version:** `0.3.0`

This endpoint/tool is the **single entrypoint** for hole guidance. It returns **one of**:
- `plan_type = TEE_TO_GREEN` (ball OFF_GREEN)
- `plan_type = PUTT` (ball ON_GREEN or near-green; requires cup/pin location)

---

## When to use
- Anytime you need shot guidance and have at least the ball position.
- Prefer using this tool instead of calling separate solvers directly.

---

## Request
See schema:
- `get_hole_advice.request.schema.json`
- `tool.get_hole_advice.args.schema.json`

Required:
- `course_id`
- `hole_id`
- `ball_wgs84`

Optional:
- `cup_wgs84` (pin) — required for PUTT solutions
- `stimp`
- `want_plot`

---

## Response
See schema:
- `get_hole_advice.response.schema.json`
- `tool.get_hole_advice.output.schema.json`

### Tee-to-Green plan (`plan_type = TEE_TO_GREEN`)
The plan includes a required human-readable:
- `plan.summary`

And may include structured fields if your tee-to-green engine provides them:
- `recommended_club`
- `carry_m`, `total_m`
- `bearing_deg`
- `target_wgs84`

### Putt plan (`plan_type = PUTT`)
The plan includes:
- `instruction_text`
- optional `plot` in `green_local_m`

---

## Routing behavior
- If the ball is OFF_GREEN and `TEE_TO_GREEN_URL` is set, AIME calls:
  - `{TEE_TO_GREEN_URL}/plan_shot`
- If the ball is OFF_GREEN and `TEE_TO_GREEN_URL` is NOT set, AIME returns a placeholder tee-to-green plan with `next_actions`.
- If the ball is ON_GREEN (or near green), AIME calls the PuttSolver Service.

---

## Notes / Known gaps
- Surface classification uses extents + optional margin. For higher accuracy, add a no-data mask check after coordinate frame conventions are confirmed.
- Tee-to-green engines vary widely; this contract keeps `summary` mandatory and makes everything else optional/extendable.
