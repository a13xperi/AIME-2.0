import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    // Get the backend URL from environment or use default
    const backendUrl = process.env.BACKEND_URL || 'http://localhost:8000';
    
    // Forward the request to the backend
    const response = await fetch(`${backendUrl}/api/status`, {
      headers: {
        'Content-Type': 'application/json',
      },
      cache: 'no-store',
    });
    
    // Get the response data
    const data = await response.json();
    
    // Return the response from the backend
    return NextResponse.json(data);
  } catch (error) {
    console.error('Error proxying to backend:', error);
    
    // Return a fallback response if the backend is unreachable
    return NextResponse.json(
      {
        authenticated: false,
        serverTime: new Date().toISOString(),
        serverStatus: 'unreachable',
        error: 'Could not connect to backend server'
      },
      { status: 503 }
    );
  }
} 