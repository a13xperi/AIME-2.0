from __future__ import annotations

import os
import uuid
import threading
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .config import CONTRACT_VERSION, SERVICE_VERSION, load_settings, validate_platform_requirements
from .dataset_registry import DatasetRegistry, DatasetRegistryError, DatasetRecord
from .schemas import SolvePuttRequest, SolvePuttResponse, PlotData, Point2D, RawData
from .dll_wrapper import PuttSolverDLL, DllLoadError, DllCallError


# Load environment variables from .env if present
load_dotenv()

settings = load_settings()

# Registry is required (even in allow_no_dll mode)
dataset_registry = DatasetRegistry(settings.data_root, settings.dataset_registry_path)
dataset_registry_error: Optional[str] = None
try:
    dataset_registry.load()
except Exception as e:
    dataset_registry_error = str(e)

# DLL load is optional only if explicitly allowed
dll: Optional[PuttSolverDLL] = None
dll_load_error: Optional[str] = None

try:
    if not settings.allow_no_dll:
        validate_platform_requirements()

    if settings.dll_path and settings.dll_path.exists():
        dll = PuttSolverDLL(
            dll_path=settings.dll_path,
            instruction_buf_len=settings.instruction_buf_len,
            error_buf_len=settings.error_buf_len,
            max_plot_points=settings.max_plot_points,
            set_cwd_to_dll_dir=settings.set_cwd_to_dll_dir,
        )
        dll.load()
    else:
        raise DllLoadError("PUTT_SOLVER_DLL_PATH not set or file does not exist.")
except Exception as e:
    dll_load_error = str(e)
    if not settings.allow_no_dll:
        # Fail fast in real mode
        raise

# Conservative: serialize calls into the DLL
dll_lock = threading.Lock()

app = FastAPI(
    title="PuttSolver Service (REAL)",
    description="Hosts PuttSolver.dll behind a safe JSON API. Step 7 implementation.",
    version=SERVICE_VERSION,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health() -> Dict[str, Any]:
    status = "ok"
    if dataset_registry_error is not None:
        status = "degraded"
    if dll is None:
        status = "degraded"

    return {
        "status": status,
        "service_version": SERVICE_VERSION,
        "contract_version": CONTRACT_VERSION,
        "dll_loaded": dll is not None,
        "dll_load_error": dll_load_error,
        "dataset_registry_loaded": dataset_registry_error is None,
        "dataset_registry_error": dataset_registry_error,
        "dataset_count": 0 if dataset_registry_error else len(dataset_registry.list()),
    }


@app.get("/datasets")
def list_datasets() -> Dict[str, Any]:
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f"Dataset registry failed to load: {dataset_registry_error}")

    out: List[Dict[str, Any]] = []
    for rec in dataset_registry.list():
        out.append({
            "dtm_id": rec.dtm_id,
            "course_id": rec.course_id,
            "hole_id": rec.hole_id,
            "green_id": rec.green_id,
            "grid_spacing_m": rec.grid_spacing_m,
            "rows": rec.rows,
            "cols": rec.cols,
            "extents_m": rec.extents_m,
            "default_stimp": rec.default_stimp,
        })
    return {"datasets": out}


def _require_in_bounds(pt: Point2D, extents_m: Optional[Dict[str, Any]], label: str) -> None:
    """
    Defensive bounds check using manifest extents.
    Supports both {x_max_m,y_max_m} (current contract) and legacy {x_max,y_max}.
    """
    if not isinstance(extents_m, dict):
        return

    x_max = extents_m.get("x_max_m", extents_m.get("x_max"))
    y_max = extents_m.get("y_max_m", extents_m.get("y_max"))
    if not isinstance(x_max, (int, float)) or not isinstance(y_max, (int, float)):
        return

    if pt.x_m < 0 or pt.y_m < 0 or pt.x_m > float(x_max) or pt.y_m > float(y_max):
        raise HTTPException(
            status_code=400,
            detail={
                "error_code": "OUT_OF_BOUNDS",
                "message": f"{label} is outside dataset extents",
                "details": {"x_m": pt.x_m, "y_m": pt.y_m, "x_max_m": x_max, "y_max_m": y_max},
            },
        )



@app.post("/solve_putt", response_model=SolvePuttResponse)
def solve_putt(req: SolvePuttRequest) -> SolvePuttResponse:
    if dataset_registry_error is not None:
        raise HTTPException(status_code=500, detail=f"Dataset registry failed to load: {dataset_registry_error}")

    if dll is None:
        raise HTTPException(status_code=503, detail=f"DLL not loaded: {dll_load_error or 'unknown error'}")

    request_id = req.request_id or str(uuid.uuid4())

    # Resolve dataset (allowlist)
    try:
        rec: DatasetRecord = dataset_registry.get(req.dtm_id)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    # Defensive bounds checks using manifest extents if available
    _require_in_bounds(req.ball, rec.extents_m, "ball")
    _require_in_bounds(req.cup, rec.extents_m, "cup")

    # Stimp defaulting: use request stimp, else manifest default, else fallback
    stimp_ft = 10.0
    stimp_in = 0.0
    if req.stimp is not None:
        stimp_ft = float(req.stimp.ft)
        stimp_in = float(req.stimp.in_)
    elif isinstance(rec.default_stimp, dict) and "ft" in rec.default_stimp and "in" in rec.default_stimp:
        try:
            stimp_ft = float(rec.default_stimp.get("ft", stimp_ft))
            stimp_in = float(rec.default_stimp.get("in", stimp_in))
        except Exception:
            pass

    warnings: List[str] = []
    if req.want_plot and req.want_plot is True:
        # Optional: could warn if plot length is huge; handled in wrapper cap
        pass

    # Call into DLL (serialized)
    try:
        with dll_lock:
            res = dll.solve_single(
                dtm_path=rec.grid_path,
                hole_x=req.cup.x_m,
                hole_y=req.cup.y_m,
                ball_x=req.ball.x_m,
                ball_y=req.ball.y_m,
                stimp_ft=stimp_ft,
                stimp_in=stimp_in,
                want_plot=bool(req.want_plot),
            )
    except (DllCallError, Exception) as e:
        raise HTTPException(status_code=500, detail=f"DLL call failed: {e}") from e

    plot = None
    if res.plot_points:
        pts = [Point2D(x_m=x, y_m=y) for (x, y) in res.plot_points]
        plot = PlotData(points=pts)

    raw = RawData(dll_return_code=int(res.return_code), dll_error_text=res.dll_error_text)

    return SolvePuttResponse(
        request_id=request_id,
        dtm_id=req.dtm_id,
        instruction_text=res.instruction_text,
        plot=plot,
        warnings=warnings,
        raw=raw,
    )
