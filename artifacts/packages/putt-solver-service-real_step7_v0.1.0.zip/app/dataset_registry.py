from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


class DatasetRegistryError(RuntimeError):
    pass


def _is_within_directory(base: Path, target: Path) -> bool:
    """
    Prevent path traversal by ensuring `target` is within `base`.
    Uses normcase + commonpath for Windows compatibility.
    """
    base_s = os.path.normcase(str(base.resolve()))
    target_s = os.path.normcase(str(target.resolve()))
    try:
        common = os.path.commonpath([base_s, target_s])
    except ValueError:
        return False
    return common == base_s


def safe_resolve_under(base: Path, rel_path: str) -> Path:
    """
    Resolve a relative path under base and reject traversal outside base.
    """
    candidate = (base / rel_path).resolve()
    if not _is_within_directory(base, candidate):
        raise DatasetRegistryError(f"Path traversal detected: {rel_path}")
    return candidate


@dataclass(frozen=True)
class DatasetRecord:
    dtm_id: str
    course_id: str
    hole_id: int
    green_id: str
    grid_path: Path
    manifest_path: Path

    # Optional metadata extracted from manifest
    grid_spacing_m: Optional[float] = None
    rows: Optional[int] = None
    cols: Optional[int] = None
    extents_m: Optional[Dict[str, float]] = None
    default_stimp: Optional[Dict[str, int]] = None


class DatasetRegistry:
    def __init__(self, data_root: Path, registry_path: Path) -> None:
        self.data_root = data_root.resolve()
        self.registry_path = registry_path.resolve()
        self._by_id: Dict[str, DatasetRecord] = {}

    def load(self) -> None:
        if not self.data_root:
            raise DatasetRegistryError("PUTT_SOLVER_DATA_ROOT is not set.")
        if not self.registry_path.exists():
            raise DatasetRegistryError(f"Dataset registry not found: {self.registry_path}")
        if not _is_within_directory(self.data_root, self.registry_path):
            raise DatasetRegistryError("Dataset registry must be inside DATA_ROOT.")

        raw = json.loads(self.registry_path.read_text(encoding="utf-8"))
        datasets = raw.get("datasets")
        if not isinstance(datasets, list):
            raise DatasetRegistryError("datasets.json missing 'datasets' list")

        by_id: Dict[str, DatasetRecord] = {}
        for entry in datasets:
            try:
                dtm_id = str(entry["dtm_id"])
                course_id = str(entry["course_id"])
                hole_id = int(entry["hole_id"])
                green_id = str(entry["green_id"])
                grid_rel = str(entry["grid_path"])
                manifest_rel = str(entry["manifest_path"])
            except Exception as e:
                raise DatasetRegistryError(f"Invalid dataset entry in registry: {entry}") from e

            grid_path = safe_resolve_under(self.data_root, grid_rel)
            manifest_path = safe_resolve_under(self.data_root, manifest_rel)

            # Load manifest metadata (best-effort)
            grid_spacing_m = None
            rows = None
            cols = None
            extents_m = None
            default_stimp = None
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                grid = manifest.get("grid") or {}
                extents_m = manifest.get("extents_m")
                defaults = manifest.get("defaults") or {}
                default_stimp = defaults.get("stimp")
                grid_spacing_m = grid.get("spacing_m")
                rows = grid.get("rows")
                cols = grid.get("cols")
            except Exception:
                # keep optional fields None; validation happens elsewhere
                pass

            rec = DatasetRecord(
                dtm_id=dtm_id,
                course_id=course_id,
                hole_id=hole_id,
                green_id=green_id,
                grid_path=grid_path,
                manifest_path=manifest_path,
                grid_spacing_m=grid_spacing_m if isinstance(grid_spacing_m, (int, float)) else None,
                rows=rows if isinstance(rows, int) else None,
                cols=cols if isinstance(cols, int) else None,
                extents_m=extents_m if isinstance(extents_m, dict) else None,
                default_stimp=default_stimp if isinstance(default_stimp, dict) else None,
            )
            by_id[dtm_id] = rec

        self._by_id = by_id

    def get(self, dtm_id: str) -> DatasetRecord:
        rec = self._by_id.get(dtm_id)
        if rec is None:
            raise DatasetRegistryError(f"Unknown dtm_id: {dtm_id}")
        return rec

    def list(self) -> List[DatasetRecord]:
        return list(self._by_id.values())
