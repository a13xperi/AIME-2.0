from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path


SERVICE_VERSION = "0.1.0"
CONTRACT_VERSION = "0.1.0"


def _to_int(value: str | None, default: int) -> int:
    try:
        return int(value) if value is not None else default
    except ValueError:
        return default


def _to_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in ("1", "true", "yes", "y", "on")


@dataclass(frozen=True)
class Settings:
    dll_path: Path
    data_root: Path
    dataset_registry_path: Path
    port: int
    instruction_buf_len: int
    error_buf_len: int
    max_plot_points: int
    set_cwd_to_dll_dir: bool
    allow_no_dll: bool
    log_level: str


def load_settings() -> Settings:
    """
    Reads env vars and returns validated settings.
    Defaults are intentionally conservative and safe.
    """
    dll_path = Path(os.getenv("PUTT_SOLVER_DLL_PATH", "")).expanduser()
    data_root = Path(os.getenv("PUTT_SOLVER_DATA_ROOT", "")).expanduser()
    dataset_registry = Path(os.getenv("PUTT_SOLVER_DATASET_REGISTRY", "")).expanduser()

    port = _to_int(os.getenv("PUTT_SOLVER_PORT"), 7071)
    instruction_buf_len = _to_int(os.getenv("PUTT_SOLVER_INSTRUCTION_BUF_LEN"), 4096)
    error_buf_len = _to_int(os.getenv("PUTT_SOLVER_ERROR_BUF_LEN"), 2048)
    max_plot_points = _to_int(os.getenv("PUTT_SOLVER_MAX_PLOT_POINTS"), 4096)

    set_cwd_to_dll_dir = _to_bool(os.getenv("PUTT_SOLVER_SET_CWD_TO_DLL_DIR"), True)
    allow_no_dll = _to_bool(os.getenv("PUTT_SOLVER_ALLOW_NO_DLL"), False)
    log_level = os.getenv("PUTT_SOLVER_LOG_LEVEL", "info").lower()

    # Defaults for data paths if not provided explicitly
    if not dataset_registry and data_root:
        dataset_registry = data_root / "datasets.json"

    return Settings(
        dll_path=dll_path,
        data_root=data_root,
        dataset_registry_path=dataset_registry,
        port=port,
        instruction_buf_len=instruction_buf_len,
        error_buf_len=error_buf_len,
        max_plot_points=max_plot_points,
        set_cwd_to_dll_dir=set_cwd_to_dll_dir,
        allow_no_dll=allow_no_dll,
        log_level=log_level,
    )


def validate_platform_requirements() -> None:
    """
    This service is intended to run on Windows x64 because the target DLL is PE32+ (x64).
    We fail fast to avoid confusing runtime errors.
    """
    if sys.platform != "win32":
        raise RuntimeError("PuttSolver service must run on Windows (win32 platform).")
    if "64" not in (os.environ.get("PROCESSOR_ARCHITECTURE", "") + os.environ.get("PROCESSOR_ARCHITEW6432", "")):
        # Not perfect, but catches common 32-bit cases.
        raise RuntimeError("PuttSolver service requires a 64-bit Windows environment.")
