from __future__ import annotations

import os
import sys
import ctypes
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple


class DllLoadError(RuntimeError):
    pass


class DllCallError(RuntimeError):
    pass


@dataclass(frozen=True)
class SolveResult:
    return_code: int
    instruction_text: str
    plot_points: Optional[List[Tuple[float, float]]] = None
    dll_error_text: Optional[str] = None


class PuttSolverDLL:
    """
    Thin ctypes wrapper around PuttSolver.dll.
    Assumptions are documented and configurable where possible.

    IMPORTANT: Calls may not be thread-safe. Callers should serialize access.
    """

    def __init__(self, dll_path: Path, instruction_buf_len: int = 4096, error_buf_len: int = 2048, max_plot_points: int = 4096, set_cwd_to_dll_dir: bool = True) -> None:
        self.dll_path = dll_path
        self.instruction_buf_len = instruction_buf_len
        self.error_buf_len = error_buf_len
        self.max_plot_points = max_plot_points
        self.set_cwd_to_dll_dir = set_cwd_to_dll_dir

        self._dll = None  # type: ignore

    def load(self) -> None:
        if sys.platform != "win32":
            raise DllLoadError("PuttSolverDLL can only be loaded on Windows.")
        if not self.dll_path.exists():
            raise DllLoadError(f"DLL not found: {self.dll_path}")

        dll_dir = self.dll_path.parent

        # Ensure dependent DLLs in the same folder can be found
        if hasattr(os, "add_dll_directory"):
            try:
                os.add_dll_directory(str(dll_dir))
            except Exception:
                pass

        if self.set_cwd_to_dll_dir:
            try:
                os.chdir(str(dll_dir))
            except Exception:
                pass

        try:
            # __cdecl → CDLL
            self._dll = ctypes.CDLL(str(self.dll_path))
        except OSError as e:
            raise DllLoadError(f"Failed to load DLL: {e}") from e

        self._bind_functions()

    def _bind_functions(self) -> None:
        assert self._dll is not None

        # int32 DLL_SolveSingle(double HoleX, double HoleY, double BallX, double BallY,
        #                      double StimpFt, double StimpIn,
        #                      char Instruction[], int32 InstructionLength,
        #                      char DTMPath[])
        self._dll.DLL_SolveSingle.argtypes = [
            ctypes.c_double, ctypes.c_double,
            ctypes.c_double, ctypes.c_double,
            ctypes.c_double, ctypes.c_double,
            ctypes.POINTER(ctypes.c_char), ctypes.c_int32,
            ctypes.c_char_p,
        ]
        self._dll.DLL_SolveSingle.restype = ctypes.c_int32

        # int32 DLL_GetPlotLength(void)
        self._dll.DLL_GetPlotLength.argtypes = []
        self._dll.DLL_GetPlotLength.restype = ctypes.c_int32

        # void DLL_GetPlotData(double PlotX[], double PlotY[], int32 LengthX, int32 LengthY)
        self._dll.DLL_GetPlotData.argtypes = [
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(ctypes.c_double),
            ctypes.c_int32,
            ctypes.c_int32,
        ]
        self._dll.DLL_GetPlotData.restype = None

        # MgErr LVDLLStatus(char *errStr, int errStrLen, void *module)
        if hasattr(self._dll, "LVDLLStatus"):
            self._dll.LVDLLStatus.argtypes = [
                ctypes.POINTER(ctypes.c_char),
                ctypes.c_int,
                ctypes.c_void_p,
            ]
            self._dll.LVDLLStatus.restype = ctypes.c_int32

    def _get_lv_error_text(self) -> Optional[str]:
        """
        Best-effort retrieval of LabVIEW-style error text.
        Requires LVDLLStatus export; module handle is passed as the loaded DLL handle.
        """
        if self._dll is None or not hasattr(self._dll, "LVDLLStatus"):
            return None

        try:
            buf = ctypes.create_string_buffer(self.error_buf_len)
            module = ctypes.c_void_p(getattr(self._dll, "_handle", 0))
            self._dll.LVDLLStatus(buf, self.error_buf_len, module)
            text = buf.value.decode("utf-8", errors="replace").strip("\x00").strip()
            return text or None
        except Exception:
            return None

    def solve_single(
        self,
        dtm_path: Path,
        hole_x: float,
        hole_y: float,
        ball_x: float,
        ball_y: float,
        stimp_ft: float,
        stimp_in: float,
        want_plot: bool = True,
    ) -> SolveResult:
        if self._dll is None:
            raise DllCallError("DLL not loaded")

        instruction_buf = ctypes.create_string_buffer(self.instruction_buf_len)
        dtm_bytes = str(dtm_path).encode("utf-8")

        try:
            rc = int(self._dll.DLL_SolveSingle(
                ctypes.c_double(hole_x),
                ctypes.c_double(hole_y),
                ctypes.c_double(ball_x),
                ctypes.c_double(ball_y),
                ctypes.c_double(stimp_ft),
                ctypes.c_double(stimp_in),
                instruction_buf,
                ctypes.c_int32(self.instruction_buf_len),
                ctypes.c_char_p(dtm_bytes),
            ))
        except Exception as e:
            raise DllCallError(f"DLL_SolveSingle call failed: {e}") from e

        instruction = instruction_buf.value.decode("utf-8", errors="replace").strip("\x00").strip()
        err_text = None
        if rc != 0:
            err_text = self._get_lv_error_text()

        plot_points = None
        if want_plot and rc == 0:
            plot_points = self._get_plot_points()

        return SolveResult(return_code=rc, instruction_text=instruction, plot_points=plot_points, dll_error_text=err_text)

    def _get_plot_points(self) -> Optional[List[Tuple[float, float]]]:
        """
        Retrieves plot polyline points.
        Assumption: GetPlotLength returns N, and both PlotX and PlotY arrays have length N.
        We pass LengthX=N and LengthY=N.

        This should be confirmed with the original developer.
        """
        assert self._dll is not None

        try:
            n = int(self._dll.DLL_GetPlotLength())
        except Exception:
            return None

        if n <= 0:
            return None
        if n > self.max_plot_points:
            # defensive cap
            n = self.max_plot_points

        xs = (ctypes.c_double * n)()
        ys = (ctypes.c_double * n)()

        try:
            self._dll.DLL_GetPlotData(xs, ys, ctypes.c_int32(n), ctypes.c_int32(n))
        except Exception:
            return None

        pts: List[Tuple[float, float]] = []
        for i in range(n):
            pts.append((float(xs[i]), float(ys[i])))
        return pts
