# PuttSolver Service (REAL DLL Wrapper) — Step 7

This service hosts **PuttSolver.dll** behind a safe HTTP API:
- `GET /health`
- `GET /datasets`
- `POST /solve_putt`

## Safety / trust note
This service loads and calls a native Windows DLL. Only run it if you trust the DLL provenance.
For first-time validation, use an isolated Windows VM with **no network** (or tightly controlled network), snapshots enabled, and minimal privileges.

## Requirements
- Windows x64
- Python x64 (recommended 3.9+)
- PuttSolver.dll + any sidecar files (e.g., `PuttSolver.ini`, `PuttSolver.aliases`)
- Dataset pack (e.g., `aime-main/course_data`) containing `datasets.json`

## Quick start (Windows)
1) Create venv + install deps:
```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

2) Set environment variables (example):
```bat
set PUTT_SOLVER_DLL_PATH=C:\path\to\PuttSolver.dll
set PUTT_SOLVER_DATA_ROOT=C:\path\to\aime-main\course_data
set PUTT_SOLVER_DATASET_REGISTRY=%PUTT_SOLVER_DATA_ROOT%\datasets.json
set PUTT_SOLVER_PORT=7071
```

3) Ensure sidecar files are in place:
- Recommended: keep `PuttSolver.ini` and `PuttSolver.aliases` **in the same folder** as `PuttSolver.dll`.

4) Run:
```bat
python -m uvicorn app.main:app --host 0.0.0.0 --port %PUTT_SOLVER_PORT%
```

## Test
```bat
curl http://localhost:7071/health
curl http://localhost:7071/datasets
```

Solve (local coords example — adjust to your bounds):
```bat
curl -X POST http://localhost:7071/solve_putt ^
  -H "Content-Type: application/json" ^
  -d "{\"dtm_id\":\"riverside_2023_20cm\",\"ball\":{\"x_m\":22.0,\"y_m\":11.0},\"cup\":{\"x_m\":13.4,\"y_m\":15.0},\"want_plot\":true}"
```

## Notes
- Calls into the DLL are **serialized** by a global lock (safe default).
- `GetPlotData` length parameters are passed as `(n, n)` where `n = GetPlotLength()`. This matches common LabVIEW array signatures but should be confirmed with the developer.
