# course_data (Pilot)

This folder contains the pilot course dataset for **riverside_2023_20cm**.

## Structure
- `datasets.json` — dataset registry (allowlist)
- `ovation/riverside/hole_01/green/green_manifest.json` — generated manifest (SSOT for dataset metadata)
- `ovation/riverside/hole_01/green/dtm/Riverside_20cm_Grid.txt` — DTM/grid file (tab-delimited)
- `ovation/riverside/hole_01/green/source/Riverside_2023.ini` — original Ovation metadata source

## Notes
- Coordinates for solver calls should be in `green_local_m` as defined in `contracts/docs/coordinate-frames.md`.
- `green_manifest.json` currently marks axis/rotation conventions as **UNCONFIRMED** until verified with the original developer.
