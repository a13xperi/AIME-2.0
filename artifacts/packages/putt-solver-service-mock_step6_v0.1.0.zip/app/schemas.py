from __future__ import annotations

from typing import List, Optional
from pydantic import BaseModel, Field, ConfigDict


class Point2D(BaseModel):
    x_m: float
    y_m: float


class Stimp(BaseModel):
    ft: int = Field(12, ge=0, le=30)
    inches: int = Field(0, alias="in", ge=0, le=11)

    model_config = ConfigDict(populate_by_name=True)


class SolvePuttRequest(BaseModel):
    request_id: Optional[str] = None
    dtm_id: str
    ball: Point2D
    cup: Point2D
    stimp: Optional[Stimp] = None
    want_plot: bool = True


class PlotData(BaseModel):
    frame: str = "green_local_m"
    points: List[Point2D]


class RawData(BaseModel):
    dll_return_code: int
    dll_error_text: Optional[str] = None


class SolvePuttResponse(BaseModel):
    request_id: str
    dtm_id: str
    instruction_text: str
    plot: Optional[PlotData] = None
    warnings: List[str] = Field(default_factory=list)
    raw: RawData
