from __future__ import annotations

import math
import uuid
from pathlib import Path
from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .config import CONTRACT_VERSION, DATA_ROOT, SERVICE_VERSION
from .dataset_registry import DatasetRegistry, DatasetRegistryError
from .schemas import SolvePuttRequest, SolvePuttResponse, PlotData, Point2D, RawData


app = FastAPI(
    title="PuttSolver Service (MOCK)",
    version=SERVICE_VERSION,
    description="Mock service for validating AIME integration. Does NOT execute DLLs.",
)

# CORS: allow all for scaffold (tighten later)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_registry: DatasetRegistry | None = None


def get_registry() -> DatasetRegistry:
    global _registry
    if _registry is not None:
        return _registry

    if not DATA_ROOT:
        raise RuntimeError("DATA_ROOT env var is required (path to course_data directory).")

    reg = DatasetRegistry(Path(DATA_ROOT))
    reg.load()
    _registry = reg
    return reg


@app.get("/health")
def health() -> Dict[str, Any]:
    ok = True
    err: str | None = None
    dataset_count = 0
    try:
        dataset_count = len(get_registry().list())
    except Exception as e:
        ok = False
        err = str(e)

    return {
        "status": "ok" if ok else "error",
        "service_version": SERVICE_VERSION,
        "contract_version": CONTRACT_VERSION,
        "dataset_count": dataset_count,
        "error": err,
    }


@app.get("/datasets")
def list_datasets() -> Dict[str, Any]:
    reg = get_registry()
    out: List[Dict[str, Any]] = []
    for rec in reg.list():
        m = reg.load_manifest(rec.dtm_id)
        out.append({
            "dtm_id": rec.dtm_id,
            "course_id": rec.course_id,
            "hole_id": rec.hole_id,
            "green_id": rec.green_id,
            "extents_m": m.get("extents_m"),
            "defaults": m.get("defaults"),
        })
    return {"contract_version": CONTRACT_VERSION, "datasets": out}


def _validate_in_bounds(p: Point2D, extents: Dict[str, Any], label: str) -> List[str]:
    warnings: List[str] = []
    x_max = float(extents.get("x_max_m", 0.0))
    y_max = float(extents.get("y_max_m", 0.0))
    if not (0.0 <= p.x_m <= x_max):
        raise HTTPException(status_code=400, detail=f"{label}.x_m out of bounds: {p.x_m} (expected 0..{x_max})")
    if not (0.0 <= p.y_m <= y_max):
        raise HTTPException(status_code=400, detail=f"{label}.y_m out of bounds: {p.y_m} (expected 0..{y_max})")
    return warnings


@app.post("/solve_putt", response_model=SolvePuttResponse)
def solve_putt(req: SolvePuttRequest) -> SolvePuttResponse:
    reg = get_registry()

    try:
        manifest = reg.load_manifest(req.dtm_id)
    except DatasetRegistryError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    extents = manifest.get("extents_m") or {}
    warnings: List[str] = []

    warnings += _validate_in_bounds(req.ball, extents, "ball")
    warnings += _validate_in_bounds(req.cup, extents, "cup")

    # Deterministic mock “instruction”
    dx = req.cup.x_m - req.ball.x_m
    dy = req.cup.y_m - req.ball.y_m
    dist_m = math.hypot(dx, dy)
    direction_deg = (math.degrees(math.atan2(dy, dx)) + 360.0) % 360.0

    instruction = (
        f"MOCK SOLVER (not DLL): Distance {dist_m:.2f} m. "
        f"Direction {direction_deg:.1f}° in green_local_m. "
        f"Aim straight to cup; speed ~medium."
    )

    plot = None
    if req.want_plot:
        # Straight line plot from ball to cup
        n = 50
        pts = []
        for i in range(n):
            t = i / (n - 1)
            pts.append(Point2D(x_m=req.ball.x_m + t * dx, y_m=req.ball.y_m + t * dy))
        plot = PlotData(points=pts)

    request_id = req.request_id or str(uuid.uuid4())

    return SolvePuttResponse(
        request_id=request_id,
        dtm_id=req.dtm_id,
        instruction_text=instruction,
        plot=plot,
        warnings=warnings,
        raw=RawData(dll_return_code=0),
    )
