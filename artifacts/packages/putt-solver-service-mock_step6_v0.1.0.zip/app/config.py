from __future__ import annotations

import os
from dotenv import load_dotenv

load_dotenv()

SERVICE_VERSION = os.getenv("SERVICE_VERSION", "0.1.0-mock")
CONTRACT_VERSION = os.getenv("CONTRACT_VERSION", "0.1.0")

DATA_ROOT = os.getenv("DATA_ROOT")  # required for datasets.json resolution
