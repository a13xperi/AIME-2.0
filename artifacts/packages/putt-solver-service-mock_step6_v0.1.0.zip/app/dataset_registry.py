from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


class DatasetRegistryError(RuntimeError):
    pass


@dataclass(frozen=True)
class DatasetRecord:
    course_id: str
    hole_id: int
    green_id: str
    dtm_id: str
    manifest_path: Path
    grid_path: Path
    source_ini_path: Optional[Path] = None


class DatasetRegistry:
    def __init__(self, data_root: Path) -> None:
        self.data_root = data_root.resolve()
        self.registry_path = self.data_root / "datasets.json"
        self._records: Dict[str, DatasetRecord] = {}
        self._raw: Dict[str, Any] = {}

    def load(self) -> None:
        if not self.registry_path.exists():
            raise DatasetRegistryError(f"datasets.json not found at: {self.registry_path}")

        self._raw = json.loads(self.registry_path.read_text(encoding="utf-8"))
        datasets = self._raw.get("datasets", [])
        if not isinstance(datasets, list):
            raise DatasetRegistryError("datasets.json: 'datasets' must be a list")

        records: Dict[str, DatasetRecord] = {}
        for d in datasets:
            try:
                dtm_id = str(d["dtm_id"])
                course_id = str(d["course_id"])
                hole_id = int(d["hole_id"])
                green_id = str(d.get("green_id", ""))
                manifest_rel = Path(str(d["manifest_path"]))
                grid_rel = Path(str(d["grid_path"]))
                ini_rel = d.get("source_ini_path")
                ini_path = Path(str(ini_rel)) if ini_rel else None

                manifest_path = (self.data_root / manifest_rel).resolve()
                grid_path = (self.data_root / grid_rel).resolve()
                source_ini_path = (self.data_root / ini_path).resolve() if ini_path else None

                # Anti-traversal: ensure resolved paths stay under data_root
                for p in [manifest_path, grid_path] + ([source_ini_path] if source_ini_path else []):
                    if p is None:
                        continue
                    if self.data_root not in p.parents and p != self.data_root:
                        raise DatasetRegistryError(f"Resolved path escapes DATA_ROOT: {p}")

                records[dtm_id] = DatasetRecord(
                    course_id=course_id,
                    hole_id=hole_id,
                    green_id=green_id,
                    dtm_id=dtm_id,
                    manifest_path=manifest_path,
                    grid_path=grid_path,
                    source_ini_path=source_ini_path,
                )
            except KeyError as e:
                raise DatasetRegistryError(f"datasets.json missing field: {e}") from e

        self._records = records

    def list(self) -> List[DatasetRecord]:
        return list(self._records.values())

    def get(self, dtm_id: str) -> DatasetRecord:
        if dtm_id not in self._records:
            raise DatasetRegistryError(f"Unknown dtm_id: {dtm_id}")
        return self._records[dtm_id]

    def load_manifest(self, dtm_id: str) -> Dict[str, Any]:
        rec = self.get(dtm_id)
        if not rec.manifest_path.exists():
            raise DatasetRegistryError(f"Manifest not found: {rec.manifest_path}")
        return json.loads(rec.manifest_path.read_text(encoding="utf-8"))
