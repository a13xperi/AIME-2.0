# PuttSolver Service (MOCK) — Step 6 Scaffold

This is a **mock** replacement for the real `PuttSolver.dll` host service.
It exists to validate the integration plumbing:
- dataset allowlisting via `dtm_id`
- request/response JSON contract
- AIME backend → solver service networking

**It does NOT load or execute any DLLs.**

## Run (Windows or macOS/Linux)
```bash
cd putt-solver-service-mock
python -m venv .venv
# Windows
.\.venv\Scripts\activate
# macOS/Linux
# source .venv/bin/activate

pip install -r requirements.txt

# Point to the AIME course_data directory containing datasets.json
# Windows (PowerShell):
$env:DATA_ROOT="C:\path\to\aime-main\course_data"
# macOS/Linux:
# export DATA_ROOT="/path/to/aime-main/course_data"

uvicorn app.main:app --host 0.0.0.0 --port 7071 --reload
```

## Endpoints
- `GET /health`
- `GET /datasets`
- `POST /solve_putt` (returns a deterministic mock instruction + a straight-line plot)

## Notes
- The service refuses unknown `dtm_id`s.
- It validates ball/cup coords against dataset extents (from green_manifest.json).
