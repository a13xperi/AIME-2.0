# Tee-to-Green Mock Service (Step 10)

**Contract version:** `0.3.0`

This is a lightweight mock tee-to-green planner that supports:
- `GET /health`
- `POST /plan_shot`

It is intended for **integration testing** with AIME's unified `get_hole_advice` router.

## Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 7072
```

## Configure AIME
Set:
- `TEE_TO_GREEN_URL=http://localhost:7072`

Then call:
- `POST http://localhost:8000/api/get_hole_advice`
