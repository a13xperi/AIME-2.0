from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
import math
import uuid

CONTRACT_VERSION = "0.3.0"

app = FastAPI(title="Tee-to-Green Mock Service", version=CONTRACT_VERSION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class GeoPointWGS84(BaseModel):
    lat: float = Field(..., ge=-90.0, le=90.0)
    lon: float = Field(..., ge=-180.0, le=180.0)

class TeeToGreenRequest(BaseModel):
    contract_version: str = Field(CONTRACT_VERSION)
    request_id: Optional[str] = None
    course_id: str
    hole_id: int
    ball_wgs84: GeoPointWGS84
    pin_wgs84: Optional[GeoPointWGS84] = None
    player: Optional[Dict[str, Any]] = None
    conditions: Optional[Dict[str, Any]] = None

class TeeToGreenResponse(BaseModel):
    contract_version: str = Field(CONTRACT_VERSION)
    request_id: str
    summary: str
    recommended_club: Optional[str] = None
    carry_m: Optional[float] = None
    total_m: Optional[float] = None
    bearing_deg: Optional[float] = None
    target_wgs84: Optional[GeoPointWGS84] = None
    confidence: Optional[float] = None
    debug: Optional[Dict[str, Any]] = None

def haversine_m(lat1, lon1, lat2, lon2) -> float:
    # returns distance in meters
    R = 6371000.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

def bearing_deg(lat1, lon1, lat2, lon2) -> float:
    # initial bearing in degrees from north
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dlambda = math.radians(lon2 - lon1)
    y = math.sin(dlambda) * math.cos(phi2)
    x = math.cos(phi1)*math.sin(phi2) - math.sin(phi1)*math.cos(phi2)*math.cos(dlambda)
    brng = math.degrees(math.atan2(y, x))
    return (brng + 360.0) % 360.0

def club_from_distance_m(dist_m: float) -> str:
    # very rough mapping (mock only)
    yd = dist_m * 1.0936133
    if yd > 230: return "Driver"
    if yd > 200: return "3-wood"
    if yd > 180: return "5-wood"
    if yd > 165: return "4-iron"
    if yd > 150: return "6-iron"
    if yd > 135: return "7-iron"
    if yd > 120: return "8-iron"
    if yd > 105: return "9-iron"
    if yd > 85:  return "Pitching Wedge"
    return "Sand Wedge"

@app.get("/health")
def health():
    return {"ok": True, "contract_version": CONTRACT_VERSION}

@app.post("/plan_shot", response_model=TeeToGreenResponse)
def plan_shot(req: TeeToGreenRequest) -> TeeToGreenResponse:
    rid = req.request_id or str(uuid.uuid4())

    # If pin is known, plan toward it; otherwise return a generic “advance” plan
    if req.pin_wgs84 is None:
        return TeeToGreenResponse(
            request_id=rid,
            summary="Mock tee-to-green: pin not provided; advance the ball safely toward the green.",
            recommended_club="7-iron",
            confidence=0.35,
            debug={"note": "Provide pin_wgs84 to get distance/bearing."},
        )

    dist_m = haversine_m(req.ball_wgs84.lat, req.ball_wgs84.lon, req.pin_wgs84.lat, req.pin_wgs84.lon)
    brng = bearing_deg(req.ball_wgs84.lat, req.ball_wgs84.lon, req.pin_wgs84.lat, req.pin_wgs84.lon)

    club = club_from_distance_m(dist_m)
    # mock carry/total relationship
    carry = max(0.0, dist_m * 0.93)
    total = dist_m

    summary = f"Mock tee-to-green: aim on bearing {brng:.0f}° and favor a controlled swing toward the pin. Estimated distance: {dist_m:.0f}m."

    return TeeToGreenResponse(
        request_id=rid,
        summary=summary,
        recommended_club=club,
        carry_m=carry,
        total_m=total,
        bearing_deg=brng,
        target_wgs84=req.pin_wgs84,
        confidence=0.55,
        debug={
            "distance_m": dist_m,
            "course_id": req.course_id,
            "hole_id": req.hole_id,
            "mock": True,
        },
    )
