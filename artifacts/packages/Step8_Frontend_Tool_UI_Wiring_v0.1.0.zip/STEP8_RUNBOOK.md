# Step 8 — AIME Frontend Tool + UI Wiring (solve_putt)
**Objective:** wire the AIME UI so the model can call `solve_putt`, AIME executes it via `/api/solve_putt`, then displays the result (instruction + debug plot info) in a panel.

> This step assumes Step 6 (backend endpoint + proxy) and Step 7 (real solver service) are in place.

---

## 0) Prereqs
- AIME backend running (FastAPI) with:
  - `POST /api/solve_putt`
- Next.js route exists:
  - `POST /api/solve_putt` → proxies to backend
- PuttSolver Service running on Windows and reachable from the backend:
  - `PUTT_SOLVER_URL=http://<windows-host>:7071`

**Sanity checks:**
- `GET http://localhost:8000/api/datasets` returns Riverside dtm_id
- `GET http://<windows-host>:7071/health` returns ok

---

## 1) Add the PuttSolutionPanel component (new file)
Add:
- `frontend/src/app/components/airealtime/PuttSolutionPanel.tsx`

This is a lightweight panel that displays:
- connection status dot
- instruction text
- request_id / dtm_id
- plot points count
- errors + warnings

---

## 2) (Optional) Add GreenOverlay component for path plotting
Add:
- `frontend/src/app/components/greens/GreenOverlay.tsx`

This can draw:
- ball marker
- cup marker
- polyline path

> Overlay mapping requires `extents_m` in the response (x_max/y_max). If you don’t have that wired yet, keep overlay as debug-only.

---

## 3) Wire the solve_putt tool into AIRealtime.tsx
You will:
1) import the panel
2) add state
3) register the `solve_putt` tool in `session.update.session.tools`
4) add a tool handler that calls `/api/solve_putt`
5) render the panel

Use the snippet file:
- `STEP8_SNIPPETS.md` (included in this pack)

---

## 4) Acceptance Criteria (Gate for Step 8)
- [ ] In a live AIME session, the model can call `solve_putt`
- [ ] AIME performs the request to `/api/solve_putt`
- [ ] The panel shows:
  - instruction_text (or a clean error)
  - request_id
  - dtm_id
  - plot points count (if requested)
- [ ] Tool output is returned back to the model via `function_call_output`
- [ ] No silent failures (every error is visible in panel)

---

## 5) Quick test plan (manual)
1) Start PuttSolver Service on Windows (Step 7)
2) Start AIME backend with `PUTT_SOLVER_URL` pointing to the Windows service
3) Start Next.js frontend
4) In the UI, ask:

> “Call solve_putt for course_id riverside hole_id 1. Use the dataset local_origin_wgs84 for ball and move the cup slightly north.”

If everything is wired correctly:
- tool executes
- panel shows instruction
- assistant speaks a summary

---

## 6) Known unknowns (still blocked by developer answers)
These do not block Step 8 plumbing, but affect correctness:
- origin corner for green_local frame
- axis direction mapping (row/col to x/y)
- rotation sign convention
- plot LengthX/LengthY semantics

Once confirmed, update:
- `contracts/docs/coordinate-frames.md`
- service wrapper plot handling
- overlay invertY setting

---

## Files in this pack
- `frontend/src/app/components/airealtime/PuttSolutionPanel.tsx`
- `frontend/src/app/components/greens/GreenOverlay.tsx` (optional)
- `STEP8_SNIPPETS.md`
- `STEP8_RUNBOOK.md`
