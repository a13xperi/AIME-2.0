# Step 8 — AIME Frontend Tool Wiring Snippets
Use these snippets to wire the `solve_putt` tool into your existing `AIRealtime.tsx`.

> These are **insertions**, not a full file replacement.  
> Apply them where indicated (search for the matching comments/blocks in your file).

---

## 1) Import the new panel component
Add near your other panel imports:

```ts
import PuttSolutionPanel, { PuttSolutionData } from "./PuttSolutionPanel";
```

(Optional overlay component)
```ts
import GreenOverlay from "../greens/GreenOverlay";
```

---

## 2) Add React state (near your other tool panel states)
```ts
const [puttData, setPuttData] = useState<PuttSolutionData | null>(null);
const [showPuttPanel, setShowPuttPanel] = useState(false);
const [puttPanelExpanded, setPuttPanelExpanded] = useState(true);
```

---

## 3) Register the `solve_putt` tool (inside `session.update` → `tools: [ ... ]`)
Add this tool object to the tools array:

```ts
{
  type: "function",
  name: "solve_putt",
  description: "Solve a putt on the green (green-to-cup). Provide ball/cup WGS84 locations; the backend resolves dataset + transforms and calls the putt solver service.",
  parameters: {
    type: "object",
    properties: {
      course_id: { type: "string", description: "Course identifier (registry key)." },
      hole_id: { type: "integer", description: "Hole number." },
      ball_wgs84: {
        type: "object",
        properties: {
          lat: { type: "number" },
          lon: { type: "number" }
        },
        required: ["lat","lon"]
      },
      cup_wgs84: {
        type: "object",
        properties: {
          lat: { type: "number" },
          lon: { type: "number" }
        },
        required: ["lat","lon"]
      },
      stimp: {
        type: "object",
        properties: {
          ft: { type: "integer" },
          in: { type: "integer" }
        }
      },
      want_plot: { type: "boolean", description: "If true, return the plot path points." }
    },
    required: ["course_id","hole_id","ball_wgs84","cup_wgs84"]
  }
}
```

---

## 4) Tool handler (inside `messageHandler`, in the `response.done` tool-call section)
Add a new `else if` branch similar to your weather tool:

```ts
} else if (toolName === "solve_putt") {
  const args = JSON.parse(functionCall.arguments || "{}");
  setShowPuttPanel(true);
  setPuttPanelExpanded(true);
  setPuttData({ fetching: true });

  try {
    const resp = await fetch("/api/solve_putt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(args),
    });

    const result = await resp.json();

    if (!resp.ok) {
      const errMsg = result?.message || result?.error || `solve_putt failed (${resp.status})`;
      setPuttData({ fetching: false, error: errMsg, ...result });
    } else {
      setPuttData({ fetching: false, ...result });
    }

    // Return tool output back to the model
    sendClientEvent({
      type: "conversation.item.create",
      item: {
        type: "function_call_output",
        call_id: functionCall.call_id,
        output: JSON.stringify(result),
      },
    });

    // Continue the assistant response
    sendClientEvent({ type: "response.create" });
  } catch (e: any) {
    const errMsg = e?.message || "Network error calling /api/solve_putt";
    setPuttData({ fetching: false, error: errMsg });

    sendClientEvent({
      type: "conversation.item.create",
      item: {
        type: "function_call_output",
        call_id: functionCall.call_id,
        output: JSON.stringify({ error: errMsg }),
      },
    });
    sendClientEvent({ type: "response.create" });
  }
```

---

## 5) Render the panel (where you render other panels)
If your `MainContent` accepts a `holeLayout` slot, you can stack panels:

```tsx
<PuttSolutionPanel
  show={showPuttPanel}
  expanded={puttPanelExpanded}
  isSessionActive={isSessionActive}
  connectionStatus={connectionStatus}
  data={puttData}
  onToggle={() => setPuttPanelExpanded((v) => !v)}
  onClose={() => setShowPuttPanel(false)}
/>
```

---

## 6) Quick manual test (dev)
Use any dataset’s `local_origin_wgs84` from `course_data/.../green_manifest.json` as a baseline:

- ball_wgs84 = local_origin_wgs84
- cup_wgs84 = local_origin_wgs84 with a tiny delta (e.g., +0.00001 lat)

Then ask the assistant in the UI:
> “Call solve_putt for course_id riverside, hole_id 1 with these coordinates…”

If the service chain is working, the Putt Solver panel will populate with:
- instruction_text
- dtm_id
- plot points count (if want_plot=true)
